export type TimeSlot = 'morning' | 'afternoon' | 'night';
export type TaskSlot = TimeSlot;
export type TaskPriority = 'low' | 'medium' | 'high' | 'goal' | 'prayer' | 'habit';
export type AlarmToneId = 'classic' | 'morning' | 'urgent' | 'zen' | 'spiritual';
export type ThemeId = 'dark' | 'light' | 'emerald' | 'rose' | 'ocean' | 'amber';
export type JalaliDateTuple = [number, number, number];

export interface TaskItem {
  id: number;
  text: string;
  slot: TimeSlot;
  time: string; // "HH:MM" or ""
  priority: TaskPriority;
  completed: boolean;
  originGoalId?: number | null;
  originTaskId?: number | null;
  originHabitId?: number | null;
  originHabitTaskId?: number | null;
  goalId?: number;
  goalTaskId?: number;
  habitId?: number;
  habitTaskId?: number;
  isPrayerTask?: boolean;
  isDeferred?: boolean;
  deferLevel?: number;
  // Enhanced Android Alarm & Personalized Reminder fields
  reminderMinutesBefore?: number; // e.g., 0, 5, 10, 15, 30, 60
  alarmEnabled?: boolean; // Ring full alarm at task time / reminder time
  alarmTone?: AlarmToneId;
  customReminderNote?: string;
  reminderSent?: boolean;
  exactAlarmSent?: boolean;
  snoozedUntil?: number | null; // timestamp ms
}

export interface NoteItem {
  id: number;
  text: string;
}

export type TasksByDate = Record<string, TaskItem[]>;
export type NotesByDate = Record<string, NoteItem[]>;

export interface GoalSubTask {
  id: number;
  text: string;
  completed: boolean;
}

export interface GoalItem {
  id: number;
  emoji: string;
  title: string;
  tasks: GoalSubTask[];
  completed: boolean;
  createdAt?: string;
  completedAt?: string | null;
}

export interface HabitSubTask {
  id: number;
  text: string;
  slot: TimeSlot;
  time: string;
  activeDays?: number[]; // 0=Sat ... 6=Fri
  excludedDates?: string[];
}

export interface JalaliDateObj {
  y: number;
  m: number;
  d: number;
}

export interface HabitItem {
  id: number;
  name: string;
  duration: number;
  startDate?: JalaliDateObj;
  startIso?: string;
  tasks: HabitSubTask[];
  activeDays: number[]; // 0=Sat ... 6=Fri
  deferrals: number;
  completed?: boolean;
  completedAt?: string | null;
}

export type CustomReminderType = 'specific_time' | 'interval';

export interface CustomReminder {
  id: number;
  title: string;
  message: string;
  type: CustomReminderType;
  time: string; // "HH:MM" for specific_time
  intervalMinutes: number; // e.g., 30, 60, 120 for interval
  activeStartTime: string; // "08:00"
  activeEndTime: string; // "22:00"
  activeDays: number[]; // 0..6 (Sat..Fri)
  alertMode: 'both' | 'alarm' | 'notification';
  tone: AlarmToneId;
  enabled: boolean;
  lastTriggeredDateKey?: string;
  lastIntervalTriggeredAt?: number;
  snoozedUntil?: number | null;
}

export interface AlarmSettings {
  notificationsEnabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  defaultAdvanceMinutes: number;
  triggerExactTimeAlarm: boolean;
  defaultTone: AlarmToneId;
  volume: number;
  defaultSnoozeMinutes: number;
}

export interface ActiveAlarmPayload {
  id: string;
  title: string;
  subtitle: string;
  timeLabel: string;
  tone: AlarmToneId;
  sourceType: 'task' | 'custom_reminder' | 'focus_timer' | 'test';
  dayKey?: string;
  dateKey?: string;
  taskId?: number;
  reminderId?: number;
}
