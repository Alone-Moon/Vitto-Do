import React from 'react';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  onTriggerInstall: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  isInstalled,
  isIOS,
  onTriggerInstall,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="prayer-modal-overlay active"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="android-install-modal-title"
    >
      <div className="prayer-modal" style={{ maxWidth: '640px' }} onClick={(e) => e.stopPropagation()}>
        <div className="prayer-modal-header">
          <h3 id="android-install-modal-title">📱 نصب نسخه اندروید (PWA & APK)</h3>
          <button
            type="button"
            className="prayer-modal-close"
            onClick={onClose}
            aria-label="بستن راهنمای نصب اندروید"
          >
            ✕
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          {isInstalled ? (
            <div
              style={{
                padding: '16px 20px',
                borderRadius: '16px',
                background: 'rgba(16, 185, 129, 0.15)',
                border: '1px solid rgba(16, 185, 129, 0.45)',
                color: '#34d399',
                fontWeight: 700,
              }}
            >
              ✅ این برنامه هم‌اکنون در حالت اپلیکیشن مستقل (Standalone) روی دستگاه شما نصب است!
            </div>
          ) : isInstallable ? (
            <div
              style={{
                padding: '18px 20px',
                borderRadius: '18px',
                background: 'rgba(139, 92, 246, 0.16)',
                border: '1px solid rgba(139, 92, 246, 0.45)',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
              }}
            >
              <div style={{ fontWeight: 800, fontSize: '1.1rem', color: 'var(--text-main)' }}>
                🚀 نصب مستقیم با یک کلیک روی گوشی اندروید:
              </div>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', lineHeight: 1.7 }}>
                مرورگر شما آماده نصب مستقیم برنامه VitToDo در صفحه اصلی اندروید (بدون نوار آدرس و کاملاً تمام‌صفحه) است.
              </p>
              <button
                type="button"
                className="btn-add"
                style={{ width: '100%' }}
                onClick={onTriggerInstall}
              >
                📲 نصب فوری اپلیکیشن اندروید
              </button>
            </div>
          ) : null}

          <div
            style={{
              background: 'var(--item-bg)',
              border: '1px solid var(--item-border)',
              borderRadius: '18px',
              padding: '18px 20px',
            }}
          >
            <h4 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '10px', color: '#34d399' }}>
              ۱. روش نصب مستقیم در اندروید (Chrome / Samsung Internet)
            </h4>
            <ol style={{ paddingRight: '20px', color: 'var(--text-muted)', lineHeight: 1.9, fontSize: '0.95rem' }}>
              <li>این لینک را در مرورگر <b>Google Chrome</b> گوشی اندروید خود باز کنید.</li>
              <li>روی آیکون سه‌نقطه <b>(⋮)</b> در بالا سمت چپ/راست مرورگر بزنید.</li>
              <li>گزینه <b>«Install app» (نصب برنامه)</b> یا <b>«Add to Home screen»</b> را انتخاب کنید.</li>
              <li>آیکون اختصاصی <b>VitToDo</b> به منوی برنامه‌های گوشی اضافه شده و نوتیفیکیشن‌ها و آلارم‌ها فعال می‌شوند.</li>
            </ol>
          </div>

          {isIOS && (
            <div
              style={{
                background: 'var(--item-bg)',
                border: '1px solid var(--item-border)',
                borderRadius: '18px',
                padding: '18px 20px',
              }}
            >
              <h4 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '10px', color: '#38bdf8' }}>
                🍎 راهنمای نصب در آیفون و آیپد (Safari)
              </h4>
              <p style={{ color: 'var(--text-muted)', lineHeight: 1.8, fontSize: '0.95rem' }}>
                در مرورگر Safari دکمه <b>Share (اشتراک‌گذاری)</b> در پایین صفحه را بزنید و گزینه <b>Add to Home Screen</b> را انتخاب نمایید.
              </p>
            </div>
          )}

          <div
            style={{
              background: 'var(--item-bg)',
              border: '1px solid var(--item-border)',
              borderRadius: '18px',
              padding: '18px 20px',
            }}
          >
            <h4 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '10px', color: '#a78bfa' }}>
              ۲. ساخت فایل نصبی `.apk` مستقیم (PWABuilder / TWA)
            </h4>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.85, fontSize: '0.95rem' }}>
              این پروژه به مانیفست استاندارد اندروید (<code>manifest.webmanifest</code>)، سرویس‌ورکر آفلاین و آیکون‌های Maskable مجهز شده است. برای دریافت فایل <b>APK</b> قابل ارسال در تلگرام یا نصب مستقیم:
            </p>
            <ul style={{ paddingRight: '20px', marginTop: '8px', color: 'var(--text-muted)', lineHeight: 1.85, fontSize: '0.92rem' }}>
              <li>آدرس اینترنتی برنامه (App URL) را در سایت رایگان <b>pwabuilder.com</b> وارد کنید.</li>
              <li>روی دکمه <b>Package for Stores</b> و سپس <b>Android (APK)</b> کلیک کنید تا فایل نصبی اندروید در چند ثانیه تولید و دانلود شود.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
