import React from 'react';
import { ActiveAlarmPayload } from '../types';
import { toPersianDigits } from '../utils/jalali';
import { ALARM_TONES } from '../utils/alarmEngine';

interface ActiveAlarmModalProps {
  alarm: ActiveAlarmPayload | null;
  defaultSnoozeMinutes: number;
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
  onCompleteTask?: () => void;
}

export const ActiveAlarmModal: React.FC<ActiveAlarmModalProps> = ({
  alarm,
  defaultSnoozeMinutes,
  onDismiss,
  onSnooze,
  onCompleteTask,
}) => {
  if (!alarm) return null;

  const toneInfo = ALARM_TONES.find((t) => t.id === alarm.tone) || ALARM_TONES[0];

  return (
    <div
      className="prayer-modal-overlay active"
      style={{ zIndex: 10050, background: 'rgba(2, 6, 23, 0.85)', backdropFilter: 'blur(24px)' }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="active-alarm-title"
    >
      <div
        className="prayer-modal"
        style={{
          maxWidth: '480px',
          textAlign: 'center',
          border: '2px solid rgba(244, 63, 94, 0.65)',
          boxShadow: '0 24px 60px rgba(244, 63, 94, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.25)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          style={{
            width: '88px',
            height: '88px',
            margin: '0 auto 16px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, rgba(244, 63, 94, 0.28), rgba(139, 92, 246, 0.28))',
            border: '2px solid rgba(244, 63, 94, 0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '2.8rem',
            animation: 'bounce-trophy 1s infinite ease-in-out',
          }}
        >
          ⏰
        </div>

        <div
          style={{
            display: 'inline-block',
            padding: '5px 16px',
            borderRadius: '999px',
            background: 'rgba(244, 63, 94, 0.2)',
            border: '1px solid rgba(244, 63, 94, 0.45)',
            color: '#fda4af',
            fontWeight: 800,
            fontSize: '0.95rem',
            marginBottom: '12px',
          }}
        >
          🚨 آلارم هوشمند اندروید • ساعت {toPersianDigits(alarm.timeLabel)}
        </div>

        <h3
          id="active-alarm-title"
          style={{
            fontSize: '1.65rem',
            fontWeight: 900,
            color: 'var(--text-main)',
            marginBottom: '10px',
            lineHeight: 1.4,
          }}
        >
          {alarm.title}
        </h3>

        <p
          style={{
            fontSize: '1.08rem',
            color: 'var(--text-muted)',
            marginBottom: '16px',
            lineHeight: 1.7,
            fontWeight: 600,
          }}
        >
          {alarm.subtitle}
        </p>

        <div
          style={{
            fontSize: '0.85rem',
            color: 'var(--text-subtle)',
            marginBottom: '24px',
          }}
        >
          آهنگ در حال پخش: {toneInfo.name}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <button
            type="button"
            onClick={onDismiss}
            style={{
              width: '100%',
              padding: '14px 20px',
              borderRadius: '16px',
              border: 'none',
              background: 'linear-gradient(135deg, #f43f5e, #e11d48)',
              color: '#fff',
              fontWeight: 900,
              fontSize: '1.15rem',
              cursor: 'pointer',
              boxShadow: '0 10px 25px rgba(244, 63, 94, 0.4)',
            }}
          >
            🔕 قطع آلارم (متوجه شدم)
          </button>

          {alarm.sourceType === 'task' && onCompleteTask && (
            <button
              type="button"
              onClick={onCompleteTask}
              style={{
                width: '100%',
                padding: '13px 20px',
                borderRadius: '16px',
                border: '1px solid rgba(16, 185, 129, 0.5)',
                background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.25), rgba(5, 150, 105, 0.35))',
                color: '#34d399',
                fontWeight: 800,
                fontSize: '1.05rem',
                cursor: 'pointer',
              }}
            >
              ✅ انجام شد (تیک زدن تسک و قطع زنگ)
            </button>
          )}

          <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap', marginTop: '4px' }}>
            <button
              type="button"
              onClick={() => onSnooze(defaultSnoozeMinutes)}
              className="backup-btn"
              style={{ flex: 1, minWidth: '120px', fontSize: '0.95rem' }}
            >
              💤 تعویق {toPersianDigits(defaultSnoozeMinutes)} دقیقه
            </button>
            <button
              type="button"
              onClick={() => onSnooze(10)}
              className="backup-btn"
              style={{ flex: 1, minWidth: '120px', fontSize: '0.95rem' }}
            >
              💤 تعویق ۱۰ دقیقه
            </button>
            <button
              type="button"
              onClick={() => onSnooze(15)}
              className="backup-btn"
              style={{ flex: 1, minWidth: '120px', fontSize: '0.95rem' }}
            >
              💤 تعویق ۱۵ دقیقه
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
