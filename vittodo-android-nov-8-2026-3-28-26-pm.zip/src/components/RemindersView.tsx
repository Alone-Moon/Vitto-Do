import React, { useState } from 'react';
import {
  AlarmSettings,
  AlarmToneId,
  CustomReminder,
  CustomReminderType,
  TaskItem,
} from '../types';
import {
  ALARM_TONES,
  playToneSequence,
} from '../utils/alarmEngine';
import {
  toPersianDigits,
  weekDaysShort,
  slotEmojis,
  slotLabels,
} from '../utils/jalali';

interface RemindersViewProps {
  reminders: CustomReminder[];
  settings: AlarmSettings;
  todayTasks: TaskItem[];
  notificationPermission: NotificationPermission;
  onRequestPermission: () => void;
  onAddReminder: (reminder: Omit<CustomReminder, 'id'>) => void;
  onToggleReminder: (id: number) => void;
  onDeleteReminder: (id: number) => void;
  onUpdateSettings: (next: AlarmSettings) => void;
  onTestAlarmAndNotification: () => void;
  onToggleTaskAlarm: (taskId: number) => void;
  onUpdateTaskReminderMinutes: (taskId: number, minutes: number) => void;
}

export const RemindersView: React.FC<RemindersViewProps> = ({
  reminders,
  settings,
  todayTasks,
  notificationPermission,
  onRequestPermission,
  onAddReminder,
  onToggleReminder,
  onDeleteReminder,
  onUpdateSettings,
  onTestAlarmAndNotification,
  onToggleTaskAlarm,
  onUpdateTaskReminderMinutes,
}) => {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState<CustomReminderType>('specific_time');
  const [time, setTime] = useState('09:00');
  const [intervalMinutes, setIntervalMinutes] = useState(60);
  const [activeStartTime, setActiveStartTime] = useState('08:00');
  const [activeEndTime, setActiveEndTime] = useState('22:00');
  const [activeDays, setActiveDays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [alertMode, setAlertMode] = useState<'both' | 'alarm' | 'notification'>('both');
  const [tone, setTone] = useState<AlarmToneId>(settings.defaultTone);

  const toggleDayInForm = (dayIdx: number) => {
    setActiveDays((prev) => {
      if (prev.includes(dayIdx)) {
        if (prev.length <= 1) return prev;
        return prev.filter((d) => d !== dayIdx);
      }
      return [...prev, dayIdx].sort();
    });
  };

  const handleCreateReminder = () => {
    const cleanTitle = title.trim();
    if (!cleanTitle) return;

    onAddReminder({
      title: cleanTitle,
      message: message.trim() || `یادآور هوشمند: ${cleanTitle}`,
      type,
      time: time || '09:00',
      intervalMinutes: Math.max(5, Number(intervalMinutes) || 60),
      activeStartTime: activeStartTime || '08:00',
      activeEndTime: activeEndTime || '22:00',
      activeDays,
      alertMode,
      tone,
      enabled: true,
    });

    setTitle('');
    setMessage('');
  };

  const applyPreset = (
    presetTitle: string,
    presetMsg: string,
    presetType: CustomReminderType,
    presetTime: string,
    presetInterval: number,
    presetTone: AlarmToneId
  ) => {
    setTitle(presetTitle);
    setMessage(presetMsg);
    setType(presetType);
    setTime(presetTime);
    setIntervalMinutes(presetInterval);
    setTone(presetTone);
  };

  const timedTasksToday = todayTasks.filter((t) => Boolean(t.time));

  return (
    <div id="reminders-view" className="view-section active">
      <div className="section-header">
        <h2>🔔 مرکز آلارم و یادآورهای شخصی‌سازی‌شده اندروید</h2>
        <div className="header-actions">
          <button
            type="button"
            className="btn-add"
            style={{
              height: '44px',
              padding: '0 20px',
              background: 'linear-gradient(135deg, #f43f5e, #e11d48)',
              boxShadow: '0 6px 20px rgba(244, 63, 94, 0.35)',
            }}
            onClick={onTestAlarmAndNotification}
          >
            🚨 تست فوری آلارم و نوتیفیکیشن
          </button>
        </div>
      </div>

      {/* Android Notification Permission Banner */}
      <div
        className="backup-card"
        style={{
          borderColor:
            notificationPermission === 'granted'
              ? 'rgba(16, 185, 129, 0.45)'
              : 'rgba(251, 191, 36, 0.5)',
          marginBottom: '22px',
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '14px',
          }}
        >
          <div>
            <h3 style={{ marginBottom: '6px' }}>
              📲 وضعیت نوتیفیکیشن و هشدار سیستم اندروید
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.96rem' }}>
              {notificationPermission === 'granted'
                ? '✅ مجوز ارسال نوتیفیکیشن اندروید فعال است. آلارم‌های صوتی، لرزش (Vibration) و اعلان‌ها آماده کار هستند.'
                : '⚠️ برای دریافت نوتیفیکیشن در نوار اعلان بالای گوشی اندروید، دکمه «فعال‌سازی مجوز نوتیفیکیشن» را بزنید.'}
            </p>
          </div>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            {notificationPermission !== 'granted' && (
              <button
                type="button"
                className="btn-add"
                onClick={onRequestPermission}
              >
                🔓 فعال‌سازی مجوز نوتیفیکیشن
              </button>
            )}
            <button
              type="button"
              className="backup-btn"
              onClick={() => playToneSequence(settings.defaultTone, settings.volume)}
            >
              🔊 پخش نمونه صدای زنگ
            </button>
          </div>
        </div>
      </div>

      {/* Create Personalized Reminder Form */}
      <div className="subsection-header">
        <h3>✨ ساخت یادآور و آلارم شخصی‌سازی‌شده جدید</h3>
        <span>ساعتی یا تکرارشونده دوره‌ای</span>
      </div>

      {/* Quick Presets */}
      <div
        style={{
          display: 'flex',
          gap: '8px',
          flexWrap: 'wrap',
          marginBottom: '16px',
          alignItems: 'center',
        }}
      >
        <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)', fontWeight: 700 }}>
          ⚡ قالب‌های آماده سریع:
        </span>
        <button
          type="button"
          className="filter-btn"
          onClick={() =>
            applyPreset(
              '💧 نوشیدن آب و هیدراتاسیون',
              'وقتشه یک لیوان آب گوارا بنوشی تا تمرکزت بالا بمونه!',
              'interval',
              '09:00',
              60,
              'zen'
            )
          }
        >
          💧 یادآور نوشیدن آب (هر ۱ ساعت)
        </button>
        <button
          type="button"
          className="filter-btn"
          onClick={() =>
            applyPreset(
              '👀 استراحت چشم و گردن (۲۰-۲۰-۲۰)',
              '۲۰ ثانیه به فاصله دور نگاه کن و شونه‌هات رو رها کن.',
              'interval',
              '09:00',
              45,
              'morning'
            )
          }
        >
          👀 استراحت چشم (هر ۴۵ دقیقه)
        </button>
        <button
          type="button"
          className="filter-btn"
          onClick={() =>
            applyPreset(
              '🌅 مرور اهداف صبحگاهی',
              '۳ تسک مهم امروزت رو اولویت‌بندی کن و با قدرت شروع کن!',
              'specific_time',
              '08:00',
              60,
              'morning'
            )
          }
        >
          🌅 آلارم شروع روز (۰۸:۰۰)
        </button>
        <button
          type="button"
          className="filter-btn"
          onClick={() =>
            applyPreset(
              '🌙 جمع‌بندی و ثبت گزارش شبانه',
              'تسک‌های انجام‌شده امروز رو تیک بزن و فردا رو برنامه‌ریزی کن.',
              'specific_time',
              '22:30',
              60,
              'spiritual'
            )
          }
        >
          🌙 مرور شبانه (۲۲:۳۰)
        </button>
      </div>

      <div className="input-wrapper" style={{ flexDirection: 'column', alignItems: 'stretch', gap: '16px' }}>
        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          <div className="input-field-group" style={{ flex: 2, minWidth: '220px' }}>
            <label htmlFor="custom-rem-title">عنوان یادآور یا آلارم شخصی:</label>
            <input
              id="custom-rem-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: خوردن ویتامین، مرور زبان، نوشیدن آب..."
            />
          </div>
          <div className="input-field-group" style={{ flex: 3, minWidth: '240px' }}>
            <label htmlFor="custom-rem-msg">پیام شخصی‌سازی‌شده (نمایش در نوتیفیکیشن و صفحه آلارم):</label>
            <input
              id="custom-rem-msg"
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="مثال: قهرمان! وقت انجام این کار مهمه..."
            />
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div className="input-field-group" style={{ minWidth: '170px' }}>
            <label htmlFor="custom-rem-type">نوع زمان‌بندی:</label>
            <select
              id="custom-rem-type"
              value={type}
              onChange={(e) => setType(e.target.value as CustomReminderType)}
            >
              <option value="specific_time">⏰ ساعت مشخص روزانه</option>
              <option value="interval">🔁 تکرار دوره‌ای (هر چند دقیقه)</option>
            </select>
          </div>

          {type === 'specific_time' ? (
            <div className="input-field-group" style={{ minWidth: '140px' }}>
              <label htmlFor="custom-rem-time">ساعت دقیق آلارم:</label>
              <input
                id="custom-rem-time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
              />
            </div>
          ) : (
            <>
              <div className="input-field-group" style={{ minWidth: '140px' }}>
                <label htmlFor="custom-rem-interval">فاصله تکرار (دقیقه):</label>
                <select
                  id="custom-rem-interval"
                  value={intervalMinutes}
                  onChange={(e) => setIntervalMinutes(Number(e.target.value))}
                >
                  <option value={15}>هر ۱۵ دقیقه</option>
                  <option value={30}>هر ۳۰ دقیقه</option>
                  <option value={45}>هر ۴۵ دقیقه</option>
                  <option value={60}>هر ۱ ساعت (۶۰ دقیقه)</option>
                  <option value={90}>هر ۹۰ دقیقه</option>
                  <option value={120}>هر ۲ ساعت (۱۲۰ دقیقه)</option>
                  <option value={180}>هر ۳ ساعت</option>
                </select>
              </div>
              <div className="input-field-group" style={{ minWidth: '125px' }}>
                <label htmlFor="custom-rem-start">از ساعت:</label>
                <input
                  id="custom-rem-start"
                  type="time"
                  value={activeStartTime}
                  onChange={(e) => setActiveStartTime(e.target.value)}
                />
              </div>
              <div className="input-field-group" style={{ minWidth: '125px' }}>
                <label htmlFor="custom-rem-end">تا ساعت:</label>
                <input
                  id="custom-rem-end"
                  type="time"
                  value={activeEndTime}
                  onChange={(e) => setActiveEndTime(e.target.value)}
                />
              </div>
            </>
          )}

          <div className="input-field-group" style={{ minWidth: '180px' }}>
            <label htmlFor="custom-rem-mode">نحوه هشدار:</label>
            <select
              id="custom-rem-mode"
              value={alertMode}
              onChange={(e) => setAlertMode(e.target.value as 'both' | 'alarm' | 'notification')}
            >
              <option value="both">🚨 آلارم صوتی + 🔔 نوتیفیکیشن</option>
              <option value="alarm">🚨 فقط آلارم صوتی تمام‌صفحه</option>
              <option value="notification">🔔 فقط نوتیفیکیشن بی‌صدا/ملایم</option>
            </select>
          </div>

          <div className="input-field-group" style={{ minWidth: '185px' }}>
            <label htmlFor="custom-rem-tone">آهنگ زنگ اختصاصی:</label>
            <select
              id="custom-rem-tone"
              value={tone}
              onChange={(e) => {
                const nextTone = e.target.value as AlarmToneId;
                setTone(nextTone);
                playToneSequence(nextTone, settings.volume);
              }}
            >
              {ALARM_TONES.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Days of week selector */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '14px',
            paddingTop: '8px',
            borderTop: '1px dashed var(--panel-border)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '0.92rem', color: 'var(--text-muted)', fontWeight: 700 }}>
              📅 روزهای فعال هفته:
            </span>
            <div style={{ display: 'flex', gap: '6px' }}>
              {weekDaysShort.map((dayName, idx) => {
                const isActive = activeDays.includes(idx);
                return (
                  <button
                    key={dayName}
                    type="button"
                    onClick={() => toggleDayInForm(idx)}
                    style={{
                      width: '38px',
                      height: '38px',
                      borderRadius: '10px',
                      border: isActive
                        ? '1px solid var(--accent-primary)'
                        : '1px solid var(--panel-border)',
                      background: isActive ? 'var(--accent-soft)' : 'var(--item-bg)',
                      color: isActive ? 'var(--accent-primary)' : 'var(--text-muted)',
                      fontWeight: 800,
                      cursor: 'pointer',
                    }}
                  >
                    {dayName}
                  </button>
                );
              })}
            </div>
          </div>

          <button type="button" className="btn-add" onClick={handleCreateReminder}>
            ➕ ثبت یادآور شخصی‌سازی‌شده
          </button>
        </div>
      </div>

      {/* Active Custom Reminders List */}
      <div className="subsection-header" style={{ marginTop: '28px' }}>
        <h3>📋 لیست یادآورها و آلارم‌های شخصی شما</h3>
        <span>{toPersianDigits(reminders.filter((r) => r.enabled).length)} یادآور فعال</span>
      </div>

      <div className="goals-grid" style={{ marginBottom: '32px' }}>
        {reminders.length === 0 ? (
          <div
            style={{
              gridColumn: '1 / -1',
              textAlign: 'center',
              color: 'var(--text-muted)',
              padding: '36px',
              background: 'var(--panel-bg)',
              borderRadius: '22px',
              border: '1px solid var(--panel-border)',
              fontSize: '1.1rem',
            }}
          >
            هنوز یادآور شخصی نساختی. از فرم بالا یا قالب‌های آماده اولین یادآور یا آلارم خودت رو تنظیم کن! ⏰
          </div>
        ) : (
          reminders.map((rem) => {
            const toneObj = ALARM_TONES.find((t) => t.id === rem.tone) || ALARM_TONES[0];
            const modeLabel =
              rem.alertMode === 'both'
                ? '🚨 آلارم + 🔔 نوتیفیکیشن'
                : rem.alertMode === 'alarm'
                ? '🚨 آلارم صوتی'
                : '🔔 نوتیفیکیشن';

            return (
              <div
                key={rem.id}
                className="goal-card"
                style={{
                  opacity: rem.enabled ? 1 : 0.6,
                  borderColor: rem.enabled ? 'var(--panel-border)' : 'rgba(100,116,139,0.25)',
                }}
              >
                <div className="goal-card-header">
                  <span className="goal-title">
                    {rem.type === 'specific_time' ? '⏰' : '🔁'} {rem.title}
                  </span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <button
                      type="button"
                      className={rem.enabled ? 'btn-complete-goal' : 'btn-restore-goal'}
                      onClick={() => onToggleReminder(rem.id)}
                    >
                      {rem.enabled ? '✔ فعال' : '⏸ غیرفعال'}
                    </button>
                    <button
                      type="button"
                      className="btn-delete"
                      onClick={() => onDeleteReminder(rem.id)}
                    >
                      حذف
                    </button>
                  </div>
                </div>

                <p style={{ color: 'var(--text-muted)', fontSize: '0.98rem', marginBottom: '14px' }}>
                  💬 {rem.message}
                </p>

                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '12px' }}>
                  <span className="habit-slot-badge">
                    {rem.type === 'specific_time'
                      ? `⏰ ساعت ${toPersianDigits(rem.time)}`
                      : `🔁 هر ${toPersianDigits(rem.intervalMinutes)} دقیقه (${toPersianDigits(
                          rem.activeStartTime
                        )} تا ${toPersianDigits(rem.activeEndTime)})`}
                  </span>
                  <span className="habit-days-chip">{modeLabel}</span>
                  <span
                    className="task-time"
                    style={{ cursor: 'pointer' }}
                    onClick={() => playToneSequence(rem.tone, settings.volume)}
                    title="پخش پیش‌نمایش زنگ"
                  >
                    🎵 {toneObj.name}
                  </span>
                </div>

                <div style={{ fontSize: '0.85rem', color: 'var(--text-subtle)' }}>
                  روزهای فعال:{' '}
                  {rem.activeDays.length === 7
                    ? 'همه روزهای هفته'
                    : rem.activeDays.map((d) => weekDaysShort[d]).join(' ، ')}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Today's Timed Tasks Alarm Customization */}
      <div className="subsection-header">
        <h3>⏱️ تنظیم یادآور تسک‌های زمان‌دار امروز</h3>
        <span>{toPersianDigits(timedTasksToday.length)} تسک زمان‌دار</span>
      </div>

      <div className="backup-card" style={{ marginBottom: '28px' }}>
        {timedTasksToday.length === 0 ? (
          <div style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '16px' }}>
            امروز تسک زمان‌داری ثبت نشده است. در تب «📋 روزانه» هنگام افزودن تسک، ساعت آن را مشخص کنید تا آلارم خودکار برایش فعال شود.
          </div>
        ) : (
          <div className="prayer-list">
            {timedTasksToday.map((t) => {
              const isAlarmOn =
                t.alarmEnabled !== undefined ? t.alarmEnabled : settings.triggerExactTimeAlarm;
              const advMin =
                t.reminderMinutesBefore !== undefined
                  ? t.reminderMinutesBefore
                  : settings.defaultAdvanceMinutes;

              return (
                <div key={t.id} className={`prayer-item ${t.completed ? 'done' : ''}`}>
                  <div className="prayer-item-right" style={{ flexWrap: 'wrap' }}>
                    <span className="prayer-name">{t.text}</span>
                    <span className="task-time">⏰ {toPersianDigits(t.time)}</span>
                    <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                      {slotEmojis[t.slot]} {slotLabels[t.slot]}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                    <select
                      className="goal-slot-select"
                      aria-label={`زمان یادآوری قبل از ${t.text}`}
                      value={advMin}
                      onChange={(e) => onUpdateTaskReminderMinutes(t.id, Number(e.target.value))}
                    >
                      <option value={0}>بدون پیش‌یادآور (فقط سر ساعت)</option>
                      <option value={5}>۵ دقیقه قبل</option>
                      <option value={10}>۱۰ دقیقه قبل</option>
                      <option value={15}>۱۵ دقیقه قبل</option>
                      <option value={30}>۳۰ دقیقه قبل</option>
                      <option value={60}>۱ ساعت قبل</option>
                    </select>
                    <button
                      type="button"
                      className={isAlarmOn ? 'btn-complete-goal' : 'btn-delete perm'}
                      onClick={() => onToggleTaskAlarm(t.id)}
                    >
                      {isAlarmOn ? '🚨 آلارم سر ساعت: روشن' : '🔕 آلارم سر ساعت: خاموش'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Global Alarm & Notification Settings */}
      <div className="subsection-header">
        <h3>⚙️ تنظیمات پیش‌فرض زنگ، ویبره و یادآور</h3>
        <span>ذخیره خودکار در حافظه دستگاه</span>
      </div>

      <div className="backup-card">
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: '18px',
          }}
        >
          <div className="input-field-group">
            <label htmlFor="setting-default-tone">🎵 آهنگ پیش‌فرض آلارم‌ها:</label>
            <select
              id="setting-default-tone"
              className="goal-slot-select"
              style={{ padding: '11px 14px', fontSize: '1rem' }}
              value={settings.defaultTone}
              onChange={(e) => {
                const nextTone = e.target.value as AlarmToneId;
                onUpdateSettings({ ...settings, defaultTone: nextTone });
                playToneSequence(nextTone, settings.volume);
              }}
            >
              {ALARM_TONES.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} — {t.desc}
                </option>
              ))}
            </select>
          </div>

          <div className="input-field-group">
            <label htmlFor="setting-advance-min">⏳ پیش‌یادآور خودکار قبل از هر تسک زمان‌دار:</label>
            <select
              id="setting-advance-min"
              className="goal-slot-select"
              style={{ padding: '11px 14px', fontSize: '1rem' }}
              value={settings.defaultAdvanceMinutes}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  defaultAdvanceMinutes: Number(e.target.value),
                })
              }
            >
              <option value={0}>غیرفعال (فقط در لحظه تسک)</option>
              <option value={5}>۵ دقیقه قبل از شروع تسک</option>
              <option value={10}>۱۰ دقیقه قبل از شروع تسک</option>
              <option value={15}>۱۵ دقیقه قبل از شروع تسک</option>
              <option value={30}>۳۰ دقیقه قبل از شروع تسک</option>
              <option value={60}>۱ ساعت قبل از شروع تسک</option>
            </select>
          </div>

          <div className="input-field-group">
            <label htmlFor="setting-snooze-min">💤 مدت زمان تعویق پیش‌فرض (Snooze):</label>
            <select
              id="setting-snooze-min"
              className="goal-slot-select"
              style={{ padding: '11px 14px', fontSize: '1rem' }}
              value={settings.defaultSnoozeMinutes}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  defaultSnoozeMinutes: Number(e.target.value),
                })
              }
            >
              <option value={5}>۵ دقیقه</option>
              <option value={10}>۱۰ دقیقه</option>
              <option value={15}>۱۵ دقیقه</option>
              <option value={20}>۲۰ دقیقه</option>
            </select>
          </div>

          <div className="input-field-group">
            <label htmlFor="setting-volume">
              🔊 بلندی صدای آلارم: {toPersianDigits(settings.volume)}٪
            </label>
            <input
              id="setting-volume"
              type="range"
              min={10}
              max={100}
              step={5}
              value={settings.volume}
              onChange={(e) =>
                onUpdateSettings({ ...settings, volume: Number(e.target.value) })
              }
              style={{ accentColor: 'var(--accent-primary)', cursor: 'pointer', marginTop: '8px' }}
            />
          </div>
        </div>

        <div
          style={{
            display: 'flex',
            gap: '16px',
            flexWrap: 'wrap',
            marginTop: '20px',
            paddingTop: '16px',
            borderTop: '1px dashed var(--panel-border)',
          }}
        >
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontWeight: 700 }}>
            <input
              type="checkbox"
              checked={settings.triggerExactTimeAlarm}
              onChange={(e) =>
                onUpdateSettings({ ...settings, triggerExactTimeAlarm: e.target.checked })
              }
            />
            <span>🚨 پخش آلارم صوتی در ساعت دقیق شروع تسک‌ها</span>
          </label>

          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontWeight: 700 }}>
            <input
              type="checkbox"
              checked={settings.vibrationEnabled}
              onChange={(e) =>
                onUpdateSettings({ ...settings, vibrationEnabled: e.target.checked })
              }
            />
            <span>📳 لرزش گوشی اندروید هنگام آلارم (Vibration)</span>
          </label>

          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontWeight: 700 }}>
            <input
              type="checkbox"
              checked={settings.notificationsEnabled}
              onChange={(e) =>
                onUpdateSettings({ ...settings, notificationsEnabled: e.target.checked })
              }
            />
            <span>🔔 ارسال نوتیفیکیشن سیستم اندروید</span>
          </label>
        </div>
      </div>
    </div>
  );
};
