import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  TaskItem,
  TasksByDate,
  NotesByDate,
  GoalItem,
  HabitItem,
  HabitSubTask,
  CustomReminder,
  AlarmSettings,
  ActiveAlarmPayload,
  ThemeId,
  TaskSlot,
  TaskPriority,
  JalaliDateTuple,
} from './types';
import {
  toPersianDigits,
  jalaliToGregorian,
  gregorianToJalali,
  getTodayJalali,
  jalaliToIso,
  isoToJalali,
  addDaysToIso,
  compareIso,
  calcDaysBetweenIso,
  getDateKey,
  getJalaliMonthLength,
  getDayOfWeek,
  isHabitCompleted,
  isPrayerMissed,
  persianMonths,
  weekDays,
  weekDaysShort,
  slotLabels,
  slotEmojis,
  priorityLabels,
  priorityOrder,
  VALID_THEMES,
} from './utils/jalali';
import {
  DEFAULT_ALARM_SETTINGS,
  evaluateDueAlarms,
  pruneFiredHistory,
  sendAndroidNotification,
  startAlarmLoop,
  stopAlarmLoop,
  triggerHaptic,
} from './utils/alarmEngine';
import { usePWAInstall } from './hooks/usePWAInstall';
import { ActiveAlarmModal } from './components/ActiveAlarmModal';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { RemindersView } from './components/RemindersView';

function safeStorageGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function safeStorageSet(key: string, val: unknown): void {
  try {
    localStorage.setItem(key, typeof val === 'string' ? val : JSON.stringify(val));
  } catch {
    // Ignore storage quota errors
  }
}

interface ToastMessage {
  id: number;
  title: string;
  text: string;
  type: 'info' | 'success' | 'warning';
}

interface ConfirmModalState {
  isOpen: boolean;
  title: string;
  message: string;
  icon: string;
  yesLabel: string;
  onConfirm: (() => void) | null;
}

const FOCUS_MINDSET_QUOTES = [
  {
    tag: '⚡ قانون ۵ دقیقه',
    text: 'سخت‌ترین بخش هر کار، شروع کردن آن است؛ فقط ۵ دقیقه اول را متمرکز بمان تا مغز وارد حالت غرقگی (Flow) شود.',
  },
  {
    tag: '🎯 تک‌وظیفگی (Single-Tasking)',
    text: 'مغز انسان در تمرکز روی یک هدف واحد، ۳ برابر سریع‌تر و با استرس بسیار کمتر عمل می‌کند.',
  },
  {
    tag: '🌱 اثر مرکب روزانه',
    text: 'تکمیل همین یک تسک کوچک، دوپامین لازم برای فتح تسک‌های بعدی امروزت را آزاد می‌کند.',
  },
  {
    tag: '🧘‍♂️ ذهن آرام و بی‌تشویش',
    text: 'اگر فکر یا کار دیگری وسط تمرکز به ذهنت رسید، در کادر «تخلیه ذهنی» پایین بنویس تا ذهنت رها شود.',
  },
];

export default function App() {
  // Core VitToDo state (100% compatible with VitTo Do Mobile localStorage keys)
  const [tasksData, setTasksData] = useState<TasksByDate>(() =>
    safeStorageGet<TasksByDate>('glass_todo_tasks_v7', {})
  );
  const [notesData, setNotesData] = useState<NotesByDate>(() =>
    safeStorageGet<NotesByDate>('glass_todo_notes_v7', {})
  );
  const [goalsData, setGoalsData] = useState<GoalItem[]>(() =>
    safeStorageGet<GoalItem[]>('glass_todo_goals_v2', [])
  );
  const [habitsData, setHabitsData] = useState<HabitItem[]>(() =>
    safeStorageGet<HabitItem[]>('glass_todo_habits_v1', [])
  );
  const [theme, setTheme] = useState<ThemeId>(() => {
    const saved = localStorage.getItem('glass_todo_theme') as ThemeId | null;
    return saved && VALID_THEMES.includes(saved) ? saved : 'dark';
  });

  // Android Alarms & Personalized Reminders state
  const [customReminders, setCustomReminders] = useState<CustomReminder[]>(() =>
    safeStorageGet<CustomReminder[]>('glass_todo_custom_reminders_v1', [
      {
        id: 101,
        title: '💧 نوشیدن آب و هیدراتاسیون',
        message: 'وقتشه یک لیوان آب بنوشی تا انرژی و تمرکزت در بالاترین سطح بمونه!',
        type: 'interval',
        time: '09:00',
        intervalMinutes: 60,
        activeStartTime: '08:00',
        activeEndTime: '22:00',
        activeDays: [0, 1, 2, 3, 4, 5, 6],
        alertMode: 'both',
        tone: 'zen',
        enabled: false,
      },
    ])
  );
  const [alarmSettings, setAlarmSettings] = useState<AlarmSettings>(() =>
    safeStorageGet<AlarmSettings>('glass_todo_alarm_settings_v1', DEFAULT_ALARM_SETTINGS)
  );
  const [firedRegistry, setFiredRegistry] = useState<Record<string, number>>(() =>
    safeStorageGet<Record<string, number>>('glass_todo_fired_alarms_v1', {})
  );
  const [activeAlarm, setActiveAlarm] = useState<ActiveAlarmPayload | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(
    () => (typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default')
  );

  // Navigation & UI state
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'tasks' | 'weekly' | 'calendar' | 'goals' | 'reminders' | 'backup'
  >('dashboard');
  const [selectedDay, setSelectedDay] = useState<JalaliDateTuple>(() => getTodayJalali());
  const [calendarMonth, setCalendarMonth] = useState<[number, number]>(() => {
    const [y, m] = getTodayJalali();
    return [y, m];
  });

  // Mobile Progressive Disclosure Drawers & Sub-Tabs
  const [isThemeDrawerOpen, setIsThemeDrawerOpen] = useState(false);
  const [isTaskComposerOpen, setIsTaskComposerOpen] = useState(false);
  const [isTaskFilterOpen, setIsTaskFilterOpen] = useState(false);
  const [activeMobileSlot, setActiveMobileSlot] = useState<'all' | TaskSlot>('all');
  const [goalsSubTab, setGoalsSubTab] = useState<'goals' | 'habits' | 'hof'>('goals');
  const [expandedWeeklyDays, setExpandedWeeklyDays] = useState<Record<string, boolean>>({});
  const [openInfoTip, setOpenInfoTip] = useState(false);

  // Daily Tasks form & filters
  const [taskInput, setTaskInput] = useState('');
  const [taskSlot, setTaskSlot] = useState<TaskSlot>('morning');
  const [taskPriority, setTaskPriority] = useState<TaskPriority>('medium');
  const [taskTime, setTaskTime] = useState('');
  const [taskReminderMin, setTaskReminderMin] = useState<number>(15);
  const [taskAlarmEnabled, setTaskAlarmEnabled] = useState<boolean>(true);
  const [currentFilter, setCurrentFilter] = useState<'all' | 'pending' | 'completed' | 'high'>('pending');
  const [currentSort, setCurrentSort] = useState<'time' | 'priority' | 'created'>('time');
  const [searchQuery, setSearchQuery] = useState('');

  // Notes state
  const [notesOpen, setNotesOpen] = useState(false);
  const [noteInput, setNoteInput] = useState('');

  // Goals & Habits form state
  const [newGoalEmoji, setNewGoalEmoji] = useState('📌');
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [goalSubtaskInputs, setGoalSubtaskInputs] = useState<Record<number, string>>({});
  const [goalTransferSlots, setGoalTransferSlots] = useState<Record<string, TaskSlot>>({});

  const [newHabitName, setNewHabitName] = useState('');
  const [newHabitDuration, setNewHabitDuration] = useState(66);
  const [editingHabitId, setEditingHabitId] = useState<number | null>(null);
  const [openAdvancedHabitIds, setOpenAdvancedHabitIds] = useState<Record<number, boolean>>({});
  const [habitNewTaskInputs, setHabitNewTaskInputs] = useState<
    Record<number, { text: string; slot: TaskSlot; time: string }>
  >({});
  const [habitEditDraft, setHabitEditDraft] = useState<{
    name: string;
    duration: number;
    tasks: Array<{ id: number; text: string; slot: TaskSlot; time: string; activeDays: number[] }>;
  } | null>(null);

  // Weekly view add inputs
  const [weeklyInputs, setWeeklyInputs] = useState<
    Record<string, { text: string; slot: TaskSlot; time: string }>
  >({});

  // Modals & Overlays
  const [isMissedPrayersOpen, setIsMissedPrayersOpen] = useState(false);
  const [isFocusModeOpen, setIsFocusModeOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [confirmModal, setConfirmModal] = useState<ConfirmModalState>({
    isOpen: false,
    title: 'تأیید عملیات',
    message: 'آیا مطمئن هستید؟',
    icon: '✨',
    yesLabel: 'بله، ادامه بده',
    onConfirm: null,
  });

  // Focus Mode Studio state (Deep Work & Flow State)
  const [focusViewTab, setFocusViewTab] = useState<'single' | 'list'>('single');
  const [focusCurrentIndex, setFocusCurrentIndex] = useState(0);
  const [focusTimerTotal, setFocusTimerTotal] = useState(25 * 60);
  const [focusTimerRemaining, setFocusTimerRemaining] = useState(25 * 60);
  const [focusTimerRunning, setFocusTimerRunning] = useState(false);
  const [focusModeLabel, setFocusModeLabel] = useState('🍅 پومودورو ۲۵ دقیقه');
  const [focusBrainDumpInput, setFocusBrainDumpInput] = useState('');
  const focusTimerIntervalRef = useRef<number | null>(null);

  // Google Drive Cloud Sync state
  const [gdriveClientId, setGdriveClientId] = useState(() => localStorage.getItem('vitodo_gdrive_client_id') || '');
  const [gdriveAccessToken, setGdriveAccessToken] = useState(
    () => localStorage.getItem('vitodo_gdrive_access_token') || ''
  );
  const [gdriveFileId, setGdriveFileId] = useState(() => localStorage.getItem('vitodo_gdrive_file_id') || '');
  const [gdriveAutoSync, setGdriveAutoSync] = useState(
    () => localStorage.getItem('vitodo_gdrive_autosync') !== 'false'
  );
  const [gdriveLastSync, setGdriveLastSync] = useState(() => localStorage.getItem('vitodo_gdrive_last_sync') || '');
  const [isGDriveSetupOpen, setIsGDriveSetupOpen] = useState(false);

  // Local FileSystem handle state
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [fileHandle, setFileHandle] = useState<any>(null);
  const [backupLastSave, setBackupLastSave] = useState('');
  const restoreInputRef = useRef<HTMLInputElement | null>(null);
  const taskInputRef = useRef<HTMLInputElement | null>(null);
  const goalInputRef = useRef<HTMLInputElement | null>(null);
  const habitInputRef = useRef<HTMLInputElement | null>(null);

  // Touch Swipe state for tasks
  const touchStartRef = useRef<{ x: number; y: number; taskId: number | null }>({
    x: 0,
    y: 0,
    taskId: null,
  });

  // PWA Install hook
  const { isInstallable, isInstalled, isIOS, install: triggerInstall } = usePWAInstall();

  // Toast helper
  const showNotification = useCallback(
    (title: string, text: string, type: 'info' | 'success' | 'warning' = 'info') => {
      const id = Date.now() + Math.floor(Math.random() * 1000);
      setToasts((prev) => [...prev, { id, title, text, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4500);
    },
    []
  );

  // Confirm bottom-sheet helper
  const openConfirmModal = useCallback(
    (
      title: string,
      message: string,
      onConfirm: () => void,
      icon = '✨',
      yesLabel = 'بله، ادامه بده'
    ) => {
      triggerHaptic(15);
      setConfirmModal({
        isOpen: true,
        title,
        message,
        icon,
        yesLabel,
        onConfirm,
      });
    },
    []
  );

  const closeConfirmModal = useCallback(
    (confirmed: boolean) => {
      if (confirmed && confirmModal.onConfirm) {
        triggerHaptic([15, 40, 20]);
        confirmModal.onConfirm();
      }
      setConfirmModal((prev) => ({ ...prev, isOpen: false, onConfirm: null }));
    },
    [confirmModal]
  );

  // Confetti Celebration helper
  const launchCelebration = useCallback(
    (type: 'goal' | 'habit', title: string) => {
      const colors =
        type === 'goal'
          ? ['#fbbf24', '#fde047', '#f59e0b', '#a855f7', '#38bdf8', '#10b981']
          : ['#10b981', '#34d399', '#2dd4bf', '#38bdf8', '#fbbf24', '#818cf8'];

      for (let i = 0; i < 24; i++) {
        const piece = document.createElement('div');
        piece.className = 'confetti-piece';
        const startX = window.innerWidth * (0.2 + Math.random() * 0.6);
        const startY = window.innerHeight * 0.35;
        const tx = (Math.random() - 0.5) * 340 + 'px';
        const ty = 120 + Math.random() * 280 + 'px';
        const rot = (Math.random() - 0.5) * 720 + 'deg';
        piece.style.left = startX + 'px';
        piece.style.top = startY + 'px';
        piece.style.background = colors[i % colors.length];
        piece.style.setProperty('--tx', tx);
        piece.style.setProperty('--ty', ty);
        piece.style.setProperty('--rot', rot);
        document.body.appendChild(piece);
        setTimeout(() => piece.remove(), 1450);
      }

      if (type === 'goal') {
        showNotification('👑 فتح قله جدید!', `تبریک! «${title}» در تالار افتخارات ثبت شد.`, 'success');
      } else {
        showNotification('🏅 عادت پایدار ساخته شد!', `آفرین! عادت «${title}» با موفقیت تثبیت شد.`, 'success');
      }
    },
    [showNotification]
  );

  // Apply 6 themes to body & html
  useEffect(() => {
    const valid = VALID_THEMES.includes(theme) ? theme : 'dark';
    VALID_THEMES.forEach((t) => {
      document.body.classList.remove('theme-' + t);
      document.documentElement.classList.remove('theme-' + t);
    });
    document.body.classList.add('theme-' + valid);
    document.documentElement.classList.add('theme-' + valid);
    safeStorageSet('glass_todo_theme', valid);
  }, [theme]);

  // Persist states to localStorage
  useEffect(() => {
    safeStorageSet('glass_todo_tasks_v7', tasksData);
  }, [tasksData]);

  useEffect(() => {
    safeStorageSet('glass_todo_notes_v7', notesData);
  }, [notesData]);

  useEffect(() => {
    safeStorageSet('glass_todo_goals_v2', goalsData);
  }, [goalsData]);

  useEffect(() => {
    safeStorageSet('glass_todo_habits_v1', habitsData);
  }, [habitsData]);

  useEffect(() => {
    safeStorageSet('glass_todo_custom_reminders_v1', customReminders);
  }, [customReminders]);

  useEffect(() => {
    safeStorageSet('glass_todo_alarm_settings_v1', alarmSettings);
  }, [alarmSettings]);

  useEffect(() => {
    safeStorageSet('glass_todo_fired_alarms_v1', firedRegistry);
  }, [firedRegistry]);

  // Initialize today's weekly accordion card expanded by default
  useEffect(() => {
    const todayKey = getDateKey(...getTodayJalali());
    setExpandedWeeklyDays((prev) => ({ ...prev, [todayKey]: true }));
  }, []);

  // Synchronize habits into tasksData across their duration & deferrals
  const syncAllHabitTasks = useCallback(
    (currentHabits: HabitItem[], currentTasks: TasksByDate): TasksByDate => {
      let mutated = false;
      const nextTasks: TasksByDate = { ...currentTasks };

      currentHabits.forEach((h) => {
        if (!h.tasks || h.tasks.length === 0) return;
        const totalSpan = h.duration + (h.deferrals || 0);
        const habitDays = h.activeDays || [0, 1, 2, 3, 4, 5, 6];

        for (let i = 0; i < totalSpan; i++) {
          const iso = addDaysToIso((h.startIso || jalaliToIso(...getTodayJalali())), i);
          const [jy, jm, jd] = isoToJalali(iso);
          const dKey = getDateKey(jy, jm, jd);
          const dayOfWeek = getDayOfWeek(jy, jm, jd);

          if (!habitDays.includes(dayOfWeek)) continue;

          const dayList = nextTasks[dKey] ? [...nextTasks[dKey]] : [];
          let dayChanged = false;

          h.tasks.forEach((ht) => {
            const taskDays = ht.activeDays || [0, 1, 2, 3, 4, 5, 6];
            if (!taskDays.includes(dayOfWeek)) return;
            if (ht.excludedDates && ht.excludedDates.includes(dKey)) return;

            const exists = dayList.some(
              (t) => t.habitId === h.id && t.habitTaskId === ht.id
            );
            if (!exists) {
              dayList.push({
                id: Date.now() + Math.floor(Math.random() * 1000000),
                text: `🔁 ${ht.text} (${h.name})`,
                slot: ht.slot || 'morning',
                priority: 'habit',
                time: ht.time || '',
                completed: false,
                habitId: h.id,
                habitTaskId: ht.id,
                isDeferred: i >= h.duration,
                alarmEnabled: Boolean(ht.time),
                reminderMinutesBefore: alarmSettings.defaultAdvanceMinutes,
              });
              dayChanged = true;
              mutated = true;
            }
          });

          if (dayChanged) {
            nextTasks[dKey] = dayList;
          }
        }
      });

      return mutated ? nextTasks : currentTasks;
    },
    [alarmSettings.defaultAdvanceMinutes]
  );

  // Run habit sync on mount & when habitsData changes
  useEffect(() => {
    setTasksData((prev) => syncAllHabitTasks(habitsData, prev));
  }, [habitsData, syncAllHabitTasks]);

  // Trigger alarm modal + audio + notification
  const triggerAlarmPayload = useCallback(
    (payload: ActiveAlarmPayload, shouldRingAudio: boolean, shouldSendNotif: boolean) => {
      if (shouldSendNotif && alarmSettings.notificationsEnabled) {
        sendAndroidNotification(payload.title, payload.subtitle, payload.id);
      }
      if (shouldRingAudio) {
        setActiveAlarm(payload);
        startAlarmLoop(payload.tone, alarmSettings.volume, alarmSettings.vibrationEnabled);
      } else {
        showNotification(payload.title, payload.subtitle, 'warning');
      }
    },
    [alarmSettings, showNotification]
  );

  // Real-time background alarm & reminder checker (every 10 seconds)
  useEffect(() => {
    const checkDue = () => {
      const now = new Date();
      const todayKey = getDateKey(...getTodayJalali());
      const todayList = tasksData[todayKey] || [];
      const cleanedHistory = pruneFiredHistory(firedRegistry, now.getTime());

      const { payloads, nextFiredKeys } = evaluateDueAlarms(
        now,
        todayKey,
        todayList,
        customReminders,
        alarmSettings,
        cleanedHistory
      );

      if (nextFiredKeys.length > 0) {
        const updatedRegistry = { ...cleanedHistory };
        nextFiredKeys.forEach((k) => {
          updatedRegistry[k] = now.getTime();
        });
        setFiredRegistry(updatedRegistry);

        payloads.forEach((p) => {
          if (p.sourceType === 'custom_reminder' && p.reminderId) {
            const rem = customReminders.find((r) => r.id === p.reminderId);
            const shouldAudio = rem ? rem.alertMode === 'both' || rem.alertMode === 'alarm' : true;
            const shouldNotif = rem
              ? rem.alertMode === 'both' || rem.alertMode === 'notification'
              : true;
            triggerAlarmPayload(p, shouldAudio, shouldNotif);
          } else {
            const isExactAlarm = p.id.startsWith('task-exact-');
            triggerAlarmPayload(p, isExactAlarm, true);
          }
        });
      }
    };

    checkDue();
    const intervalId = window.setInterval(checkDue, 10000);
    return () => window.clearInterval(intervalId);
  }, [tasksData, customReminders, alarmSettings, firedRegistry, triggerAlarmPayload]);

  // Focus Mode Pomodoro Countdown Effect
  useEffect(() => {
    if (!focusTimerRunning) {
      if (focusTimerIntervalRef.current) {
        window.clearInterval(focusTimerIntervalRef.current);
        focusTimerIntervalRef.current = null;
      }
      return;
    }

    focusTimerIntervalRef.current = window.setInterval(() => {
      setFocusTimerRemaining((prev) => {
        if (prev <= 1) {
          setFocusTimerRunning(false);
          triggerHaptic([30, 60, 40, 60, 80]);
          launchCelebration('goal', 'تایمر تمرکز عمیق');
          const now = new Date();
          const hh = String(now.getHours()).padStart(2, '0');
          const mm = String(now.getMinutes()).padStart(2, '0');
          triggerAlarmPayload(
            {
              id: `focus-done-${Date.now()}`,
              title: '🎉 زمان تمرکز به پایان رسید!',
              subtitle: 'خسته نباشی قهرمان! یک نوبت تمرکز عمیق رو با موفقیت کامل کردی.',
              timeLabel: `${hh}:${mm}`,
              tone: alarmSettings.defaultTone,
              sourceType: 'focus_timer',
            },
            true,
            true
          );
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (focusTimerIntervalRef.current) {
        window.clearInterval(focusTimerIntervalRef.current);
      }
    };
  }, [focusTimerRunning, alarmSettings.defaultTone, launchCelebration, triggerAlarmPayload]);

  // Dismiss or Snooze Active Alarm
  const handleDismissAlarm = () => {
    stopAlarmLoop();
    setActiveAlarm(null);
  };

  const handleSnoozeAlarm = (minutes: number) => {
    if (!activeAlarm) return;
    const snoozedCopy = { ...activeAlarm };
    stopAlarmLoop();
    setActiveAlarm(null);
    showNotification(
      '💤 تعویق آلارم (Snooze)',
      `این آلارم ${toPersianDigits(minutes)} دقیقه دیگر دوباره زنگ خواهد زد.`,
      'info'
    );
    window.setTimeout(() => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      triggerAlarmPayload(
        {
          ...snoozedCopy,
          id: `${snoozedCopy.id}-snooze-${Date.now()}`,
          timeLabel: `${hh}:${mm}`,
        },
        true,
        true
      );
    }, minutes * 60 * 1000);
  };

  const handleCompleteTaskFromAlarm = () => {
    if (!activeAlarm || !activeAlarm.taskId || !activeAlarm.dateKey) {
      handleDismissAlarm();
      return;
    }
    const dKey = activeAlarm.dateKey;
    const tId = activeAlarm.taskId;
    setTasksData((prev) => {
      const list = prev[dKey] || [];
      return {
        ...prev,
        [dKey]: list.map((t) => (t.id === tId ? { ...t, completed: true } : t)),
      };
    });
    handleDismissAlarm();
    showNotification('آفرین!', 'تسک با موفقیت انجام شد و آلارم بسته شد.', 'success');
  };

  // Request Android System Notification Permission
  const requestAndroidNotificationPermission = async () => {
    if (!('Notification' in window)) {
      showNotification('عدم پشتیبانی', 'مرورگر فعلی از نوتیفیکیشن سیستم پشتیبانی نمی‌کند.', 'warning');
      return;
    }
    try {
      const perm = await Notification.requestPermission();
      setNotificationPermission(perm);
      if (perm === 'granted') {
        showNotification(
          'مجوز فعال شد!',
          'نوتیفیکیشن‌های اندروید با موفقیت فعال شدند.',
          'success'
        );
        sendAndroidNotification(
          'VitTo Do Mobile فعال شد 🎉',
          'سیستم نوتیفیکیشن و آلارم هوشمند آماده یادآوری تسک‌های شماست.'
        );
      } else {
        showNotification(
          'مجوز رد شد',
          'در صورت نیاز می‌توانید از تنظیمات مرورگر کروم مجوز Notification را فعال کنید.',
          'warning'
        );
      }
    } catch {
      showNotification('خطا', 'درخواست مجوز نوتیفیکیشن با مشکل مواجه شد.', 'warning');
    }
  };

  // Instant Test Alarm & Notification
  const handleTestAlarmAndNotification = () => {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    triggerAlarmPayload(
      {
        id: `test-alarm-${Date.now()}`,
        title: '🔔 تست آلارم و نوتیفیکیشن اندروید',
        subtitle: 'سیستم صوتی، لرزش (Vibration) و اعلان VitTo Do Mobile به درستی کار می‌کند!',
        timeLabel: `${hh}:${mm}`,
        tone: alarmSettings.defaultTone,
        sourceType: 'test',
      },
      true,
      true
    );
  };

  // Greeting & Header Info
  const nowHour = new Date().getHours();
  let greetMsg = 'روزت بخیر';
  let greetEmoji = '☀️';
  if (nowHour >= 5 && nowHour < 11) {
    greetMsg = 'صبحت بخیر';
    greetEmoji = '🌅';
  } else if (nowHour >= 11 && nowHour < 16) {
    greetMsg = 'ظهرت بخیر';
    greetEmoji = '☀️';
  } else if (nowHour >= 16 && nowHour < 20) {
    greetMsg = 'عصرت بخیر';
    greetEmoji = '🌇';
  } else {
    greetMsg = 'شبت بخیر';
    greetEmoji = '🌙';
  }

  const [ty, tm, td] = getTodayJalali();
  const todayDow = getDayOfWeek(ty, tm, td);
  const headerDateText = `امروز: ${weekDays[todayDow]} ${toPersianDigits(td)} ${persianMonths[tm - 1]} ${toPersianDigits(ty)}`;

  const selectedDateKey = getDateKey(...selectedDay);
  const selectedDayDow = getDayOfWeek(...selectedDay);
  const currentDayLabelText = `${weekDays[selectedDayDow]} ${toPersianDigits(selectedDay[2])} ${persianMonths[selectedDay[1] - 1]}`;

  // Mobile FAB Quick Action
  const handleMobileFabClick = () => {
    triggerHaptic(18);
    if (activeTab === 'goals') {
      if (goalsSubTab === 'habits') {
        habitInputRef.current?.focus();
      } else {
        setGoalsSubTab('goals');
        setTimeout(() => goalInputRef.current?.focus(), 80);
      }
      return;
    }
    if (activeTab === 'reminders') {
      const el = document.getElementById('custom-rem-title');
      if (el) el.focus();
      return;
    }
    setActiveTab('tasks');
    setIsTaskComposerOpen(true);
    setTimeout(() => {
      taskInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      taskInputRef.current?.focus();
    }, 120);
  };

  // Add Daily Task
  const handleAddTask = () => {
    const cleanText = taskInput.trim();
    if (!cleanText) return;

    const newTask: TaskItem = {
      id: Date.now(),
      text: cleanText,
      slot: taskSlot,
      priority: taskPriority,
      time: taskTime,
      completed: false,
      alarmEnabled: taskTime ? taskAlarmEnabled : false,
      reminderMinutesBefore: taskReminderMin,
    };

    setTasksData((prev) => ({
      ...prev,
      [selectedDateKey]: [...(prev[selectedDateKey] || []), newTask],
    }));

    setTaskInput('');
    setTaskTime('');
    setIsTaskComposerOpen(false);
    triggerHaptic(15);
    showNotification(
      'تسک ثبت شد ✨',
      taskTime
        ? `«${cleanText}» برای ساعت ${toPersianDigits(taskTime)} با آلارم فعال ثبت شد.`
        : `«${cleanText}» به لیست برنامه روزانه اضافه شد.`,
      'success'
    );
  };

  // Toggle Task Completion
  const handleToggleTask = (dateKey: string, taskId: number) => {
    triggerHaptic(15);
    let toggledGoalId: number | undefined;
    let toggledGoalTaskId: number | undefined;
    let nextCompletedState = false;

    setTasksData((prev) => {
      const list = prev[dateKey] || [];
      const updated = list.map((t) => {
        if (t.id === taskId) {
          nextCompletedState = !t.completed;
          toggledGoalId = t.goalId;
          toggledGoalTaskId = t.goalTaskId;
          return { ...t, completed: nextCompletedState };
        }
        return t;
      });
      return { ...prev, [dateKey]: updated };
    });

    if (toggledGoalId && toggledGoalTaskId) {
      setGoalsData((prev) =>
        prev.map((g) => {
          if (g.id !== toggledGoalId) return g;
          return {
            ...g,
            tasks: g.tasks.map((gt) =>
              gt.id === toggledGoalTaskId ? { ...gt, completed: nextCompletedState } : gt
            ),
          };
        })
      );
    }
  };

  // Cycle Task Slot (morning -> afternoon -> night -> morning)
  const handleCycleTaskSlot = (dateKey: string, taskId: number) => {
    triggerHaptic(12);
    const order: TaskSlot[] = ['morning', 'afternoon', 'night'];
    setTasksData((prev) => {
      const list = prev[dateKey] || [];
      const target = list.find((t) => t.id === taskId);
      if (!target) return prev;
      const nextSlot = order[(order.indexOf(target.slot) + 1) % order.length];
      showNotification('تغییر نوبت زمانی', `تسک به بخش «${slotLabels[nextSlot]}» منتقل شد.`, 'info');
      return {
        ...prev,
        [dateKey]: list.map((t) => (t.id === taskId ? { ...t, slot: nextSlot } : t)),
      };
    });
  };

  // Delete Task (with Habit Compensation logic)
  const handleDeleteTask = (dateKey: string, taskId: number, permanent = false) => {
    const list = tasksData[dateKey] || [];
    const task = list.find((t) => t.id === taskId);
    if (!task) return;

    if (task.habitId && !permanent) {
      const h = habitsData.find((x) => x.id === task.habitId);
      if (h) {
        const nextHabits = habitsData.map((item) => {
          if (item.id !== h.id) return item;
          const updatedSubtasks = item.tasks.map((st) => {
            if (st.id !== task.habitTaskId) return st;
            const excluded = st.excludedDates ? [...st.excludedDates] : [];
            if (!excluded.includes(dateKey)) excluded.push(dateKey);
            return { ...st, excludedDates: excluded };
          });
          return { ...item, tasks: updatedSubtasks };
        });

        const totalSpan = h.duration + (h.deferrals || 0);
        const compIso = addDaysToIso((h.startIso || jalaliToIso(...getTodayJalali())), totalSpan);
        const [cy, cm, cd] = isoToJalali(compIso);
        const compKey = getDateKey(cy, cm, cd);
        const ht = h.tasks.find((x) => x.id === task.habitTaskId);

        setHabitsData(nextHabits);
        setTasksData((prev) => {
          const filteredDay = (prev[dateKey] || []).filter((t) => t.id !== taskId);
          const compList = prev[compKey] ? [...prev[compKey]] : [];
          if (ht && !compList.some((t) => t.habitId === h.id && t.habitTaskId === ht.id)) {
            compList.push({
              id: Date.now() + Math.floor(Math.random() * 100000),
              text: `🔁 ${ht.text} (${h.name})`,
              slot: ht.slot || 'morning',
              priority: 'habit',
              time: ht.time || '',
              completed: false,
              habitId: h.id,
              habitTaskId: ht.id,
              isDeferred: true,
            });
          }
          return {
            ...prev,
            [dateKey]: filteredDay,
            [compKey]: compList,
          };
        });

        showNotification(
          'روز جبرانی ثبت شد',
          `تسک «${task.text}» به پایان دوره عادت منتقل شد.`,
          'warning'
        );
        return;
      }
    }

    if (task.habitId && permanent) {
      setHabitsData((prev) =>
        prev.map((item) => {
          if (item.id !== task.habitId) return item;
          return {
            ...item,
            tasks: item.tasks.map((st) => {
              if (st.id !== task.habitTaskId) return st;
              const excluded = st.excludedDates ? [...st.excludedDates] : [];
              if (!excluded.includes(dateKey)) excluded.push(dateKey);
              return { ...st, excludedDates: excluded };
            }),
          };
        })
      );
    }

    setTasksData((prev) => ({
      ...prev,
      [dateKey]: (prev[dateKey] || []).filter((t) => t.id !== taskId),
    }));
  };

  // Touch Swipe handlers on Task Items
  const handleTaskTouchStart = (e: React.TouchEvent, taskId: number) => {
    if (!e.touches || e.touches.length !== 1) return;
    touchStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
      taskId,
    };
  };

  const handleTaskTouchEnd = (e: React.TouchEvent, dateKey: string, taskId: number) => {
    if (touchStartRef.current.taskId !== taskId || !e.changedTouches || e.changedTouches.length !== 1) {
      return;
    }
    const dx = e.changedTouches[0].clientX - touchStartRef.current.x;
    const dy = Math.abs(e.changedTouches[0].clientY - touchStartRef.current.y);
    touchStartRef.current.taskId = null;

    if (dy > 50) return;
    if (dx > 65) {
      handleToggleTask(dateKey, taskId);
    } else if (dx < -65) {
      handleDeleteTask(dateKey, taskId, false);
    }
  };

  // Toggle per-task exact alarm
  const handleToggleTaskAlarm = (dateKey: string, taskId: number) => {
    setTasksData((prev) => {
      const list = prev[dateKey] || [];
      return {
        ...prev,
        [dateKey]: list.map((t) => {
          if (t.id !== taskId) return t;
          const current =
            t.alarmEnabled !== undefined ? t.alarmEnabled : alarmSettings.triggerExactTimeAlarm;
          return { ...t, alarmEnabled: !current };
        }),
      };
    });
  };

  const handleUpdateTaskReminderMinutes = (dateKey: string, taskId: number, minutes: number) => {
    setTasksData((prev) => {
      const list = prev[dateKey] || [];
      return {
        ...prev,
        [dateKey]: list.map((t) =>
          t.id === taskId ? { ...t, reminderMinutesBefore: minutes } : t
        ),
      };
    });
  };

  // Add Daily Prayers
  const handleAddPrayerTasks = () => {
    const prayers: Array<{ text: string; slot: TaskSlot; time: string }> = [
      { text: '🕌 نماز صبح', slot: 'morning', time: '05:15' },
      { text: '🕌 نماز ظهر و عصر', slot: 'afternoon', time: '12:30' },
      { text: '🕌 نماز مغرب و عشاء', slot: 'night', time: '18:45' },
    ];
    const existing = tasksData[selectedDateKey] || [];
    const toAdd: TaskItem[] = [];

    prayers.forEach((p, idx) => {
      if (!existing.some((t) => t.text === p.text)) {
        toAdd.push({
          id: Date.now() + idx,
          text: p.text,
          slot: p.slot,
          priority: 'prayer',
          time: p.time,
          completed: false,
          alarmEnabled: true,
          reminderMinutesBefore: 10,
        });
      }
    });

    if (toAdd.length === 0) {
      showNotification('توجه', 'نمازهای این روز قبلاً به لیست اضافه شده‌اند.', 'info');
      return;
    }

    setTasksData((prev) => ({
      ...prev,
      [selectedDateKey]: [...(prev[selectedDateKey] || []), ...toAdd],
    }));
    triggerHaptic([15, 30, 15]);
    showNotification(
      'التماس دعا 🕌',
      `${toPersianDigits(toAdd.length)} وعده نماز همراه با یادآور به برنامه اضافه شد.`,
      'success'
    );
  };

  // Notes handlers
  const handleAddNote = () => {
    const clean = noteInput.trim();
    if (!clean) return;
    setNotesData((prev) => ({
      ...prev,
      [selectedDateKey]: [...(prev[selectedDateKey] || []), { id: Date.now(), text: clean }],
    }));
    setNoteInput('');
    setNotesOpen(true);
  };

  const handleDeleteNote = (noteId: number) => {
    setNotesData((prev) => ({
      ...prev,
      [selectedDateKey]: (prev[selectedDateKey] || []).filter((n) => n.id !== noteId),
    }));
  };

  // Goals handlers
  const handleAddGoal = () => {
    const clean = newGoalTitle.trim();
    if (!clean) return;
    const newGoal: GoalItem = {
      id: Date.now(),
      title: clean,
      emoji: newGoalEmoji,
      tasks: [],
      completed: false,
      completedAt: null,
    };
    setGoalsData((prev) => [...prev, newGoal]);
    setNewGoalTitle('');
    showNotification('هدف جدید ثبت شد 🎯', `هدف «${clean}» با موفقیت ساخته شد.`, 'success');
  };

  const handleDeleteGoal = (goalId: number) => {
    const g = goalsData.find((x) => x.id === goalId);
    openConfirmModal(
      'حذف هدف',
      `آیا از حذف هدف «${g ? g.title : ''}» مطمئن هستید؟`,
      () => {
        setGoalsData((prev) => prev.filter((x) => x.id !== goalId));
      },
      '🗑️',
      'بله، حذف شود'
    );
  };

  const handleCompleteGoal = (goalId: number) => {
    const g = goalsData.find((x) => x.id === goalId);
    if (!g) return;
    openConfirmModal(
      'ثبت در تالار افتخارات 🏆',
      `آیا هدف «${g.title}» را کامل کرده‌اید و می‌خواهید در تالار افتخارات ثبت شود؟`,
      () => {
        const [jy, jm, jd] = getTodayJalali();
        const completedDateStr = `${toPersianDigits(jd)} ${persianMonths[jm - 1]} ${toPersianDigits(jy)}`;
        setGoalsData((prev) =>
          prev.map((item) =>
            item.id === goalId
              ? {
                  ...item,
                  completed: true,
                  completedAt: completedDateStr,
                  tasks: item.tasks.map((t) => ({ ...t, completed: true })),
                }
              : item
          )
        );
        launchCelebration('goal', g.title);
      },
      '👑',
      'بله، فتح شد!'
    );
  };

  const handleRestoreGoal = (goalId: number) => {
    setGoalsData((prev) =>
      prev.map((g) => (g.id === goalId ? { ...g, completed: false, completedAt: null } : g))
    );
    showNotification('بازگردانی هدف', 'هدف به لیست اهداف فعال بازگردانده شد.', 'info');
  };

  const handleAddGoalSubtask = (goalId: number) => {
    const text = (goalSubtaskInputs[goalId] || '').trim();
    if (!text) return;
    setGoalsData((prev) =>
      prev.map((g) =>
        g.id === goalId
          ? { ...g, tasks: [...g.tasks, { id: Date.now(), text, completed: false }] }
          : g
      )
    );
    setGoalSubtaskInputs((prev) => ({ ...prev, [goalId]: '' }));
  };

  const handleToggleGoalSubtask = (goalId: number, subtaskId: number) => {
    let nextState = false;
    setGoalsData((prev) =>
      prev.map((g) => {
        if (g.id !== goalId) return g;
        return {
          ...g,
          tasks: g.tasks.map((t) => {
            if (t.id === subtaskId) {
              nextState = !t.completed;
              return { ...t, completed: nextState };
            }
            return t;
          }),
        };
      })
    );

    setTasksData((prev) => {
      const next: TasksByDate = {};
      Object.keys(prev).forEach((dKey) => {
        next[dKey] = prev[dKey].map((t) =>
          t.goalId === goalId && t.goalTaskId === subtaskId ? { ...t, completed: nextState } : t
        );
      });
      return next;
    });
  };

  const handleDeleteGoalSubtask = (goalId: number, subtaskId: number) => {
    setGoalsData((prev) =>
      prev.map((g) =>
        g.id === goalId ? { ...g, tasks: g.tasks.filter((t) => t.id !== subtaskId) } : g
      )
    );
  };

  const handleTransferGoalTaskToToday = (goalId: number, subtaskId: number) => {
    const g = goalsData.find((x) => x.id === goalId);
    const gt = g?.tasks.find((x) => x.id === subtaskId);
    if (!g || !gt) return;

    const slotKey = `${goalId}_${subtaskId}`;
    const chosenSlot: TaskSlot = goalTransferSlots[slotKey] || 'morning';
    const existing = tasksData[selectedDateKey] || [];

    if (existing.some((t) => t.goalId === goalId && t.goalTaskId === subtaskId)) {
      showNotification('توجه', 'این گام قبلاً به برنامه این روز اضافه شده است.', 'warning');
      return;
    }

    const newTask: TaskItem = {
      id: Date.now(),
      text: `${g.emoji || '🎯'} ${gt.text} (${g.title})`,
      slot: chosenSlot,
      priority: 'goal',
      time: '',
      completed: gt.completed,
      goalId: g.id,
      goalTaskId: gt.id,
    };

    setTasksData((prev) => ({
      ...prev,
      [selectedDateKey]: [...(prev[selectedDateKey] || []), newTask],
    }));
    showNotification(
      'انتقال موفق ✨',
      `گام «${gt.text}» به بخش ${slotLabels[chosenSlot]} اضافه شد.`,
      'success'
    );
  };

  // Habits handlers
  const handleAddHabit = () => {
    const clean = newHabitName.trim();
    if (!clean) return;
    const dur = Math.max(1, Math.min(365, Number(newHabitDuration) || 66));
    const startIso = jalaliToIso(...getTodayJalali());

    const newHabit: HabitItem = {
      id: Date.now(),
      name: clean,
      duration: dur,
      startIso,
      deferrals: 0,
      tasks: [],
      activeDays: [0, 1, 2, 3, 4, 5, 6],
    };

    setHabitsData((prev) => [...prev, newHabit]);
    setNewHabitName('');
    showNotification('عادت جدید ساخته شد 🔁', `عادت «${clean}» برای ${toPersianDigits(dur)} روز ایجاد شد.`, 'success');
  };

  const handleCompleteHabitManual = (habitId: number) => {
    const h = habitsData.find((x) => x.id === habitId);
    if (!h) return;
    openConfirmModal(
      'تثبیت عادت در تالار افتخارات 🏅',
      `آیا عادت «${h.name}» در سبک زندگی شما تثبیت شده و می‌خواهید به تالار افتخارات منتقل شود؟`,
      () => {
        const [jy, jm, jd] = getTodayJalali();
        const completedDateStr = `${toPersianDigits(jd)} ${persianMonths[jm - 1]} ${toPersianDigits(jy)}`;
        setHabitsData((prev) =>
          prev.map((item) =>
            item.id === habitId
              ? { ...item, completed: true, completedAt: completedDateStr }
              : item
          )
        );
        launchCelebration('habit', h.name);
      },
      '🏅',
      'بله، تثبیت شد!'
    );
  };

  const handleRestoreCompletedHabit = (habitId: number) => {
    const todayIso = jalaliToIso(...getTodayJalali());
    setHabitsData((prev) =>
      prev.map((h) =>
        h.id === habitId
          ? { ...h, completed: false, completedAt: null, startIso: todayIso, deferrals: 0 }
          : h
      )
    );
    showNotification('بازگردانی عادت 🔁', 'عادت مجدداً در لیست عادت‌های فعال قرار گرفت.', 'info');
  };

  const handleDeleteHabit = (habitId: number) => {
    const h = habitsData.find((x) => x.id === habitId);
    openConfirmModal(
      'حذف عادت و تسک‌ها',
      `آیا از حذف کامل عادت «${h ? h.name : ''}» مطمئن هستید؟`,
      () => {
        setHabitsData((prev) => prev.filter((x) => x.id !== habitId));
        setTasksData((prev) => {
          const next: TasksByDate = {};
          Object.keys(prev).forEach((dKey) => {
            next[dKey] = prev[dKey].filter((t) => t.habitId !== habitId);
          });
          return next;
        });
      },
      '🗑️',
      'بله، حذف شود'
    );
  };

  const handleToggleHabitDay = (habitId: number, dayIndex: number) => {
    setHabitsData((prev) =>
      prev.map((h) => {
        if (h.id !== habitId) return h;
        const currentDays = h.activeDays ? [...h.activeDays] : [0, 1, 2, 3, 4, 5, 6];
        const idx = currentDays.indexOf(dayIndex);
        if (idx > -1) {
          if (currentDays.length <= 1) {
            showNotification('توجه', 'حداقل یک روز در هفته باید فعال باشد!', 'warning');
            return h;
          }
          currentDays.splice(idx, 1);
        } else {
          currentDays.push(dayIndex);
          currentDays.sort();
        }
        return { ...h, activeDays: currentDays };
      })
    );
  };

  const handleToggleHabitSubTaskDay = (habitId: number, subTaskId: number, dayIndex: number) => {
    setHabitsData((prev) =>
      prev.map((h) => {
        if (h.id !== habitId) return h;
        return {
          ...h,
          tasks: h.tasks.map((st) => {
            if (st.id !== subTaskId) return st;
            const days = st.activeDays ? [...st.activeDays] : [0, 1, 2, 3, 4, 5, 6];
            const idx = days.indexOf(dayIndex);
            if (idx > -1) {
              if (days.length <= 1) {
                showNotification('توجه', 'حداقل یک روز باید برای این تسک فعال باشد.', 'warning');
                return st;
              }
              days.splice(idx, 1);
            } else {
              days.push(dayIndex);
              days.sort();
            }
            return { ...st, activeDays: days };
          }),
        };
      })
    );
  };

  const handleAddHabitSubTask = (habitId: number) => {
    const draft = habitNewTaskInputs[habitId] || { text: '', slot: 'morning', time: '' };
    const clean = draft.text.trim();
    if (!clean) return;

    const newSub: HabitSubTask = {
      id: Date.now(),
      text: clean,
      slot: draft.slot || 'morning',
      time: draft.time || '',
      excludedDates: [],
      activeDays: [0, 1, 2, 3, 4, 5, 6],
    };

    setHabitsData((prev) =>
      prev.map((h) => (h.id === habitId ? { ...h, tasks: [...h.tasks, newSub] } : h))
    );
    setHabitNewTaskInputs((prev) => ({
      ...prev,
      [habitId]: { text: '', slot: 'morning', time: '' },
    }));
    showNotification('تسک عادت ثبت شد', `«${clean}» به برنامه روزانه عادت اضافه شد.`, 'success');
  };

  const handleDeleteHabitSubTask = (habitId: number, subTaskId: number) => {
    setHabitsData((prev) =>
      prev.map((h) =>
        h.id === habitId ? { ...h, tasks: h.tasks.filter((st) => st.id !== subTaskId) } : h
      )
    );
    setTasksData((prev) => {
      const next: TasksByDate = {};
      Object.keys(prev).forEach((dKey) => {
        next[dKey] = prev[dKey].filter(
          (t) => !(t.habitId === habitId && t.habitTaskId === subTaskId)
        );
      });
      return next;
    });
  };

  const startEditHabit = (h: HabitItem) => {
    setEditingHabitId(h.id);
    setHabitEditDraft({
      name: h.name,
      duration: h.duration,
      tasks: h.tasks.map((t) => ({
        id: t.id,
        text: t.text,
        slot: t.slot,
        time: t.time || '',
        activeDays: t.activeDays || [0, 1, 2, 3, 4, 5, 6],
      })),
    });
  };

  const saveEditHabit = (habitId: number) => {
    if (!habitEditDraft || !habitEditDraft.name.trim()) return;
    setHabitsData((prev) =>
      prev.map((h) => {
        if (h.id !== habitId) return h;
        const updatedTasks: HabitSubTask[] = habitEditDraft.tasks
          .filter((dt) => dt.text.trim().length > 0)
          .map((dt) => {
            const orig = h.tasks.find((ot) => ot.id === dt.id);
            return {
              id: dt.id,
              text: dt.text.trim(),
              slot: dt.slot,
              time: dt.time,
              excludedDates: orig?.excludedDates || [],
              activeDays: dt.activeDays || [0, 1, 2, 3, 4, 5, 6],
            };
          });
        return {
          ...h,
          name: habitEditDraft.name.trim(),
          duration: Math.max(1, Math.min(365, Number(habitEditDraft.duration) || 66)),
          tasks: updatedTasks,
        };
      })
    );
    setEditingHabitId(null);
    setHabitEditDraft(null);
    showNotification('ذخیره شد ✨', 'تغییرات عادت با موفقیت اعمال شد.', 'success');
  };

  // Personalized Reminders handlers
  const handleAddCustomReminder = (rem: Omit<CustomReminder, 'id'>) => {
    const newRem: CustomReminder = {
      ...rem,
      id: Date.now(),
    };
    setCustomReminders((prev) => [newRem, ...prev]);
    showNotification(
      'یادآور شخصی ثبت شد 🔔',
      `یادآور «${rem.title}» فعال شد و سر موقع آلارم و نوتیفیکیشن ارسال می‌کند.`,
      'success'
    );
  };

  const handleToggleCustomReminder = (id: number) => {
    setCustomReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
  };

  const handleDeleteCustomReminder = (id: number) => {
    setCustomReminders((prev) => prev.filter((r) => r.id !== id));
    showNotification('حذف شد', 'یادآور شخصی حذف شد.', 'info');
  };

  // Backup & Google Drive handlers
  const buildBackupPayload = useCallback(() => {
    return {
      version: 2,
      exportedAt: new Date().toISOString(),
      theme,
      tasksData,
      notesData,
      goalsData,
      habitsData,
      customReminders,
      alarmSettings,
    };
  }, [theme, tasksData, notesData, goalsData, habitsData, customReminders, alarmSettings]);

  const applyBackupPayload = (data: Record<string, unknown>) => {
    if (data.tasksData && typeof data.tasksData === 'object') {
      setTasksData(data.tasksData as TasksByDate);
    }
    if (data.notesData && typeof data.notesData === 'object') {
      setNotesData(data.notesData as NotesByDate);
    }
    if (Array.isArray(data.goalsData)) {
      setGoalsData(data.goalsData as GoalItem[]);
    }
    if (Array.isArray(data.habitsData)) {
      setHabitsData(data.habitsData as HabitItem[]);
    }
    if (Array.isArray(data.customReminders)) {
      setCustomReminders(data.customReminders as CustomReminder[]);
    }
    if (data.alarmSettings && typeof data.alarmSettings === 'object') {
      setAlarmSettings({ ...DEFAULT_ALARM_SETTINGS, ...(data.alarmSettings as AlarmSettings) });
    }
    if (typeof data.theme === 'string' && VALID_THEMES.includes(data.theme as ThemeId)) {
      setTheme(data.theme as ThemeId);
    }
    showNotification('بازیابی موفق! 🎉', 'تمامی اطلاعات پشتیبان با موفقیت بازیابی شد.', 'success');
  };

  const handleDownloadBackup = () => {
    const payload = JSON.stringify(buildBackupPayload(), null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VitToDo-Backup-${getDateKey(...getTodayJalali())}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showNotification('دانلود شد 💾', 'فایل پشتیبان با موفقیت ذخیره شد.', 'success');
  };

  const handleRestoreFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        applyBackupPayload(parsed);
      } catch {
        showNotification('خطا', 'فایل پشتیبان معتبر نیست.', 'warning');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleChooseBackupFile = async () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const win = window as any;
    if (typeof win.showSaveFilePicker !== 'function') {
      showNotification(
        'راهنما',
        'مرورگر شما از اتصال مستقیم فایل پشتیبانی نمی‌کند؛ از دکمه «دانلود پشتیبان» استفاده کنید.',
        'info'
      );
      return;
    }
    try {
      const handle = await win.showSaveFilePicker({
        suggestedName: 'VitToDo-AutoBackup.json',
        types: [{ description: 'JSON Backup', accept: { 'application/json': ['.json'] } }],
      });
      setFileHandle(handle);
      const writable = await handle.createWritable();
      await writable.write(JSON.stringify(buildBackupPayload(), null, 2));
      await writable.close();
      setBackupLastSave(new Date().toLocaleTimeString('fa-IR'));
      showNotification('متصل شد 📁', 'فایل پشتیبان متصل و ذخیره شد.', 'success');
    } catch {
      // User cancelled picker
    }
  };

  // Google Drive Cloud Sync functions
  const saveGDriveConfig = (nextClientId: string, nextToken: string) => {
    setGdriveClientId(nextClientId);
    setGdriveAccessToken(nextToken);
    safeStorageSet('vitodo_gdrive_client_id', nextClientId.trim());
    safeStorageSet('vitodo_gdrive_access_token', nextToken.trim());
  };

  const syncToGoogleDrive = async (manual = false) => {
    if (!gdriveAccessToken) {
      if (manual) {
        showNotification('نیاز به اتصال ☁️', 'ابتدا به Google Drive متصل شوید یا از دکمه «ارسال مستقیم به اپ Google Drive گوشی» استفاده کنید.', 'warning');
      }
      return;
    }
    try {
      const content = JSON.stringify(buildBackupPayload(), null, 2);
      const metadata = { name: 'VitToDo-Cloud-Backup.json', mimeType: 'application/json' };
      let targetId = gdriveFileId;

      if (!targetId) {
        const q = encodeURIComponent("name='VitToDo-Cloud-Backup.json' and trashed=false");
        const searchRes = await fetch(
          `https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name)`,
          { headers: { Authorization: `Bearer ${gdriveAccessToken}` } }
        );
        if (searchRes.ok) {
          const searchData = await searchRes.json();
          if (searchData.files && searchData.files.length > 0) {
            targetId = searchData.files[0].id;
            setGdriveFileId(targetId);
            safeStorageSet('vitodo_gdrive_file_id', targetId);
          }
        }
      }

      const boundary = '-------vitodo_cloud_sync_boundary';
      const multipartBody =
        `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n` +
        JSON.stringify(metadata) +
        `\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n` +
        content +
        `\r\n--${boundary}--`;

      const url = targetId
        ? `https://www.googleapis.com/upload/drive/v3/files/${targetId}?uploadType=multipart`
        : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';

      const res = await fetch(url, {
        method: targetId ? 'PATCH' : 'POST',
        headers: {
          Authorization: `Bearer ${gdriveAccessToken}`,
          'Content-Type': `multipart/related; boundary=${boundary}`,
        },
        body: multipartBody,
      });

      if (!res.ok) throw new Error('Drive API Error');
      const resJson = await res.json();
      if (resJson.id) {
        setGdriveFileId(resJson.id);
        safeStorageSet('vitodo_gdrive_file_id', resJson.id);
      }

      const nowStr = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
      setGdriveLastSync(nowStr);
      safeStorageSet('vitodo_gdrive_last_sync', nowStr);
      if (manual) {
        showNotification('ذخیره ابری موفق ☁️', 'اطلاعات شما در Google Drive به‌روزرسانی شد.', 'success');
      }
    } catch {
      if (manual) {
        showNotification('خطا در اتصال ابری', 'توکن Google Drive منقضی یا نامعتبر است. تنظیمات API را بررسی کنید.', 'warning');
      }
    }
  };

  const restoreFromGoogleDrive = async () => {
    if (!gdriveAccessToken) {
      showNotification('نیاز به اتصال ☁️', 'ابتدا به حساب Google Drive متصل شوید.', 'warning');
      return;
    }
    try {
      let targetId = gdriveFileId;
      if (!targetId) {
        const q = encodeURIComponent("name='VitToDo-Cloud-Backup.json' and trashed=false");
        const searchRes = await fetch(
          `https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name)`,
          { headers: { Authorization: `Bearer ${gdriveAccessToken}` } }
        );
        if (searchRes.ok) {
          const sJson = await searchRes.json();
          if (sJson.files && sJson.files.length > 0) {
            targetId = sJson.files[0].id;
          }
        }
      }
      if (!targetId) {
        showNotification('یافت نشد', 'فایل VitToDo-Cloud-Backup.json در Google Drive شما پیدا نشد.', 'warning');
        return;
      }
      const res = await fetch(`https://www.googleapis.com/drive/v3/files/${targetId}?alt=media`, {
        headers: { Authorization: `Bearer ${gdriveAccessToken}` },
      });
      if (!res.ok) throw new Error('Failed to fetch');
      const parsed = await res.json();
      applyBackupPayload(parsed);
    } catch {
      showNotification('خطا در بازیابی ابری', 'امکان دریافت فایل از Google Drive وجود نداشت.', 'warning');
    }
  };

  const shareBackupToDriveApp = async () => {
    triggerHaptic(18);
    const content = JSON.stringify(buildBackupPayload(), null, 2);
    const fileName = `VitToDo-Cloud-Backup.json`;
    const file = new File([content], fileName, { type: 'application/json' });
    const nav = navigator as Navigator & {
      canShare?: (data: { files: File[] }) => boolean;
    };

    if (nav.canShare && nav.canShare({ files: [file] }) && typeof nav.share === 'function') {
      try {
        await nav.share({
          title: 'پشتیبان ابری VitTo Do',
          text: 'ذخیره مستقیم فایل پشتیبان در Google Drive گوشی',
          files: [file],
        });
        showNotification('ارسال شد ☁️', 'فایل پشتیبان به منوی اشتراک‌گذاری گوشی ارسال شد.', 'success');
        return;
      } catch {
        // Fallback to download if share sheet closed
      }
    }
    handleDownloadBackup();
  };

  // Computed Data for Selected Day
  const rawDayTasks = tasksData[selectedDateKey] || [];
  const filteredDayTasks = rawDayTasks
    .filter((t) => {
      if (currentFilter === 'pending' && t.completed) return false;
      if (currentFilter === 'completed' && !t.completed) return false;
      if (currentFilter === 'high' && t.priority !== 'high') return false;
      if (searchQuery.trim() && !t.text.toLowerCase().includes(searchQuery.trim().toLowerCase())) {
        return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (currentSort === 'time') {
        if (!a.time && !b.time) return 0;
        if (!a.time) return 1;
        if (!b.time) return -1;
        return a.time.localeCompare(b.time);
      }
      if (currentSort === 'priority') {
        return (priorityOrder[a.priority] || 9) - (priorityOrder[b.priority] || 9);
      }
      return b.id - a.id;
    });

  const morningTasks = filteredDayTasks.filter((t) => t.slot === 'morning');
  const afternoonTasks = filteredDayTasks.filter((t) => t.slot === 'afternoon');
  const nightTasks = filteredDayTasks.filter((t) => t.slot === 'night');

  const rawMorningCount = rawDayTasks.filter((t) => t.slot === 'morning').length;
  const rawAfternoonCount = rawDayTasks.filter((t) => t.slot === 'afternoon').length;
  const rawNightCount = rawDayTasks.filter((t) => t.slot === 'night').length;

  const dayTotalCount = rawDayTasks.length;
  const dayCompletedCount = rawDayTasks.filter((t) => t.completed).length;
  const dayProgressPct =
    dayTotalCount === 0 ? 0 : Math.round((dayCompletedCount / dayTotalCount) * 100);

  // Dashboard Metrics
  const todayKey = getDateKey(ty, tm, td);
  const todayTasks = tasksData[todayKey] || [];
  const todayTotal = todayTasks.length;
  const todayCompleted = todayTasks.filter((t) => t.completed).length;
  const todayProgressPct = todayTotal === 0 ? 0 : Math.round((todayCompleted / todayTotal) * 100);

  // Up-Next Priority Tasks on Dashboard (top 3 pending tasks)
  const todayPendingSorted = todayTasks
    .filter((t) => !t.completed)
    .sort((a, b) => {
      const pa = priorityOrder[a.priority] ?? 9;
      const pb = priorityOrder[b.priority] ?? 9;
      if (pa !== pb) return pa - pb;
      return (a.time || '99:99').localeCompare(b.time || '99:99');
    });

  // Missed Prayers across all dates
  const missedPrayersList: Array<{ dateKey: string; dateLabel: string; task: TaskItem }> = [];
  Object.keys(tasksData)
    .sort()
    .forEach((dKey) => {
      const parts = dKey.split('-').map(Number);
      if (parts.length !== 3) return;
      const [jy, jm, jd] = parts as JalaliDateTuple;
      (tasksData[dKey] || []).forEach((t) => {
        if (t.priority === 'prayer' && isPrayerMissed(jy, jm, jd, t)) {
          missedPrayersList.push({
            dateKey: dKey,
            dateLabel: `${toPersianDigits(jd)} ${persianMonths[jm - 1]} ${toPersianDigits(jy)}`,
            task: t,
          });
        }
      });
    });

  // Active vs Completed Goals & Habits
  const activeGoals = goalsData.filter((g) => !g.completed);
  const completedGoals = goalsData.filter((g) => g.completed);
  const activeHabits = habitsData.filter((h) => !isHabitCompleted(h));
  const completedHabits = habitsData.filter((h) => isHabitCompleted(h));

  // Total active alarms count
  const activeCustomRemindersCount = customReminders.filter((r) => r.enabled).length;
  const activeTodayTaskAlarmsCount = todayTasks.filter(
    (t) =>
      !t.completed &&
      Boolean(t.time) &&
      (t.alarmEnabled !== undefined ? t.alarmEnabled : alarmSettings.triggerExactTimeAlarm)
  ).length;

  // Current week's 7 days (Saturday to Friday) for Mobile Date Ribbon & Weekly View
  const currentSelectedIso = jalaliToIso(...selectedDay);
  const currentSelectedDow = getDayOfWeek(...selectedDay);
  const weekStartIso = addDaysToIso(currentSelectedIso, -currentSelectedDow);
  const currentWeekDays = Array.from({ length: 7 }, (_, i) => {
    const iso = addDaysToIso(weekStartIso, i);
    const [jy, jm, jd] = isoToJalali(iso);
    const dKey = getDateKey(jy, jm, jd);
    return {
      tuple: [jy, jm, jd] as JalaliDateTuple,
      dKey,
      dowName: weekDays[i],
      dowShort: weekDaysShort[i],
      dayNum: jd,
      monthName: persianMonths[jm - 1],
      tasks: tasksData[dKey] || [],
    };
  });

  // Past 7 days chart & 30-day streak data
  const todayIso = jalaliToIso(ty, tm, td);
  const weeklyChartBars = Array.from({ length: 7 }, (_, idx) => {
    const offset = idx - 6;
    const iso = addDaysToIso(todayIso, offset);
    const [jy, jm, jd] = isoToJalali(iso);
    const dKey = getDateKey(jy, jm, jd);
    const list = tasksData[dKey] || [];
    const pct =
      list.length === 0
        ? 0
        : Math.round((list.filter((t) => t.completed).length / list.length) * 100);
    const dow = getDayOfWeek(jy, jm, jd);
    return { dKey, label: weekDaysShort[dow], pct };
  });

  const streakDays = Array.from({ length: 30 }, (_, idx) => {
    const offset = idx - 29;
    const iso = addDaysToIso(todayIso, offset);
    const [jy, jm, jd] = isoToJalali(iso);
    const dKey = getDateKey(jy, jm, jd);
    const list = tasksData[dKey] || [];
    const hasCompleted = list.some((t) => t.completed);
    return { dKey, dayNum: jd, monthName: persianMonths[jm - 1], hasCompleted };
  });
  const activeDaysIn30 = streakDays.filter((s) => s.hasCompleted).length;

  // Focus Mode Studio Helpers
  const focusPendingTasks = rawDayTasks
    .filter((t) => !t.completed)
    .sort((a, b) => {
      const pa = priorityOrder[a.priority] ?? 9;
      const pb = priorityOrder[b.priority] ?? 9;
      if (pa !== pb) return pa - pb;
      return (a.time || '99:99').localeCompare(b.time || '99:99');
    });

  const safeFocusIndex =
    focusPendingTasks.length > 0 ? focusCurrentIndex % focusPendingTasks.length : 0;
  const currentFocusTask = focusPendingTasks[safeFocusIndex] || null;
  const currentMindsetQuote =
    FOCUS_MINDSET_QUOTES[safeFocusIndex % FOCUS_MINDSET_QUOTES.length];

  const focusMm = String(Math.floor(focusTimerRemaining / 60)).padStart(2, '0');
  const focusSs = String(focusTimerRemaining % 60).padStart(2, '0');
  const focusCircumference = 490;
  const focusStrokeDashoffset =
    focusTimerTotal > 0
      ? focusCircumference * (1 - focusTimerRemaining / focusTimerTotal)
      : 0;

  const setFocusPreset = (mins: number, label: string) => {
    triggerHaptic(12);
    setFocusTimerRunning(false);
    const cleanMins = Math.max(1, Math.min(180, Math.round(Number(mins) || 25)));
    setFocusTimerTotal(cleanMins * 60);
    setFocusTimerRemaining(cleanMins * 60);
    setFocusModeLabel(label);
  };

  const adjustFocusCustomMinutes = (delta: number) => {
    const curMins = Math.round(focusTimerTotal / 60);
    const nextMins = Math.max(1, Math.min(180, curMins + delta));
    setFocusPreset(nextMins, `⏱️ زمان دلخواه (${toPersianDigits(nextMins)} دقیقه)`);
  };

  const handleSaveFocusBrainDump = () => {
    const val = focusBrainDumpInput.trim();
    if (!val) return;
    triggerHaptic(15);
    setNotesData((prev) => ({
      ...prev,
      [selectedDateKey]: [
        ...(prev[selectedDateKey] || []),
        { id: Date.now(), text: `🧠 [تخلیه ذهنی حین تمرکز]: ${val}` },
      ],
    }));
    setFocusBrainDumpInput('');
    showNotification('ذهنت رها شد ✨', 'فکر مزاحم در یادداشت‌های امروز ذخیره شد؛ به تمرکزت ادامه بده!', 'info');
  };

  return (
    <>
      {/* Thumb-Zone Bottom Navigation Dock */}
      <div className="nav-tabs" role="navigation" aria-label="ناوبری اصلی">
        <button
          type="button"
          className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
          id="btn-dashboard"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('dashboard');
          }}
        >
          <span className="tab-ic">📊</span>
          <span>داشبورد</span>
        </button>
        <button
          type="button"
          className={`tab-btn ${activeTab === 'tasks' ? 'active' : ''}`}
          id="btn-tasks"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('tasks');
          }}
        >
          <span className="tab-ic">📋</span>
          <span>روزانه</span>
        </button>
        <button
          type="button"
          className={`tab-btn ${activeTab === 'weekly' ? 'active' : ''}`}
          id="btn-weekly"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('weekly');
          }}
        >
          <span className="tab-ic">📅</span>
          <span>هفتگی</span>
        </button>
        <button
          type="button"
          className={`tab-btn ${activeTab === 'calendar' ? 'active' : ''}`}
          id="btn-calendar"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('calendar');
          }}
        >
          <span className="tab-ic">🗓️</span>
          <span>تقویم</span>
        </button>
        <button
          type="button"
          className={`tab-btn ${activeTab === 'goals' ? 'active' : ''}`}
          id="btn-goals"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('goals');
          }}
        >
          <span className="tab-ic">🎯</span>
          <span>اهداف</span>
        </button>
        <button
          type="button"
          className={`tab-btn ${activeTab === 'reminders' ? 'active' : ''}`}
          id="btn-reminders"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('reminders');
          }}
        >
          <span className="tab-ic">🔔</span>
          <span>آلارم</span>
        </button>
        <button
          type="button"
          className={`tab-btn ${activeTab === 'backup' ? 'active' : ''}`}
          id="btn-backup"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('backup');
          }}
        >
          <span className="tab-ic">💾</span>
          <span>پشتیبان</span>
        </button>
      </div>

      {/* Floating + Action Button (Mobile Thumb FAB) */}
      <button
        type="button"
        className="mobile-fab"
        onClick={handleMobileFabClick}
        aria-label="افزودن سریع"
      >
        ＋
      </button>

      {/* Main Mobile App Shell (max-width: 480px) */}
      <div className="glass-card">
        {/* Calm Mobile Header + Hidden Theme Drawer */}
        <div className="greeting-panel">
          <div className="mobile-top-row">
            <div>
              <div className="greeting-title" id="greeting-text">
                <span>{greetEmoji}</span>
                <span className="greeting-gradient-text">{greetMsg}، قهرمان!</span>
              </div>
              <div
                className="date-display"
                id="date-text"
                onClick={() => {
                  setSelectedDay(getTodayJalali());
                  setActiveTab('tasks');
                }}
              >
                {headerDateText}
              </div>
            </div>
            <div className="mobile-quick-pills">
              <button
                type="button"
                className={`icon-pill-btn ${isThemeDrawerOpen ? 'active-Spin' : ''}`}
                onClick={() => {
                  triggerHaptic(10);
                  setIsThemeDrawerOpen((p) => !p);
                }}
                title="تغییر تم رنگی"
                aria-label="تغییر تم رنگی"
              >
                🎨
              </button>
              <button
                type="button"
                className="icon-pill-btn"
                onClick={() => {
                  triggerHaptic(10);
                  setIsInstallModalOpen(true);
                }}
                title="نصب اپلیکیشن اندروید"
                aria-label="نصب اپلیکیشن اندروید"
              >
                📱
              </button>
              <button
                type="button"
                className="quick-action-pill focus-pill"
                onClick={() => {
                  triggerHaptic(12);
                  setIsFocusModeOpen(true);
                }}
              >
                🔍 تمرکز
              </button>
              <button
                type="button"
                className="quick-action-pill prayer-pill"
                onClick={handleAddPrayerTasks}
              >
                🕌 نمازها
              </button>
            </div>
          </div>

          <div className={`theme-drawer ${isThemeDrawerOpen ? 'open' : ''}`} id="theme-drawer">
            <div className="theme-drawer-inner">
              <div className="theme-switcher" role="group" aria-label="انتخاب تم">
                <button
                  type="button"
                  className={`theme-btn ${theme === 'light' ? 'active' : ''}`}
                  id="btn-theme-light"
                  onClick={() => setTheme('light')}
                >
                  ☀️ روز
                </button>
                <button
                  type="button"
                  className={`theme-btn ${theme === 'dark' ? 'active' : ''}`}
                  id="btn-theme-dark"
                  onClick={() => setTheme('dark')}
                >
                  🌙 شب
                </button>
                <button
                  type="button"
                  className={`theme-btn ${theme === 'emerald' ? 'active' : ''}`}
                  id="btn-theme-emerald"
                  onClick={() => setTheme('emerald')}
                >
                  <span className="theme-dot" style={{ color: '#10b981', background: '#10b981' }} />
                  زمرد
                </button>
                <button
                  type="button"
                  className={`theme-btn ${theme === 'rose' ? 'active' : ''}`}
                  id="btn-theme-rose"
                  onClick={() => setTheme('rose')}
                >
                  <span className="theme-dot" style={{ color: '#f43f5e', background: '#f43f5e' }} />
                  یاقوت
                </button>
                <button
                  type="button"
                  className={`theme-btn ${theme === 'ocean' ? 'active' : ''}`}
                  id="btn-theme-ocean"
                  onClick={() => setTheme('ocean')}
                >
                  <span className="theme-dot" style={{ color: '#0ea5e9', background: '#0ea5e9' }} />
                  اقیانوس
                </button>
                <button
                  type="button"
                  className={`theme-btn ${theme === 'amber' ? 'active' : ''}`}
                  id="btn-theme-amber"
                  onClick={() => setTheme('amber')}
                >
                  <span className="theme-dot" style={{ color: '#f59e0b', background: '#f59e0b' }} />
                  کهربا
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 1. BENTO COMMAND CENTER DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div id="dashboard-view" className="view-section active">
            <div className="section-header" style={{ marginBottom: '10px' }}>
              <h2>📊 پیشخوان امروز</h2>
              <div className="header-actions">
                <span className="day-badge" id="dashboard-date-label">
                  {weekDays[todayDow]} {toPersianDigits(td)} {persianMonths[tm - 1]}
                </span>
              </div>
            </div>

            {/* 1. Hero Pulse Card + Progress Circle */}
            <div className="dash-hero-card" onClick={() => setActiveTab('tasks')}>
              <div className="dash-hero-info">
                <div className="dash-hero-title">⚡ نبض برنامه امروز</div>
                <div className="dash-hero-sub" id="dash-hero-status-text">
                  {todayTotal === 0
                    ? 'هنوز تسکی برای امروز ثبت نکردی — لمس کن و شروع کن!'
                    : todayCompleted === todayTotal
                    ? '🎉 فوق‌العاده! تمام تسک‌های امروز رو فتح کردی!'
                    : `${toPersianDigits(todayTotal - todayCompleted)} تسک تا تکمیل کامل برنامه امروز باقی مونده`}
                </div>
                <div className="dash-hero-counts">
                  <span className="dash-mini-pill">
                    📋 کل: <b id="stat-tasks-today">{toPersianDigits(todayTotal)}</b>
                  </span>
                  <span className="dash-mini-pill">
                    ✅ انجام‌شده: <b id="stat-completed-today">{toPersianDigits(todayCompleted)}</b>
                  </span>
                  <span
                    className="dash-mini-pill"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveTab('reminders');
                    }}
                  >
                    🔔 آلارم:{' '}
                    <b>{toPersianDigits(activeCustomRemindersCount + activeTodayTaskAlarmsCount)}</b>
                  </span>
                </div>
              </div>
              <div
                className="dash-ring-box"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFocusModeOpen(true);
                }}
                title="ورود به حالت تمرکز"
              >
                <svg viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="rgba(255,255,255,0.12)"
                    strokeWidth="3.4"
                  />
                  <path
                    id="dash-progress-circle"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="var(--success)"
                    strokeWidth="3.4"
                    strokeDasharray={`${todayProgressPct}, 100`}
                    strokeLinecap="round"
                  />
                </svg>
                <span className="dash-ring-val" id="stat-progress-today">
                  {toPersianDigits(todayProgressPct)}%
                </span>
              </div>
            </div>

            {/* 2. Compact 4-item Strip (Goals, Habits, Missed Prayers, Alarms) */}
            <div className="dash-compact-strip">
              <div
                className="dash-strip-item"
                onClick={() => {
                  setActiveTab('goals');
                  setGoalsSubTab('goals');
                }}
              >
                <div className="dash-strip-top">
                  <span className="dash-strip-icon">🎯</span>
                  <span className="dash-strip-val" id="stat-goals-active">
                    {toPersianDigits(activeGoals.length)}
                  </span>
                </div>
                <span className="dash-strip-lbl">اهداف فعال</span>
              </div>
              <div
                className="dash-strip-item"
                onClick={() => {
                  setActiveTab('goals');
                  setGoalsSubTab('habits');
                }}
              >
                <div className="dash-strip-top">
                  <span className="dash-strip-icon">🔁</span>
                  <span className="dash-strip-val" id="stat-habits-active">
                    {toPersianDigits(activeHabits.length)}
                  </span>
                </div>
                <span className="dash-strip-lbl">عادت‌های فعال</span>
              </div>
              <div className="dash-strip-item" onClick={() => setIsMissedPrayersOpen(true)}>
                <div className="dash-strip-top">
                  <span className="dash-strip-icon">🕌</span>
                  <span
                    className="dash-strip-val"
                    id="stat-prayers-missed"
                    style={{
                      color: missedPrayersList.length > 0 ? 'var(--warning)' : 'var(--success)',
                    }}
                  >
                    {toPersianDigits(missedPrayersList.length)}
                  </span>
                </div>
                <span className="dash-strip-lbl">نماز قضا</span>
              </div>
              <div className="dash-strip-item" onClick={() => setActiveTab('reminders')}>
                <div className="dash-strip-top">
                  <span className="dash-strip-icon">⏰</span>
                  <span className="dash-strip-val">
                    {toPersianDigits(activeCustomRemindersCount + activeTodayTaskAlarmsCount)}
                  </span>
                </div>
                <span className="dash-strip-lbl">یادآور فعال</span>
              </div>
            </div>

            {/* 3. Up-Next Priority Tasks Widget */}
            <div className="dash-upnext-card">
              <div className="dash-upnext-header">
                <span className="dash-upnext-title">🔥 اولویت‌های پیش‌روی امروز</span>
                <button
                  type="button"
                  className="btn-advanced"
                  onClick={() => setActiveTab('tasks')}
                  style={{ fontSize: '0.72rem', padding: '3px 8px' }}
                >
                  همه تسک‌ها ◀
                </button>
              </div>
              <div className="dash-upnext-list" id="dash-upnext-list">
                {todayPendingSorted.length === 0 ? (
                  todayTotal > 0 ? (
                    <div
                      style={{
                        textAlign: 'center',
                        padding: '10px',
                        color: 'var(--success)',
                        fontSize: '0.82rem',
                        fontWeight: 800,
                      }}
                    >
                      ✨ عالیه! هیچ کار ناتمامی برای امروز نداری.
                    </div>
                  ) : (
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '8px',
                        padding: '6px 4px',
                      }}
                    >
                      <span
                        style={{
                          fontSize: '0.8rem',
                          color: 'var(--text-muted)',
                          fontWeight: 700,
                        }}
                      >
                        برنامه امروزت هنوز خالیه!
                      </span>
                      <button
                        type="button"
                        className="btn-advanced"
                        onClick={() => {
                          setActiveTab('tasks');
                          setIsTaskComposerOpen(true);
                        }}
                      >
                        + ثبت تسک جدید
                      </button>
                    </div>
                  )
                ) : (
                  todayPendingSorted.slice(0, 3).map((t) => (
                    <div
                      key={t.id}
                      className="dash-upnext-item"
                      onClick={() => handleToggleTask(todayKey, t.id)}
                    >
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px',
                          minWidth: 0,
                          flex: 1,
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={false}
                          onChange={() => {}}
                          style={{ width: '19px', height: '19px', accentColor: 'var(--success)' }}
                        />
                        <span className={`priority-dot priority-dot-${t.priority}`} />
                        <span
                          style={{
                            fontSize: '0.86rem',
                            fontWeight: 800,
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >
                          {t.text}
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px', flexShrink: 0 }}>
                        {t.time && (
                          <span className="task-time">⏰ {toPersianDigits(t.time)}</span>
                        )}
                        <span style={{ fontSize: '0.75rem' }}>{slotEmojis[t.slot]}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* 4. Unified 7-Day Performance & 30-Day Streak Card */}
            <div className="dash-unified-analytics">
              <div className="dash-analytics-head">
                <span className="chart-title" style={{ margin: 0, fontSize: '0.9rem' }}>
                  📈 عملکرد ۷ روز و زنجیره استمرار
                </span>
                <span className="dash-streak-badge" id="dash-active-days-badge">
                  🔥 {toPersianDigits(activeDaysIn30)} روز فعال
                </span>
              </div>
              <div className="bar-chart" id="weekly-chart">
                {weeklyChartBars.map((b) => (
                  <div key={b.dKey} className="bar-wrapper">
                    <div
                      className="bar"
                      style={{ height: `${Math.max(b.pct, 5)}%` }}
                      data-value={`${toPersianDigits(b.pct)}%`}
                    />
                    <span className="bar-label">{b.label}</span>
                  </div>
                ))}
              </div>
              <div className="dash-streak-row">
                <div className="dash-streak-title">
                  <span>نمای ۳۰ روز گذشته</span>
                  <span>سبز = روز فعال</span>
                </div>
                <div
                  id="streak-display"
                  style={{ display: 'grid', gridTemplateColumns: 'repeat(15, 1fr)', gap: '4px' }}
                >
                  {streakDays.map((s) => (
                    <div
                      key={s.dKey}
                      title={`${toPersianDigits(s.dayNum)} ${s.monthName}`}
                      style={{
                        height: '18px',
                        borderRadius: '5px',
                        background: s.hasCompleted
                          ? 'linear-gradient(135deg, #10b981, #059669)'
                          : 'var(--streak-empty)',
                        border: s.hasCompleted
                          ? '1px solid rgba(52, 211, 153, 0.5)'
                          : '1px solid var(--streak-empty-border)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '0.58rem',
                        fontWeight: 800,
                        color: s.hasCompleted ? '#fff' : 'var(--text-subtle)',
                      }}
                    >
                      {toPersianDigits(s.dayNum)}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. DAILY TASKS VIEW (Mobile Date Ribbon + Calm Drawers + Slot Tabs + Swipe) */}
        {activeTab === 'tasks' && (
          <div id="tasks-view" className="view-section active">
            <div className="section-header">
              <h2>📋 برنامه روزانه</h2>
              <div className="header-actions">
                <span className="day-badge" id="current-day-label">
                  {currentDayLabelText}
                </span>
              </div>
            </div>

            {/* 7-Day Mobile Date Ribbon */}
            <div className="mobile-date-ribbon" id="mobile-date-ribbon">
              {currentWeekDays.map((wd) => {
                const isActive = wd.dKey === selectedDateKey;
                const hasTasks = wd.tasks.length > 0;
                return (
                  <div
                    key={wd.dKey}
                    className={`date-pill-item ${isActive ? 'active' : ''} ${
                      hasTasks ? 'has-tasks' : ''
                    }`}
                    onClick={() => {
                      triggerHaptic(8);
                      setSelectedDay(wd.tuple);
                    }}
                  >
                    <span className="dp-dow">{wd.dowShort}</span>
                    <span className="dp-num">{toPersianDigits(wd.dayNum)}</span>
                    <span className="dp-dot" />
                  </div>
                );
              })}
            </div>

            <div className="progress-box">
              <div className="progress-info">
                <span>پیشرفت این روز:</span>
                <span id="progress-text">{toPersianDigits(dayProgressPct)}%</span>
              </div>
              <div className="progress-bar-track">
                <div
                  className="progress-bar-fill"
                  id="progress-bar"
                  style={{ width: `${dayProgressPct}%` }}
                />
              </div>
            </div>

            {/* Calm Toolbar Row */}
            <div className="tasks-toolbar-row">
              <button
                type="button"
                className="btn-calm-compose"
                onClick={() => {
                  triggerHaptic(12);
                  setIsTaskComposerOpen((p) => !p);
                }}
              >
                {isTaskComposerOpen ? '✖ بستن فرم تسک' : '✨ ثبت تسک جدید'}
              </button>
              <button
                type="button"
                className={`btn-calm-search ${isTaskFilterOpen ? 'active' : ''}`}
                id="btn-toggle-filter"
                onClick={() => {
                  triggerHaptic(10);
                  setIsTaskFilterOpen((p) => !p);
                }}
              >
                🔍 فیلتر و جستجو
              </button>
            </div>

            {/* Collapsible Task Composer Drawer */}
            <div
              className={`collapsible-drawer ${isTaskComposerOpen ? 'open' : ''}`}
              id="task-composer-drawer"
            >
              <div className="input-wrapper" id="quick-task-box">
                <div className="input-field-group">
                  <label htmlFor="task-input">عنوان تسک جدید:</label>
                  <input
                    ref={taskInputRef}
                    type="text"
                    id="task-input"
                    value={taskInput}
                    onChange={(e) => setTaskInput(e.target.value)}
                    placeholder="مثلاً: مطالعه ۳۰ دقیقه یا تماس کاری..."
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleAddTask();
                    }}
                  />
                </div>
                <div className="mobile-input-grid">
                  <div className="input-field-group">
                    <label htmlFor="task-slot">🌤️ نوبت:</label>
                    <select
                      id="task-slot"
                      value={taskSlot}
                      onChange={(e) => setTaskSlot(e.target.value as TaskSlot)}
                    >
                      <option value="morning">🌅 صبح</option>
                      <option value="afternoon">☀️ ظهر</option>
                      <option value="night">🌙 شب</option>
                    </select>
                  </div>
                  <div className="input-field-group">
                    <label htmlFor="task-priority">⚡ اهمیت:</label>
                    <select
                      id="task-priority"
                      value={taskPriority}
                      onChange={(e) => setTaskPriority(e.target.value as TaskPriority)}
                    >
                      <option value="low">پایین 🔵</option>
                      <option value="medium">متوسط 🟡</option>
                      <option value="high">بالا 🔴</option>
                    </select>
                  </div>
                  <div className="input-field-group">
                    <label htmlFor="task-time">⏰ ساعت:</label>
                    <input
                      type="time"
                      id="task-time"
                      value={taskTime}
                      onChange={(e) => setTaskTime(e.target.value)}
                    />
                  </div>
                </div>
                {taskTime && (
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: '1fr 1fr',
                      gap: '8px',
                      paddingTop: '4px',
                    }}
                  >
                    <div className="input-field-group">
                      <label htmlFor="task-reminder-min">🔔 یادآور قبل از تسک:</label>
                      <select
                        id="task-reminder-min"
                        value={taskReminderMin}
                        onChange={(e) => setTaskReminderMin(Number(e.target.value))}
                      >
                        <option value={0}>فقط سر ساعت</option>
                        <option value={5}>۵ دقیقه قبل</option>
                        <option value={10}>۱۰ دقیقه قبل</option>
                        <option value={15}>۱۵ دقیقه قبل</option>
                        <option value={30}>۳۰ دقیقه قبل</option>
                      </select>
                    </div>
                    <div className="input-field-group">
                      <label>🚨 آلارم صوتی سر ساعت:</label>
                      <button
                        type="button"
                        className={taskAlarmEnabled ? 'btn-complete-goal' : 'btn-delete perm'}
                        style={{ height: '44px', borderRadius: '13px', width: '100%' }}
                        onClick={() => setTaskAlarmEnabled((p) => !p)}
                      >
                        {taskAlarmEnabled ? '🚨 آلارم روشن' : '🔕 آلارم خاموش'}
                      </button>
                    </div>
                  </div>
                )}
                <button type="button" className="btn-add" onClick={handleAddTask}>
                  افزودن تسک
                </button>
              </div>
            </div>

            {/* Collapsible Filter & Search Drawer */}
            <div
              className={`collapsible-drawer ${isTaskFilterOpen ? 'open' : ''}`}
              id="task-filter-drawer"
            >
              <div className="filter-bar">
                <input
                  type="text"
                  id="search-input"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="🔍 جستجو در تسک‌های این روز..."
                />
                <div className="filter-pills-scroll">
                  <button
                    type="button"
                    className={`filter-btn ${currentFilter === 'all' ? 'active' : ''}`}
                    id="filter-all"
                    onClick={() => setCurrentFilter('all')}
                  >
                    همه
                  </button>
                  <button
                    type="button"
                    className={`filter-btn ${currentFilter === 'pending' ? 'active' : ''}`}
                    id="filter-pending"
                    onClick={() => setCurrentFilter('pending')}
                  >
                    در انتظار
                  </button>
                  <button
                    type="button"
                    className={`filter-btn ${currentFilter === 'completed' ? 'active' : ''}`}
                    id="filter-completed"
                    onClick={() => setCurrentFilter('completed')}
                  >
                    انجام‌شده
                  </button>
                  <button
                    type="button"
                    className={`filter-btn ${currentFilter === 'high' ? 'active' : ''}`}
                    id="filter-high"
                    onClick={() => setCurrentFilter('high')}
                  >
                    اهمیت بالا
                  </button>
                  <select
                    className="filter-btn"
                    id="sort-select"
                    value={currentSort}
                    onChange={(e) =>
                      setCurrentSort(e.target.value as 'time' | 'priority' | 'created')
                    }
                  >
                    <option value="time">مرتب‌سازی: ساعت</option>
                    <option value="priority">مرتب‌سازی: اهمیت</option>
                    <option value="created">مرتب‌سازی: جدیدترین</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Segmented Slot Tabs */}
            <div className="mobile-slot-tabs">
              <button
                type="button"
                className={`slot-seg-btn ${activeMobileSlot === 'all' ? 'active' : ''}`}
                id="slot-tab-all"
                onClick={() => setActiveMobileSlot('all')}
              >
                همه <span className="slot-cnt" id="cnt-slot-all">{toPersianDigits(rawDayTasks.length)}</span>
              </button>
              <button
                type="button"
                className={`slot-seg-btn ${activeMobileSlot === 'morning' ? 'active' : ''}`}
                id="slot-tab-morning"
                onClick={() => setActiveMobileSlot('morning')}
              >
                🌅 صبح <span className="slot-cnt" id="cnt-slot-morning">{toPersianDigits(rawMorningCount)}</span>
              </button>
              <button
                type="button"
                className={`slot-seg-btn ${activeMobileSlot === 'afternoon' ? 'active' : ''}`}
                id="slot-tab-afternoon"
                onClick={() => setActiveMobileSlot('afternoon')}
              >
                ☀️ ظهر <span className="slot-cnt" id="cnt-slot-afternoon">{toPersianDigits(rawAfternoonCount)}</span>
              </button>
              <button
                type="button"
                className={`slot-seg-btn ${activeMobileSlot === 'night' ? 'active' : ''}`}
                id="slot-tab-night"
                onClick={() => setActiveMobileSlot('night')}
              >
                🌙 شب <span className="slot-cnt" id="cnt-slot-night">{toPersianDigits(rawNightCount)}</span>
              </button>
            </div>

            {/* 3 Slot Columns */}
            <div className="desktop-columns-wrapper">
              {(
                [
                  { slot: 'morning' as TaskSlot, title: '🌅 صبح', items: morningTasks },
                  { slot: 'afternoon' as TaskSlot, title: '☀️ ظهر و عصر', items: afternoonTasks },
                  { slot: 'night' as TaskSlot, title: '🌙 شب', items: nightTasks },
                ] as const
              ).map((col) => {
                const isHidden = activeMobileSlot !== 'all' && activeMobileSlot !== col.slot;
                return (
                  <div
                    key={col.slot}
                    className={`column-box ${isHidden ? 'slot-hidden' : ''}`}
                    id={`col-box-${col.slot}`}
                  >
                    <div className="section-category-title">{col.title}</div>
                    <div className="task-container-wrapper">
                      <ul className="task-list" id={`task-list-${col.slot}`}>
                        {col.items.length === 0 ? (
                          <li
                            style={{
                              textAlign: 'center',
                              color: 'var(--text-subtle)',
                              padding: '16px 8px',
                              fontSize: '0.86rem',
                            }}
                          >
                            تسکی در این بخش وجود ندارد
                          </li>
                        ) : (
                          col.items.map((t) => {
                            const isAlarmOn =
                              t.alarmEnabled !== undefined
                                ? t.alarmEnabled
                                : alarmSettings.triggerExactTimeAlarm;
                            return (
                              <li
                                key={t.id}
                                className={`task-item ${t.completed ? 'completed' : ''} ${
                                  t.isDeferred ? 'deferred-task' : ''
                                }`}
                                onTouchStart={(e) => handleTaskTouchStart(e, t.id)}
                                onTouchEnd={(e) => handleTaskTouchEnd(e, selectedDateKey, t.id)}
                              >
                                <div
                                  className="task-info"
                                  onClick={() => handleToggleTask(selectedDateKey, t.id)}
                                >
                                  <input
                                    type="checkbox"
                                    checked={t.completed}
                                    onChange={() => {}}
                                    onClick={(e) => e.stopPropagation()}
                                    onChangeCapture={() =>
                                      handleToggleTask(selectedDateKey, t.id)
                                    }
                                  />
                                  <span className={`priority-dot priority-dot-${t.priority}`} />
                                  <span className="task-title-text">{t.text}</span>
                                  <span className={`priority-badge priority-${t.priority}`}>
                                    {priorityLabels[t.priority]}
                                  </span>
                                  {t.isDeferred && (
                                    <span className="deferrals-chip">⏳ جبرانی</span>
                                  )}
                                  {t.time && (
                                    <span className="task-time">
                                      ⏰ {toPersianDigits(t.time)}
                                    </span>
                                  )}
                                  {t.time && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleToggleTaskAlarm(selectedDateKey, t.id);
                                      }}
                                      style={{
                                        background: isAlarmOn
                                          ? 'rgba(16, 185, 129, 0.16)'
                                          : 'rgba(100, 116, 139, 0.16)',
                                        border: isAlarmOn
                                          ? '1px solid rgba(16, 185, 129, 0.4)'
                                          : '1px solid rgba(100, 116, 139, 0.35)',
                                        color: isAlarmOn ? '#34d399' : 'var(--text-muted)',
                                        borderRadius: '8px',
                                        padding: '2px 7px',
                                        fontSize: '0.72rem',
                                        fontWeight: 800,
                                        cursor: 'pointer',
                                      }}
                                      title="تغییر وضعیت آلارم این تسک"
                                    >
                                      {isAlarmOn ? '🚨 آلارم' : '🔕 بی‌صدا'}
                                    </button>
                                  )}
                                </div>
                                <div className="task-actions">
                                  <button
                                    type="button"
                                    className="btn-slot-cycle"
                                    title="تغییر نوبت (صبح/ظهر/شب)"
                                    onClick={() => handleCycleTaskSlot(selectedDateKey, t.id)}
                                  >
                                    ⇄
                                  </button>
                                  <button
                                    type="button"
                                    className="btn-delete"
                                    onClick={() => handleDeleteTask(selectedDateKey, t.id, false)}
                                  >
                                    حذف
                                  </button>
                                  {t.habitId && (
                                    <button
                                      type="button"
                                      className="btn-delete perm"
                                      onClick={() => handleDeleteTask(selectedDateKey, t.id, true)}
                                    >
                                      حذف دائم
                                    </button>
                                  )}
                                </div>
                              </li>
                            );
                          })
                        )}
                      </ul>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Collapsible Daily Notes */}
            <div className={`notes-box ${notesOpen ? 'open' : ''}`} id="notes-box">
              <div className="notes-bar">
                <h3>📝 یادداشت‌های این روز</h3>
                <span className="notes-count" id="notes-count">
                  {toPersianDigits((notesData[selectedDateKey] || []).length)} یادداشت
                </span>
                <button
                  type="button"
                  className="notes-toggle"
                  onClick={() => setNotesOpen((p) => !p)}
                >
                  +
                </button>
              </div>
              <div className="notes-panel" id="notes-panel">
                <div className="notes-panel-inner">
                  <div className="notes-add">
                    <textarea
                      id="note-input"
                      value={noteInput}
                      onChange={(e) => setNoteInput(e.target.value)}
                      placeholder="نکته یا درسی که امروز یاد گرفتی بنویس..."
                    />
                    <button type="button" className="btn-add" onClick={handleAddNote}>
                      افزودن
                    </button>
                  </div>
                  <ul className="notes-list" id="notes-list">
                    {(notesData[selectedDateKey] || []).map((n) => (
                      <li key={n.id} className="note-item">
                        <div className="note-text">{n.text}</div>
                        <button
                          type="button"
                          className="note-del"
                          onClick={() => handleDeleteNote(n.id)}
                        >
                          ✖
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. WEEKLY VIEW (Accordion Mobile Cards) */}
        {activeTab === 'weekly' && (
          <div id="weekly-view" className="view-section active">
            <div className="section-header">
              <h2>📅 برنامه هفتگی</h2>
            </div>
            <div className="weekly-grid" id="weekly-grid-container">
              {currentWeekDays.map((wd) => {
                const isToday = wd.dKey === todayKey;
                const isExpanded = Boolean(expandedWeeklyDays[wd.dKey]);
                const doneCount = wd.tasks.filter((t) => t.completed).length;
                const draft = weeklyInputs[wd.dKey] || {
                  text: '',
                  slot: 'morning' as TaskSlot,
                  time: '',
                };

                return (
                  <div
                    key={wd.dKey}
                    className={`weekly-day-card ${isExpanded ? 'expanded' : ''}`}
                    style={isToday ? { borderColor: 'var(--accent-primary)' } : undefined}
                  >
                    <div
                      className="weekly-day-title"
                      onClick={() => {
                        triggerHaptic(8);
                        setExpandedWeeklyDays((prev) => ({
                          ...prev,
                          [wd.dKey]: !prev[wd.dKey],
                        }));
                      }}
                    >
                      <span>
                        {wd.dowName}{' '}
                        {isToday ? <b style={{ color: 'var(--success)' }}>(امروز)</b> : null} —{' '}
                        <small style={{ color: 'var(--text-muted)' }}>
                          {toPersianDigits(wd.dayNum)} {wd.monthName}
                        </small>
                      </span>
                      <span className="weekly-count-pill">
                        {wd.tasks.length > 0
                          ? `${toPersianDigits(doneCount)}/${toPersianDigits(wd.tasks.length)} انجام‌شده ▾`
                          : 'خالی ▾'}
                      </span>
                    </div>

                    <div className="weekly-body-wrap">
                      <ul className="weekly-task-list">
                        {wd.tasks.length === 0 ? (
                          <li
                            style={{
                              color: 'var(--text-subtle)',
                              fontSize: '0.84rem',
                              textAlign: 'center',
                              padding: '10px',
                            }}
                          >
                            بدون تسک
                          </li>
                        ) : (
                          wd.tasks.map((t) => (
                            <li
                              key={t.id}
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                gap: '6px',
                                background: 'var(--item-bg)',
                                padding: '7px 10px',
                                borderRadius: '10px',
                                fontSize: '0.85rem',
                                opacity: t.completed ? 0.6 : 1,
                              }}
                            >
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '6px',
                                  flex: 1,
                                  minWidth: 0,
                                  cursor: 'pointer',
                                }}
                                onClick={() => handleToggleTask(wd.dKey, t.id)}
                              >
                                <input
                                  type="checkbox"
                                  checked={t.completed}
                                  onChange={() => {}}
                                />
                                <span
                                  style={{
                                    textDecoration: t.completed ? 'line-through' : 'none',
                                    wordBreak: 'break-word',
                                  }}
                                >
                                  {slotEmojis[t.slot]} {t.text}
                                </span>
                              </div>
                              <button
                                type="button"
                                className="note-del"
                                onClick={() => handleDeleteTask(wd.dKey, t.id, false)}
                              >
                                ✖
                              </button>
                            </li>
                          ))
                        )}
                      </ul>

                      <div className="weekly-add-box">
                        <input
                          type="text"
                          placeholder="تسک جدید در این روز..."
                          value={draft.text}
                          onChange={(e) =>
                            setWeeklyInputs((prev) => ({
                              ...prev,
                              [wd.dKey]: { ...draft, text: e.target.value },
                            }))
                          }
                        />
                        <div className="weekly-add-row">
                          <select
                            value={draft.slot}
                            onChange={(e) =>
                              setWeeklyInputs((prev) => ({
                                ...prev,
                                [wd.dKey]: { ...draft, slot: e.target.value as TaskSlot },
                              }))
                            }
                          >
                            <option value="morning">🌅 صبح</option>
                            <option value="afternoon">☀️ ظهر</option>
                            <option value="night">🌙 شب</option>
                          </select>
                          <input
                            type="time"
                            value={draft.time}
                            onChange={(e) =>
                              setWeeklyInputs((prev) => ({
                                ...prev,
                                [wd.dKey]: { ...draft, time: e.target.value },
                              }))
                            }
                          />
                        </div>
                        <button
                          type="button"
                          className="weekly-add-btn"
                          onClick={() => {
                            const clean = draft.text.trim();
                            if (!clean) return;
                            const newTask: TaskItem = {
                              id: Date.now(),
                              text: clean,
                              slot: draft.slot,
                              priority: 'medium',
                              time: draft.time,
                              completed: false,
                              alarmEnabled: Boolean(draft.time),
                              reminderMinutesBefore: alarmSettings.defaultAdvanceMinutes,
                            };
                            setTasksData((prev) => ({
                              ...prev,
                              [wd.dKey]: [...(prev[wd.dKey] || []), newTask],
                            }));
                            setWeeklyInputs((prev) => ({
                              ...prev,
                              [wd.dKey]: { text: '', slot: 'morning', time: '' },
                            }));
                          }}
                        >
                          + افزودن به این روز
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 4. MONTHLY CALENDAR VIEW (7-column mobile grid) */}
        {activeTab === 'calendar' && (
          <div id="calendar-view" className="view-section active">
            <div className="calendar-header">
              <button
                type="button"
                className="calendar-nav-btn"
                onClick={() =>
                  setCalendarMonth(([y, m]) => (m === 1 ? [y - 1, 12] : [y, m - 1]))
                }
              >
                ▶ ماه قبل
              </button>
              <h3 id="calendar-month-title" style={{ fontSize: '1.05rem', fontWeight: 900 }}>
                {persianMonths[calendarMonth[1] - 1]} {toPersianDigits(calendarMonth[0])}
              </h3>
              <button
                type="button"
                className="calendar-nav-btn"
                onClick={() =>
                  setCalendarMonth(([y, m]) => (m === 12 ? [y + 1, 1] : [y, m + 1]))
                }
              >
                ماه بعد ◀
              </button>
            </div>
            <div className="calendar-weekdays">
              <span>ش</span>
              <span>ی</span>
              <span>د</span>
              <span>س</span>
              <span>چ</span>
              <span>پ</span>
              <span>ج</span>
            </div>
            <div className="calendar-grid" id="calendar-grid">
              {Array.from(
                { length: getDayOfWeek(calendarMonth[0], calendarMonth[1], 1) },
                (_, idx) => (
                  <div
                    key={`empty-${idx}`}
                    className="day-card"
                    style={{ visibility: 'hidden', pointerEvents: 'none' }}
                  />
                )
              )}
              {Array.from(
                { length: getJalaliMonthLength(calendarMonth[0], calendarMonth[1]) },
                (_, idx) => {
                  const d = idx + 1;
                  const [cy, cm] = calendarMonth;
                  const dKey = getDateKey(cy, cm, d);
                  const isSelected =
                    selectedDay[0] === cy && selectedDay[1] === cm && selectedDay[2] === d;
                  const isToday = ty === cy && tm === cm && td === d;
                  const dayTasks = tasksData[dKey] || [];
                  const dayNotes = notesData[dKey] || [];

                  return (
                    <div
                      key={dKey}
                      className={`day-card ${isSelected ? 'selected' : ''}`}
                      style={
                        isToday && !isSelected
                          ? { borderColor: 'var(--success)', borderWidth: '1.5px' }
                          : undefined
                      }
                      onClick={() => {
                        setSelectedDay([cy, cm, d]);
                        setActiveTab('tasks');
                      }}
                    >
                      {dayNotes.length > 0 && <span className="note-indicator">📝</span>}
                      <strong style={{ fontSize: '1rem', fontWeight: 900 }}>
                        {toPersianDigits(d)}
                      </strong>
                      <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>
                        {dayTasks.length > 0 ? `${toPersianDigits(dayTasks.length)} تسک` : 'خالی'}
                      </span>
                      <div className="dots-wrapper">
                        {dayTasks.slice(0, 5).map((t) => (
                          <span
                            key={t.id}
                            className={`dot ${t.completed ? 'done' : 'pending'}`}
                          />
                        ))}
                      </div>
                    </div>
                  );
                }
              )}
            </div>
          </div>
        )}

        {/* 5. GOALS, HABITS & HALL OF FAME (3-Pane Sub-Nav) */}
        {activeTab === 'goals' && (
          <div id="goals-view" className="view-section active">
            <div className="section-header">
              <h2>🎯 مسیر رشد و اهداف</h2>
            </div>

            <div className="goals-sub-nav">
              <button
                type="button"
                className={`goals-sub-btn ${goalsSubTab === 'goals' ? 'active' : ''}`}
                id="gsub-btn-goals"
                onClick={() => {
                  triggerHaptic(10);
                  setGoalsSubTab('goals');
                }}
              >
                🎯 اهداف
              </button>
              <button
                type="button"
                className={`goals-sub-btn ${goalsSubTab === 'habits' ? 'active' : ''}`}
                id="gsub-btn-habits"
                onClick={() => {
                  triggerHaptic(10);
                  setGoalsSubTab('habits');
                }}
              >
                🔁 عادت‌ها
              </button>
              <button
                type="button"
                className={`goals-sub-btn ${goalsSubTab === 'hof' ? 'active' : ''}`}
                id="gsub-btn-hof"
                onClick={() => {
                  triggerHaptic(10);
                  setGoalsSubTab('hof');
                }}
              >
                👑 افتخارات
              </button>
            </div>

            {/* PANE 1: ACTIVE GOALS */}
            <div className={`goals-pane ${goalsSubTab === 'goals' ? 'active' : ''}`} id="gsub-pane-goals">
              <div className="subsection-header">
                <h3>🎯 پیشرفت اهداف</h3>
                <span id="goals-count-label">{toPersianDigits(activeGoals.length)} هدف فعال</span>
              </div>
              <div className="goal-input-box" id="quick-goal-box">
                <select
                  id="new-goal-emoji"
                  value={newGoalEmoji}
                  onChange={(e) => setNewGoalEmoji(e.target.value)}
                  style={{ fontSize: '1.3rem', flex: '0 0 58px', width: '58px', textAlign: 'center' }}
                >
                  {[
                    '📌',
                    '🎯',
                    '💻',
                    '📚',
                    '💪',
                    '💡',
                    '🎨',
                    '🚀',
                    '⭐',
                    '💼',
                    '🏆',
                    '🎓',
                    '🔥',
                    '💎',
                    '🌟',
                  ].map((em) => (
                    <option key={em} value={em}>
                      {em}
                    </option>
                  ))}
                </select>
                <input
                  ref={goalInputRef}
                  type="text"
                  id="new-goal-title"
                  value={newGoalTitle}
                  onChange={(e) => setNewGoalTitle(e.target.value)}
                  placeholder="عنوان هدف جدید..."
                  style={{ flex: 1 }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleAddGoal();
                  }}
                />
                <button type="button" className="btn-add" onClick={handleAddGoal}>
                  ایجاد هدف
                </button>
              </div>

              <div className="goals-grid" id="goals-container">
                {activeGoals.length === 0 ? (
                  <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '18px' }}>
                    هنوز هدف فعالی ثبت نشده است.
                  </p>
                ) : (
                  activeGoals.map((g) => {
                    const total = g.tasks.length;
                    const done = g.tasks.filter((t) => t.completed).length;
                    const pct = total === 0 ? 0 : Math.round((done / total) * 100);
                    return (
                      <div key={g.id} className="goal-card">
                        <div className="goal-card-header">
                          <span className="goal-title">
                            {g.emoji || '🎯'} {g.title}
                          </span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <button
                              type="button"
                              className="btn-complete-goal"
                              onClick={() => handleCompleteGoal(g.id)}
                            >
                              🏆 تکمیل
                            </button>
                            <button
                              type="button"
                              className="btn-delete"
                              onClick={() => handleDeleteGoal(g.id)}
                            >
                              حذف
                            </button>
                          </div>
                        </div>

                        <div className="progress-info">
                          <span>پیشرفت هدف:</span>
                          <span>{toPersianDigits(pct)}%</span>
                        </div>
                        <div className="progress-bar-track" style={{ marginBottom: '12px' }}>
                          <div className="progress-bar-fill" style={{ width: `${pct}%` }} />
                        </div>

                        <div className="goal-task-input-box">
                          <input
                            type="text"
                            placeholder="افزودن گام جدید برای این هدف..."
                            value={goalSubtaskInputs[g.id] || ''}
                            onChange={(e) =>
                              setGoalSubtaskInputs((prev) => ({ ...prev, [g.id]: e.target.value }))
                            }
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleAddGoalSubtask(g.id);
                            }}
                          />
                          <button type="button" onClick={() => handleAddGoalSubtask(g.id)}>
                            +
                          </button>
                        </div>

                        <ul className="goal-tasks-list">
                          {g.tasks.map((gt) => {
                            const slotKey = `${g.id}_${gt.id}`;
                            return (
                              <li
                                key={gt.id}
                                className={`goal-task-item ${gt.completed ? 'completed' : ''}`}
                              >
                                <div
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    cursor: 'pointer',
                                    flex: 1,
                                  }}
                                  onClick={() => handleToggleGoalSubtask(g.id, gt.id)}
                                >
                                  <input type="checkbox" checked={gt.completed} onChange={() => {}} />
                                  <span className="task-name">{gt.text}</span>
                                </div>
                                <div className="goal-actions">
                                  <select
                                    className="goal-slot-select"
                                    value={goalTransferSlots[slotKey] || 'morning'}
                                    onChange={(e) =>
                                      setGoalTransferSlots((prev) => ({
                                        ...prev,
                                        [slotKey]: e.target.value as TaskSlot,
                                      }))
                                    }
                                  >
                                    <option value="morning">🌅 صبح</option>
                                    <option value="afternoon">☀️ ظهر</option>
                                    <option value="night">🌙 شب</option>
                                  </select>
                                  <button
                                    type="button"
                                    className="btn-transfer"
                                    onClick={() => handleTransferGoalTaskToToday(g.id, gt.id)}
                                  >
                                    + امروز
                                  </button>
                                  <button
                                    type="button"
                                    className="note-del"
                                    onClick={() => handleDeleteGoalSubtask(g.id, gt.id)}
                                  >
                                    ✖
                                  </button>
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* PANE 2: ACTIVE HABITS */}
            <div className={`goals-pane ${goalsSubTab === 'habits' ? 'active' : ''}`} id="gsub-pane-habits">
              <div className="subsection-header">
                <h3>
                  🔁 ایجاد عادت{' '}
                  <span
                    className={`info-tip ${openInfoTip ? 'open' : ''}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setOpenInfoTip((p) => !p);
                    }}
                  >
                    ❗
                    <span className="info-pop">
                      💡 <b>عادت‌ها برای ساخت روتین روزانه هستن.</b>
                      <br />
                      <br />
                      📅 می‌تونی <b>روزهای فعال</b>، <b>مدت عادت</b> و <b>تسک‌های روزانه</b> رو ویرایش کنی.
                      <br />
                      <br />
                      📌 هر تسک عادت می‌تونه روزهای فعال خودش رو داشته باشه.
                      <br />
                      <br />
                      ⚠️ اگه تسکی رو حذف کنی، فقط همون یکی جبرانی می‌شه. برای حذف بدون جبرانی، «حذف دائم» بزن.
                    </span>
                  </span>
                </h3>
                <span id="habits-count-label">{toPersianDigits(activeHabits.length)} عادت فعال</span>
              </div>

              <div className="habit-input-box">
                <input
                  ref={habitInputRef}
                  type="text"
                  id="new-habit-name"
                  value={newHabitName}
                  onChange={(e) => setNewHabitName(e.target.value)}
                  placeholder="نام عادت... مثال: ورزش صبحگاهی"
                  style={{ flex: 1 }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleAddHabit();
                  }}
                />
                <div className="habit-duration-group">
                  <input
                    type="number"
                    id="new-habit-duration"
                    min={1}
                    max={365}
                    value={newHabitDuration}
                    onChange={(e) => setNewHabitDuration(Number(e.target.value))}
                  />
                  <span>روز</span>
                </div>
                <button type="button" className="btn-add-habit" onClick={handleAddHabit}>
                  🔁 ایجاد عادت
                </button>
              </div>

              <div className="habits-grid" id="habits-container">
                {activeHabits.length === 0 ? (
                  <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '18px' }}>
                    هنوز عادت فعالی ثبت نشده است.
                  </p>
                ) : (
                  activeHabits.map((h) => {
                    const totalSpan = h.duration + (h.deferrals || 0);
                    const elapsed = Math.min(
                      totalSpan,
                      Math.max(0, calcDaysBetweenIso((h.startIso || todayIso), todayIso) + 1)
                    );
                    const pct = totalSpan === 0 ? 0 : Math.round((elapsed / totalSpan) * 100);
                    const isEditing = editingHabitId === h.id && habitEditDraft !== null;
                    const isAdvOpen = Boolean(openAdvancedHabitIds[h.id]);
                    const newSubDraft = habitNewTaskInputs[h.id] || {
                      text: '',
                      slot: 'morning' as TaskSlot,
                      time: '',
                    };
                    const activeDays = h.activeDays || [0, 1, 2, 3, 4, 5, 6];

                    if (isEditing && habitEditDraft) {
                      return (
                        <div key={h.id} className="goal-card">
                          <div className="habit-edit-box">
                            <label>نام عادت:</label>
                            <input
                              type="text"
                              value={habitEditDraft.name}
                              onChange={(e) =>
                                setHabitEditDraft({ ...habitEditDraft, name: e.target.value })
                              }
                            />
                            <label>مدت زمان (روز):</label>
                            <input
                              type="number"
                              min={1}
                              max={365}
                              value={habitEditDraft.duration}
                              onChange={(e) =>
                                setHabitEditDraft({
                                  ...habitEditDraft,
                                  duration: Number(e.target.value),
                                })
                              }
                            />
                            <label>تسک‌های روزانه عادت:</label>
                            {habitEditDraft.tasks.map((dt, idx) => (
                              <div key={dt.id} className="habit-edit-task">
                                <input
                                  type="text"
                                  value={dt.text}
                                  onChange={(e) => {
                                    const copy = [...habitEditDraft.tasks];
                                    copy[idx] = { ...copy[idx], text: e.target.value };
                                    setHabitEditDraft({ ...habitEditDraft, tasks: copy });
                                  }}
                                />
                                <select
                                  value={dt.slot}
                                  onChange={(e) => {
                                    const copy = [...habitEditDraft.tasks];
                                    copy[idx] = {
                                      ...copy[idx],
                                      slot: e.target.value as TaskSlot,
                                    };
                                    setHabitEditDraft({ ...habitEditDraft, tasks: copy });
                                  }}
                                >
                                  <option value="morning">🌅 صبح</option>
                                  <option value="afternoon">☀️ ظهر</option>
                                  <option value="night">🌙 شب</option>
                                </select>
                                <input
                                  type="time"
                                  value={dt.time}
                                  onChange={(e) => {
                                    const copy = [...habitEditDraft.tasks];
                                    copy[idx] = { ...copy[idx], time: e.target.value };
                                    setHabitEditDraft({ ...habitEditDraft, tasks: copy });
                                  }}
                                />
                              </div>
                            ))}
                            <div className="habit-edit-actions">
                              <button
                                type="button"
                                className="btn-add"
                                onClick={() => saveEditHabit(h.id)}
                              >
                                💾 ذخیره
                              </button>
                              <button
                                type="button"
                                className="btn-delete"
                                onClick={() => {
                                  setEditingHabitId(null);
                                  setHabitEditDraft(null);
                                }}
                              >
                                انصراف
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div key={h.id} className="goal-card">
                        <div className="goal-card-header">
                          <span className="goal-title">🔁 {h.name}</span>
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              flexWrap: 'wrap',
                            }}
                          >
                            <span className="habit-days-chip">
                              {toPersianDigits(h.duration)} روزه
                            </span>
                            {(h.deferrals || 0) > 0 && (
                              <span className="deferrals-chip">
                                +{toPersianDigits(h.deferrals)} جبرانی
                              </span>
                            )}
                            <button
                              type="button"
                              className="btn-complete-goal"
                              onClick={() => handleCompleteHabitManual(h.id)}
                            >
                              🏁 تثبیت
                            </button>
                            <button
                              type="button"
                              className="btn-advanced"
                              onClick={() =>
                                setOpenAdvancedHabitIds((prev) => ({
                                  ...prev,
                                  [h.id]: !prev[h.id],
                                }))
                              }
                            >
                              📅 روزها
                            </button>
                            <button
                              type="button"
                              className="btn-advanced"
                              onClick={() => startEditHabit(h)}
                            >
                              ✏️
                            </button>
                            <button
                              type="button"
                              className="btn-delete"
                              onClick={() => handleDeleteHabit(h.id)}
                            >
                              حذف
                            </button>
                          </div>
                        </div>

                        <div className="habit-info-row">
                          روز {toPersianDigits(elapsed)} از {toPersianDigits(totalSpan)} ({toPersianDigits(pct)}%)
                        </div>
                        <div className="progress-bar-track" style={{ marginBottom: '12px' }}>
                          <div className="progress-bar-fill" style={{ width: `${pct}%` }} />
                        </div>

                        {isAdvOpen && (
                          <div className="advanced-settings-box" style={{ marginBottom: '12px' }}>
                            <div className="advanced-settings-title">📅 روزهای فعال هفته برای این عادت:</div>
                            <div className="day-picker-grid">
                              {weekDaysShort.map((dName, dIdx) => {
                                const isOn = activeDays.includes(dIdx);
                                return (
                                  <div
                                    key={dName}
                                    className={`day-picker-cell ${isOn ? 'active' : ''}`}
                                    onClick={() => handleToggleHabitDay(h.id, dIdx)}
                                  >
                                    <span className="day-name">{dName}</span>
                                    <span className="day-indicator" />
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        <ul className="goal-tasks-list">
                          {h.tasks.map((ht) => {
                            const tDays = ht.activeDays || [0, 1, 2, 3, 4, 5, 6];
                            return (
                              <li key={ht.id} className="habit-task-item">
                                <div style={{ flex: 1, minWidth: '140px' }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                                    <span className="habit-task-text">{ht.text}</span>
                                    <span className="habit-slot-badge">
                                      {slotEmojis[ht.slot]} {slotLabels[ht.slot]}
                                    </span>
                                    {ht.time && (
                                      <span className="task-time">⏰ {toPersianDigits(ht.time)}</span>
                                    )}
                                  </div>
                                  <div className="day-picker-mini">
                                    {weekDaysShort.map((dn, di) => (
                                      <span
                                        key={dn}
                                        className={tDays.includes(di) ? 'active' : ''}
                                        onClick={() => handleToggleHabitSubTaskDay(h.id, ht.id, di)}
                                      >
                                        {dn}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  className="note-del"
                                  onClick={() => handleDeleteHabitSubTask(h.id, ht.id)}
                                >
                                  ✖
                                </button>
                              </li>
                            );
                          })}
                        </ul>

                        <div className="habit-add-box">
                          <input
                            type="text"
                            placeholder="افزودن تسک روزانه به این عادت..."
                            value={newSubDraft.text}
                            onChange={(e) =>
                              setHabitNewTaskInputs((prev) => ({
                                ...prev,
                                [h.id]: { ...newSubDraft, text: e.target.value },
                              }))
                            }
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleAddHabitSubTask(h.id);
                            }}
                          />
                          <div className="habit-add-row">
                            <select
                              value={newSubDraft.slot}
                              onChange={(e) =>
                                setHabitNewTaskInputs((prev) => ({
                                  ...prev,
                                  [h.id]: { ...newSubDraft, slot: e.target.value as TaskSlot },
                                }))
                              }
                            >
                              <option value="morning">🌅 صبح</option>
                              <option value="afternoon">☀️ ظهر</option>
                              <option value="night">🌙 شب</option>
                            </select>
                            <input
                              type="time"
                              value={newSubDraft.time}
                              onChange={(e) =>
                                setHabitNewTaskInputs((prev) => ({
                                  ...prev,
                                  [h.id]: { ...newSubDraft, time: e.target.value },
                                }))
                              }
                            />
                            <button type="button" onClick={() => handleAddHabitSubTask(h.id)}>
                              + افزودن
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* PANE 3: HALL OF FAME (👑 افتخارات) */}
            <div className={`goals-pane ${goalsSubTab === 'hof' ? 'active' : ''}`} id="gsub-pane-hof">
              <div className="hall-of-fame-wrapper">
                <div className="hof-banner">
                  <div className="hof-title-group">
                    <div className="hof-crown-badge">👑</div>
                    <div>
                      <div className="hof-main-title">تالار افتخارات و دستاوردها</div>
                      <div className="hof-subtitle">ویترین اهداف فتح‌شده و عادت‌های پایدار شما</div>
                    </div>
                  </div>
                  <div className="hof-metrics-bar">
                    <div className="hof-metric-pill">
                      <span className="hof-metric-val" id="hof-total-trophies">
                        {toPersianDigits(completedGoals.length + completedHabits.length)}
                      </span>
                      <span className="hof-metric-lbl">کل جام‌ها</span>
                    </div>
                    <div className="hof-metric-pill">
                      <span className="hof-metric-val" id="hof-total-habit-days">
                        {toPersianDigits(
                          completedHabits.reduce((sum, h) => sum + (h.duration || 0), 0)
                        )}
                      </span>
                      <span className="hof-metric-lbl">روز استمرار</span>
                    </div>
                    <div className="hof-metric-pill">
                      <span className="hof-metric-val" id="hof-total-goal-steps">
                        {toPersianDigits(
                          completedGoals.reduce(
                            (sum, g) => sum + (g.tasks ? g.tasks.length : 0),
                            0
                          )
                        )}
                      </span>
                      <span className="hof-metric-lbl">گام فتح‌شده</span>
                    </div>
                  </div>
                </div>

                <div className="completed-habits-section">
                  <div className="subsection-header">
                    <h3>🏅 عادت‌های تثبیت‌شده</h3>
                    <span id="completed-habits-count-label">
                      {toPersianDigits(completedHabits.length)} عادت
                    </span>
                  </div>
                  <div className="habits-grid" id="completed-habits-container">
                    {completedHabits.length === 0 ? (
                      <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '16px' }}>
                        هنوز عادتی به پایان دوره نرسیده است.
                      </div>
                    ) : (
                      completedHabits.map((h) => {
                        const [sy, sm, sd] = isoToJalali((h.startIso || todayIso));
                        const startLabel = `${toPersianDigits(sd)} ${persianMonths[sm - 1]} ${toPersianDigits(sy)}`;
                        const totalSpan = h.duration + (h.deferrals || 0);
                        const endIso = addDaysToIso((h.startIso || todayIso), Math.max(0, totalSpan - 1));
                        const [ey, em, ed] = isoToJalali(endIso);
                        const endLabel =
                          h.completedAt ||
                          `${toPersianDigits(ed)} ${persianMonths[em - 1]} ${toPersianDigits(ey)}`;
                        const dotsCount = Math.min(28, Math.max(7, h.duration));

                        return (
                          <div key={h.id} className="hof-card hof-habit-theme">
                            <div className="hof-card-top">
                              <div className="hof-Identity">
                                <div className="hof-medal-ring">🏅</div>
                                <div className="hof-title-wrap">
                                  <span className="hof-rank-pill">✨ عادت تثبیت‌شده در سبک زندگی</span>
                                  <div className="hof-item-title">{h.name}</div>
                                  <div className="hof-item-sub">
                                    از {startLabel} تا {endLabel}
                                  </div>
                                </div>
                              </div>
                              <div className="hof-ring-badge">
                                <svg viewBox="0 0 36 36">
                                  <path
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                    fill="none"
                                    stroke="rgba(16, 185, 129, 0.2)"
                                    strokeWidth="3.5"
                                  />
                                  <path
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                    fill="none"
                                    stroke="#10b981"
                                    strokeWidth="3.5"
                                    strokeDasharray="100, 100"
                                  />
                                </svg>
                                <span>۱۰۰٪</span>
                              </div>
                            </div>

                            <div className="hof-stats-grid">
                              <div className="hof-stat-box">
                                <span className="hof-stat-val">
                                  🔥 {toPersianDigits(h.duration)} روز
                                </span>
                                <span className="hof-stat-lbl">تعهد و مداومت</span>
                              </div>
                              <div className="hof-stat-box">
                                <span className="hof-stat-val">
                                  ⚡ {toPersianDigits(h.tasks.length)} روتین
                                </span>
                                <span className="hof-stat-lbl">تسک روزانه</span>
                              </div>
                              <div className="hof-stat-box">
                                <span className="hof-stat-val">
                                  {(h.deferrals || 0) === 0
                                    ? '💎 بی‌وقفه'
                                    : `${toPersianDigits(h.deferrals)} جبرانی`}
                                </span>
                                <span className="hof-stat-lbl">کیفیت استمرار</span>
                              </div>
                            </div>

                            <div className="hof-steps-preview">
                              <div className="hof-steps-title">
                                <span>🌱 شبکه استمرار روزانه</span>
                                <span>{toPersianDigits(h.duration)} روز کامل</span>
                              </div>
                              <div
                                className="hof-Mastery-dots"
                                style={{ marginBottom: h.tasks.length ? '8px' : 0 }}
                              >
                                {Array.from({ length: dotsCount }, (_, i) => (
                                  <span key={i} className="hof-mastery-dot" />
                                ))}
                              </div>
                              {h.tasks.length > 0 && (
                                <div className="hof-task-chips">
                                  {h.tasks.map((ht) => (
                                    <span key={ht.id} className="hof-task-chip">
                                      ✔ {ht.text}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>

                            <div className="hof-card-footer">
                              <button
                                type="button"
                                className="btn-celebrate"
                                onClick={() => launchCelebration('habit', h.name)}
                              >
                                🎉 جشن افتخار
                              </button>
                              <div style={{ display: 'flex', gap: '6px' }}>
                                <button
                                  type="button"
                                  className="btn-restore-goal"
                                  onClick={() => handleRestoreCompletedHabit(h.id)}
                                >
                                  ↩ شروع مجدد
                                </button>
                                <button
                                  type="button"
                                  className="btn-delete-completed"
                                  onClick={() => handleDeleteHabit(h.id)}
                                >
                                  حذف
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                <div className="completed-goals-section" style={{ marginTop: '28px' }}>
                  <div className="subsection-header">
                    <h3>🏆 اهداف فتح‌شده</h3>
                    <span id="completed-goals-count-label">
                      {toPersianDigits(completedGoals.length)} هدف
                    </span>
                  </div>
                  <div className="goals-grid" id="completed-goals-container">
                    {completedGoals.length === 0 ? (
                      <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '16px' }}>
                        هنوز هدفی تکمیل نشده است.
                      </div>
                    ) : (
                      completedGoals.map((g) => (
                        <div key={g.id} className="hof-card hof-goal-theme">
                          <div className="hof-card-top">
                            <div className="hof-Identity">
                              <div className="hof-medal-ring">{g.emoji || '🏆'}</div>
                              <div className="hof-title-wrap">
                                <span className="hof-rank-pill">👑 قله فتح‌شده</span>
                                <div className="hof-item-title">{g.title}</div>
                                <div className="hof-item-sub">
                                  📅 تاریخ فتح: {g.completedAt || 'ثبت‌شده'}
                                </div>
                              </div>
                            </div>
                            <div className="hof-ring-badge">
                              <svg viewBox="0 0 36 36">
                                <path
                                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                  fill="none"
                                  stroke="rgba(251, 191, 36, 0.2)"
                                  strokeWidth="3.5"
                                />
                                <path
                                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                  fill="none"
                                  stroke="#fbbf24"
                                  strokeWidth="3.5"
                                  strokeDasharray="100, 100"
                                />
                              </svg>
                              <span>۱۰۰٪</span>
                            </div>
                          </div>

                          {g.tasks.length > 0 && (
                            <div className="hof-steps-preview">
                              <div className="hof-steps-title">
                                <span>🗺️ گام‌های به سرانجام رسیده</span>
                                <span>{toPersianDigits(g.tasks.length)} گام</span>
                              </div>
                              <div className="hof-task-chips">
                                {g.tasks.map((t) => (
                                  <span key={t.id} className="hof-task-chip">
                                    ✔ {t.text}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="hof-card-footer">
                            <button
                              type="button"
                              className="btn-celebrate"
                              onClick={() => launchCelebration('goal', g.title)}
                            >
                              🎉 جشن افتخار
                            </button>
                            <div style={{ display: 'flex', gap: '6px' }}>
                              <button
                                type="button"
                                className="btn-restore-goal"
                                onClick={() => handleRestoreGoal(g.id)}
                              >
                                ↩ بازگردانی
                              </button>
                              <button
                                type="button"
                                className="btn-delete-completed"
                                onClick={() => handleDeleteGoal(g.id)}
                              >
                                حذف
                              </button>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 6. PERSONALIZED REMINDERS & ANDROID ALARMS VIEW */}
        {activeTab === 'reminders' && (
          <RemindersView
            reminders={customReminders}
            settings={alarmSettings}
            todayTasks={todayTasks}
            notificationPermission={notificationPermission}
            onRequestPermission={requestAndroidNotificationPermission}
            onAddReminder={handleAddCustomReminder}
            onToggleReminder={handleToggleCustomReminder}
            onDeleteReminder={handleDeleteCustomReminder}
            onUpdateSettings={setAlarmSettings}
            onTestAlarmAndNotification={handleTestAlarmAndNotification}
            onToggleTaskAlarm={(taskId) => handleToggleTaskAlarm(todayKey, taskId)}
            onUpdateTaskReminderMinutes={(taskId, min) =>
              handleUpdateTaskReminderMinutes(todayKey, taskId, min)
            }
          />
        )}

        {/* 7. BACKUP & CLOUD SYNC VIEW */}
        {activeTab === 'backup' && (
          <div id="backup-view" className="view-section active">
            <div className="section-header">
              <h2>💾 پشتیبان‌گیری و فضای ابری</h2>
              <span
                className={`gdrive-badge ${gdriveAccessToken ? 'connected' : ''}`}
                id="gdrive-top-badge"
              >
                {gdriveAccessToken ? '☁️ متصل به Drive' : '☁️ آماده اتصال'}
              </span>
            </div>

            {/* Android App Install Card */}
            <div
              className="backup-card"
              style={{
                borderColor: 'rgba(16, 185, 129, 0.4)',
                background:
                  'linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(15, 23, 42, 0.45))',
              }}
            >
              <h3>📱 نصب اپلیکیشن اندروید (PWA & APK)</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginBottom: '12px' }}>
                این برنامه را روی صفحه اصلی گوشی اندروید خود نصب کنید تا تمام‌صفحه اجرا شده و آلارم‌ها و نوتیفیکیشن‌ها را دریافت کنید.
              </p>
              <div className="backup-actions">
                {isInstallable && !isInstalled && (
                  <button
                    type="button"
                    className="btn-add"
                    onClick={triggerInstall}
                  >
                    📲 نصب مستقیم در گوشی اندروید
                  </button>
                )}
                <button
                  type="button"
                  className="backup-btn"
                  onClick={() => setIsInstallModalOpen(true)}
                >
                  📖 راهنمای نصب و دریافت فایل APK
                </button>
              </div>
            </div>

            {/* Google Drive Cloud Sync Card */}
            <div className="backup-card" style={{ borderColor: 'rgba(56, 189, 248, 0.35)' }}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  gap: '8px',
                  marginBottom: '10px',
                  flexWrap: 'wrap',
                }}
              >
                <h3 style={{ margin: 0 }}>☁️ اتصال به Google Drive</h3>
                <button
                  type="button"
                  className="btn-advanced"
                  onClick={() => setIsGDriveSetupOpen((p) => !p)}
                  style={{ fontSize: '0.76rem' }}
                >
                  ⚙️ تنظیمات API
                </button>
              </div>
              <div className="backup-status-row">
                <span id="gdrive-status-text">
                  {gdriveAccessToken ? '🟢 متصل به حساب Google Drive' : '⚪ متصل به حساب گوگل نیست'}
                </span>
                {gdriveLastSync && (
                  <span
                    id="gdrive-last-sync"
                    style={{ fontSize: '0.78rem', color: 'var(--accent-tertiary)' }}
                  >
                    آخرین سینک: {gdriveLastSync}
                  </span>
                )}
              </div>

              {isGDriveSetupOpen && (
                <div
                  id="gdrive-setup-box"
                  style={{
                    padding: '12px',
                    background: 'var(--item-bg)',
                    border: '1px solid var(--item-border)',
                    borderRadius: '14px',
                    marginBottom: '12px',
                  }}
                >
                  <div
                    style={{
                      fontSize: '0.8rem',
                      fontWeight: 800,
                      color: 'var(--text-main)',
                      marginBottom: '4px',
                    }}
                  >
                    🔑 کلید Google OAuth Client ID یا Access Token:
                  </div>
                  <div className="gdrive-input-group">
                    <input
                      type="text"
                      id="gdrive-client-id"
                      value={gdriveClientId}
                      onChange={(e) => saveGDriveConfig(e.target.value, gdriveAccessToken)}
                      placeholder="xxxx.apps.googleusercontent.com"
                    />
                    <input
                      type="password"
                      id="gdrive-access-token"
                      value={gdriveAccessToken}
                      onChange={(e) => saveGDriveConfig(gdriveClientId, e.target.value)}
                      placeholder="یا Access Token مستقیم (OAuth2 Token)..."
                    />
                  </div>
                  <div className="habit-hint">
                    💡 برای اتصال خودکار ابری، Client ID یا توکن خود را وارد کنید یا مستقیماً از دکمه «ارسال مستقیم به اپ Google Drive گوشی» پایین استفاده کنید.
                  </div>
                </div>
              )}

              <div className="gdrive-sync-toggle">
                <span>🔄 همگام‌سازی خودکار پس از هر تغییر</span>
                <input
                  type="checkbox"
                  id="gdrive-autosync-check"
                  checked={gdriveAutoSync}
                  onChange={(e) => {
                    setGdriveAutoSync(e.target.checked);
                    safeStorageSet('vitodo_gdrive_autosync', String(e.target.checked));
                  }}
                  style={{ width: '20px', height: '20px', accentColor: 'var(--success)' }}
                />
              </div>

              <div className="backup-actions">
                <button
                  type="button"
                  className="backup-btn"
                  id="btn-gdrive-connect"
                  onClick={() => setIsGDriveSetupOpen(true)}
                  style={{
                    background: 'linear-gradient(135deg, #0ea5e9, #2563eb)',
                    color: '#fff',
                    border: 'none',
                  }}
                >
                  ☁️ اتصال به Google Drive
                </button>
                <button
                  type="button"
                  className="backup-btn"
                  id="btn-gdrive-push"
                  onClick={() => syncToGoogleDrive(true)}
                >
                  ⬆️ ذخیره در Drive
                </button>
                <button
                  type="button"
                  className="backup-btn"
                  id="btn-gdrive-pull"
                  onClick={restoreFromGoogleDrive}
                >
                  ⬇️ بازیابی از Drive
                </button>
              </div>
              <div className="backup-actions" style={{ marginTop: '6px' }}>
                <button
                  type="button"
                  className="backup-btn"
                  onClick={shareBackupToDriveApp}
                  style={{
                    background: 'var(--accent-soft)',
                    borderColor: 'var(--panel-border-hover)',
                  }}
                >
                  📲 ارسال مستقیم به اپ Google Drive گوشی
                </button>
              </div>
              <div className="habit-hint">
                تمامی تسک‌ها، یادداشت‌ها، اهداف، عادت‌ها، تالار افتخارات و یادآورهای شخصی در فایل{' '}
                <code>VitToDo-Cloud-Backup.json</code> ذخیره می‌شوند.
              </div>
            </div>

            {/* Connected Local File Card */}
            <div className="backup-card">
              <h3>📁 فایل داده متصل</h3>
              <div className="backup-status-row">
                <span id="backup-connection-status">
                  {fileHandle ? '✅ فایل پشتیبان متصل است' : '❌ هیچ فایلی متصل نیست'}
                </span>
                <span id="backup-last-save">
                  {backupLastSave ? `آخرین ذخیره: ${backupLastSave}` : ''}
                </span>
              </div>
              <div className="backup-actions">
                <button type="button" className="backup-btn" onClick={handleChooseBackupFile}>
                  📁 انتخاب محل ذخیره
                </button>
                {fileHandle && (
                  <button
                    type="button"
                    className="backup-btn danger"
                    onClick={() => setFileHandle(null)}
                  >
                    ✖ قطع اتصال
                  </button>
                )}
              </div>
              <div className="habit-hint">
                در مرورگرهای کروم/اج دسکتاپ یا اندروید، تغییرات خودکار ذخیره می‌شود.
              </div>
            </div>

            {/* Backup Summary Chips */}
            <div className="backup-card">
              <h3>📦 خلاصه اطلاعات ذخیره‌شده</h3>
              <div className="backup-chips" id="backup-summary">
                <span className="backup-chip">
                  📋 {toPersianDigits(Object.values(tasksData).reduce((s, l) => s + l.length, 0))}{' '}
                  تسک
                </span>
                <span className="backup-chip">
                  📝 {toPersianDigits(Object.values(notesData).reduce((s, l) => s + l.length, 0))}{' '}
                  یادداشت
                </span>
                <span className="backup-chip">
                  🎯 {toPersianDigits(goalsData.length)} هدف
                </span>
                <span className="backup-chip">
                  🔁 {toPersianDigits(habitsData.length)} عادت
                </span>
                <span className="backup-chip">
                  🔔 {toPersianDigits(customReminders.length)} یادآور شخصی
                </span>
              </div>
            </div>

            {/* Manual Download & Restore */}
            <div className="backup-card">
              <h3>🔄 دانلود و بازیابی دستی</h3>
              <div className="backup-actions">
                <button type="button" className="backup-btn" onClick={handleDownloadBackup}>
                  💾 دانلود پشتیبان
                </button>
                <button
                  type="button"
                  className="backup-btn"
                  onClick={() => restoreInputRef.current?.click()}
                >
                  📂 بازیابی
                </button>
              </div>
              <input
                ref={restoreInputRef}
                type="file"
                id="restore-file-input"
                accept=".json"
                style={{ display: 'none' }}
                onChange={handleRestoreFileChange}
              />
            </div>

            <div className="credit-footer">
              <div className="creator-showcase-card">
                <div className="creator-subtitle-top">✨ ساخته شده توسط:</div>
                <div className="creator-badges-row">
                  <div className="creator-pill-gemini">
                    <span>💎</span>
                    <span className="creator-name-gemini credit-name-gemini">Gemini</span>
                  </div>
                  <span className="creator-collab-x">×</span>
                  <div className="creator-pill-qwen">
                    <span>👑</span>
                    <span className="creator-name-qwen credit-name-qwen">Qwen</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Missed Prayers Bottom-Sheet Modal */}
      <div
        className={`prayer-modal-overlay ${isMissedPrayersOpen ? 'active' : ''}`}
        id="prayer-modal-overlay"
        onClick={(e) => {
          if (e.target === e.currentTarget) setIsMissedPrayersOpen(false);
        }}
      >
        <div className="prayer-modal" onClick={(e) => e.stopPropagation()}>
          <div className="prayer-modal-header">
            <h3>🕌 نمازهای قضا</h3>
            <button
              type="button"
              className="prayer-modal-close"
              onClick={() => setIsMissedPrayersOpen(false)}
            >
              ✕
            </button>
          </div>
          <div className="prayer-list" id="prayer-modal-list">
            {missedPrayersList.length === 0 ? (
              <div className="prayer-empty">🎉 الحمدلله! هیچ نماز قضایی ثبت نشده است.</div>
            ) : (
              missedPrayersList.map((mp) => (
                <div key={`${mp.dateKey}-${mp.task.id}`} className="prayer-item">
                  <div className="prayer-item-right">
                    <input
                      type="checkbox"
                      checked={mp.task.completed}
                      onChange={() => handleToggleTask(mp.dateKey, mp.task.id)}
                    />
                    <span className="prayer-name">{mp.task.text}</span>
                    <span className="prayer-date">📅 {mp.dateLabel}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Confirm Operation Bottom-Sheet Modal */}
      <div
        className={`confirm-modal-overlay ${confirmModal.isOpen ? 'active' : ''}`}
        id="confirm-modal-overlay"
        onClick={() => closeConfirmModal(false)}
      >
        <div className="confirm-modal" onClick={(e) => e.stopPropagation()}>
          <div className="confirm-modal-icon" id="confirm-modal-icon">
            {confirmModal.icon}
          </div>
          <div className="confirm-modal-title" id="confirm-modal-title">
            {confirmModal.title}
          </div>
          <div className="confirm-modal-msg" id="confirm-modal-msg">
            {confirmModal.message}
          </div>
          <div className="confirm-modal-actions">
            <button
              type="button"
              className="btn-add"
              id="confirm-modal-yes"
              onClick={() => closeConfirmModal(true)}
            >
              {confirmModal.yesLabel}
            </button>
            <button
              type="button"
              className="btn-delete"
              id="confirm-modal-no"
              onClick={() => closeConfirmModal(false)}
              style={{ height: '46px', fontSize: '0.95rem' }}
            >
              انصراف
            </button>
          </div>
        </div>
      </div>

      {/* Deep Work & Flow State Studio Focus Overlay */}
      <div className={`focus-overlay ${isFocusModeOpen ? 'active' : ''}`} id="focus-overlay">
        <div className="focus-header">
          <div>
            <h2>🔍 حالت تمرکز</h2>
            <span id="focus-date-label">{currentDayLabelText}</span>
          </div>
          <button
            type="button"
            className="btn-close-focus"
            onClick={() => {
              setFocusTimerRunning(false);
              setIsFocusModeOpen(false);
            }}
          >
            ✖ خروج
          </button>
        </div>

        <div className="focus-container" id="focus-container">
          {/* Overall Day Progress */}
          <div className="focus-overall-progress">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontWeight: 800, color: 'var(--focus-text)', fontSize: '0.9rem' }}>
                📊 پیشرفت تسک‌های امروز
              </span>
              <span style={{ fontWeight: 900, color: '#34d399' }}>
                {toPersianDigits(dayProgressPct)}%
              </span>
            </div>
            <div className="focus-progress-bar">
              <div className="focus-progress-fill" style={{ width: `${dayProgressPct}%` }} />
            </div>
            <div className="focus-progress-text">
              {toPersianDigits(dayCompletedCount)} از {toPersianDigits(dayTotalCount)} تسک انجام شده
            </div>
          </div>

          {/* Switcher between Single-Task Flow & Full Day List */}
          <div className="focus-mode-switcher">
            <button
              type="button"
              className={`fmode-btn ${focusViewTab === 'single' ? 'active' : ''}`}
              onClick={() => {
                triggerHaptic(10);
                setFocusViewTab('single');
              }}
            >
              🎯 تمرکز تک‌کاره (Flow)
            </button>
            <button
              type="button"
              className={`fmode-btn ${focusViewTab === 'list' ? 'active' : ''}`}
              onClick={() => {
                triggerHaptic(10);
                setFocusViewTab('list');
              }}
            >
              📋 لیست کل روز ({toPersianDigits(focusPendingTasks.length)})
            </button>
          </div>

          {rawDayTasks.length === 0 ? (
            <div
              style={{
                textAlign: 'center',
                color: 'var(--focus-muted)',
                fontSize: '1.05rem',
                padding: '36px 20px',
                background: 'var(--focus-card-bg)',
                borderRadius: '22px',
              }}
            >
              🎉 هیچ تسکی برای این روز ثبت نشده است!
            </div>
          ) : focusViewTab === 'single' ? (
            focusPendingTasks.length === 0 ? (
              <div className="focus-hero-card">
                <div style={{ fontSize: '3.2rem' }}>🏆</div>
                <div className="focus-hero-title">فوق‌العاده! تمام کارهای امروزت رو فتح کردی!</div>
                <p style={{ color: 'var(--focus-muted)', fontSize: '0.9rem', lineHeight: 1.7 }}>
                  ذهن آرام، نتیجه عمل به تعهداته. می‌تونی استراحت کنی یا برای فردات برنامه‌ریزی کنی.
                </p>
                <button
                  type="button"
                  className="btn-focus-done"
                  style={{ width: '100%' }}
                  onClick={() => launchCelebration('goal', 'تمام تسک‌های امروز')}
                >
                  🎉 جشن تکمیل روز
                </button>
              </div>
            ) : (
              <>
                <div className="focus-hero-card">
                  <div className="focus-mindset-pill">{currentMindsetQuote.tag}</div>
                  <div
                    style={{
                      fontSize: '0.8rem',
                      color: 'var(--focus-muted)',
                      lineHeight: 1.6,
                      padding: '0 4px',
                    }}
                  >
                    {currentMindsetQuote.text}
                  </div>

                  {currentFocusTask && (
                    <div className="focus-active-task-box">
                      <div className="focus-step-counter">
                        گام {toPersianDigits(safeFocusIndex + 1)} از{' '}
                        {toPersianDigits(focusPendingTasks.length)} در اولویت امروز
                      </div>
                      <div className="focus-hero-title">{currentFocusTask.text}</div>
                      <div className="focus-hero-badges">
                        <span className={`priority-badge priority-${currentFocusTask.priority}`}>
                          {priorityLabels[currentFocusTask.priority]}
                        </span>
                        <span className="habit-slot-badge">
                          {slotEmojis[currentFocusTask.slot]} {slotLabels[currentFocusTask.slot]}
                        </span>
                        {currentFocusTask.time && (
                          <span className="focus-task-time">
                            ⏰ {toPersianDigits(currentFocusTask.time)}
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Pomodoro Circular SVG Ring */}
                  <div className="focus-timer-ring-wrap">
                    <svg className="focus-timer-svg" viewBox="0 0 180 180">
                      <circle className="focus-timer-track" cx="90" cy="90" r="78" />
                      <circle
                        className="focus-timer-progress"
                        id="focus-timer-ring"
                        cx="90"
                        cy="90"
                        r="78"
                        strokeDasharray="490"
                        strokeDashoffset={focusStrokeDashoffset}
                      />
                    </svg>
                    <div className="focus-timer-center">
                      <div className="focus-timer-digits" id="focus-timer-digits">
                        {toPersianDigits(focusMm)}:{toPersianDigits(focusSs)}
                      </div>
                      <div className="focus-timer-phase" id="focus-timer-phase">
                        {focusModeLabel}
                      </div>
                    </div>
                  </div>

                  <div className="focus-presets-row">
                    <button
                      type="button"
                      className={`focus-preset-chip ${
                        focusTimerTotal === 5 * 60 ? 'active' : ''
                      }`}
                      onClick={() => setFocusPreset(5, '⚡ قانون ۵ دقیقه شروع سریع')}
                    >
                      ⚡ قانون ۵ دقیقه
                    </button>
                    <button
                      type="button"
                      className={`focus-preset-chip ${
                        focusTimerTotal === 25 * 60 ? 'active' : ''
                      }`}
                      onClick={() => setFocusPreset(25, '🍅 پومودورو ۲۵ دقیقه')}
                    >
                      🍅 ۲۵ دقیقه
                    </button>
                    <button
                      type="button"
                      className={`focus-preset-chip ${
                        focusTimerTotal === 45 * 60 ? 'active' : ''
                      }`}
                      onClick={() => setFocusPreset(45, '🔥 کار عمیق ۴۵ دقیقه')}
                    >
                      🔥 ۴۵ دقیقه عمیق
                    </button>
                    <button
                      type="button"
                      className={`focus-preset-chip ${
                        focusTimerTotal === 1 * 60 ? 'active' : ''
                      }`}
                      onClick={() => setFocusPreset(1, '🧘 تنفس عمیق آرامش‌بخش (۱ دقیقه)')}
                    >
                      🧘 تنفس ۱ دقیقه
                    </button>
                  </div>

                  {/* Custom Minutes Input Bar */}
                  <div className="focus-custom-time-bar">
                    <span
                      style={{
                        fontSize: '0.78rem',
                        fontWeight: 800,
                        color: 'var(--focus-muted)',
                      }}
                    >
                      ⏱️ زمان دلخواه:
                    </span>
                    <button
                      type="button"
                      className="focus-step-btn"
                      onClick={() => adjustFocusCustomMinutes(-5)}
                    >
                      −۵
                    </button>
                    <button
                      type="button"
                      className="focus-step-btn"
                      onClick={() => adjustFocusCustomMinutes(-1)}
                    >
                      −۱
                    </button>
                    <div className="focus-custom-input-wrap">
                      <input
                        type="number"
                        id="focus-custom-min-input"
                        min={1}
                        max={180}
                        value={Math.round(focusTimerTotal / 60)}
                        onChange={(e) => {
                          const val = Math.max(1, Math.min(180, Number(e.target.value) || 25));
                          setFocusPreset(val, `⏱️ زمان دلخواه (${toPersianDigits(val)} دقیقه)`);
                        }}
                      />
                      <span>دقیقه</span>
                    </div>
                    <button
                      type="button"
                      className="focus-step-btn"
                      onClick={() => adjustFocusCustomMinutes(1)}
                    >
                      +۱
                    </button>
                    <button
                      type="button"
                      className="focus-step-btn"
                      onClick={() => adjustFocusCustomMinutes(5)}
                    >
                      +۵
                    </button>
                  </div>

                  <div className="focus-controls-row">
                    <button
                      type="button"
                      className="btn-focus-primary"
                      id="btn-focus-run"
                      onClick={() => {
                        triggerHaptic(15);
                        setFocusTimerRunning((p) => !p);
                      }}
                    >
                      {focusTimerRunning ? '⏸ مکث تایمر' : '▶ شروع تمرکز'}
                    </button>
                    <button
                      type="button"
                      className="btn-focus-secondary"
                      onClick={() => {
                        triggerHaptic(10);
                        setFocusTimerRunning(false);
                        setFocusTimerRemaining(focusTimerTotal);
                      }}
                    >
                      ↺ ریست
                    </button>
                  </div>

                  {currentFocusTask && (
                    <div className="focus-controls-row">
                      <button
                        type="button"
                        className="btn-focus-done"
                        onClick={() => {
                          triggerHaptic([20, 40, 20]);
                          setFocusTimerRunning(false);
                          handleToggleTask(selectedDateKey, currentFocusTask.id);
                          launchCelebration('habit', currentFocusTask.text);
                        }}
                      >
                        ✅ انجام شد! (پاداش)
                      </button>
                      {focusPendingTasks.length > 1 && (
                        <button
                          type="button"
                          className="btn-focus-secondary"
                          onClick={() => {
                            triggerHaptic(10);
                            setFocusCurrentIndex((i) => i + 1);
                          }}
                        >
                          ⏭ کار بعدی
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Brain Dump Scratchpad */}
                <div className="focus-braindump-card">
                  <div
                    style={{
                      fontSize: '0.82rem',
                      fontWeight: 800,
                      color: 'var(--focus-text)',
                    }}
                  >
                    🧠 تخلیه ذهنی سریع (جلوگیری از پرش ذهن وسط تمرکز)
                  </div>
                  <div className="focus-braindump-row">
                    <input
                      type="text"
                      id="focus-braindump-input"
                      value={focusBrainDumpInput}
                      onChange={(e) => setFocusBrainDumpInput(e.target.value)}
                      placeholder="فکر یا کاری به ذهنت رسید؟ اینجا بنویس تا فراموش نشه..."
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSaveFocusBrainDump();
                      }}
                    />
                    <button type="button" onClick={handleSaveFocusBrainDump}>
                      ثبت در یادداشت
                    </button>
                  </div>
                </div>
              </>
            )
          ) : (
            /* Full Day List inside Focus Mode */
            (['morning', 'afternoon', 'night'] as TaskSlot[]).map((slot) => {
              const slotItems = rawDayTasks.filter((t) => t.slot === slot);
              if (slotItems.length === 0) return null;
              return (
                <React.Fragment key={slot}>
                  <div className="section-category-title">
                    {slotEmojis[slot]} {slotLabels[slot]}
                  </div>
                  {slotItems.map((t) => (
                    <div
                      key={t.id}
                      className={`focus-task-card glow-${t.priority} ${
                        t.completed ? 'completed' : ''
                      }`}
                      onClick={() => handleToggleTask(selectedDateKey, t.id)}
                    >
                      <input
                        type="checkbox"
                        className="focus-checkbox"
                        checked={t.completed}
                        onChange={() => {}}
                      />
                      <div className="focus-task-info">
                        <span className={`priority-dot priority-dot-${t.priority}`} />
                        <span className="focus-task-text">{t.text}</span>
                        <span className={`priority-badge priority-${t.priority}`}>
                          {priorityLabels[t.priority]}
                        </span>
                        {t.time && (
                          <span className="focus-task-time">⏰ {toPersianDigits(t.time)}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </React.Fragment>
              );
            })
          )}
        </div>
      </div>

      {/* Android PWA & APK Install Modal */}
      <AndroidInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        isIOS={isIOS}
        onTriggerInstall={triggerInstall}
      />

      {/* Full-Screen / Bottom-Sheet Active Ringing Alarm Modal */}
      <ActiveAlarmModal
        alarm={activeAlarm}
        defaultSnoozeMinutes={alarmSettings.defaultSnoozeMinutes}
        onDismiss={handleDismissAlarm}
        onSnooze={handleSnoozeAlarm}
        onCompleteTask={activeAlarm?.sourceType === 'task' ? handleCompleteTaskFromAlarm : undefined}
      />

      {/* Dynamic Island Toast Notifications */}
      {toasts.map((toast) => (
        <div key={toast.id} className={`notification-toast ${toast.type}`}>
          <div className="notification-title">{toast.title}</div>
          <div className="notification-text">{toast.text}</div>
        </div>
      ))}
    </>
  );
}
