import { HabitItem, JalaliDateObj, JalaliDateTuple, TaskItem, TaskPriority, ThemeId } from '../types';

export const VALID_THEMES: ThemeId[] = ['dark', 'light', 'emerald', 'rose', 'ocean', 'amber'];

export const jalaliMonthNames = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];
export const persianMonths = jalaliMonthNames;

export const weekDaysOrder = [
  'شنبه',
  'یکشنبه',
  'دوشنبه',
  'سه‌شنبه',
  'چهارشنبه',
  'پنج‌شنبه',
  'جمعه',
];
export const weekDays = weekDaysOrder;

export const weekDaysShort = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

export const slotLabels: Record<string, string> = {
  morning: 'صبح',
  afternoon: 'ظهر و عصر',
  night: 'شب',
};

export const slotEmojis: Record<string, string> = {
  morning: '🌅',
  afternoon: '☀️',
  night: '🌙',
};

export const priorityLabels: Record<TaskPriority, string> = {
  low: 'پایین',
  medium: 'متوسط',
  high: 'بالا',
  goal: 'هدف',
  prayer: 'نماز',
  habit: 'عادت',
};

export const priorityOrder: Record<TaskPriority, number> = {
  high: 1,
  prayer: 2,
  goal: 3,
  habit: 4,
  medium: 5,
  low: 6,
};

export function toPersianDigits(num: number | string): string {
  return String(num).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

const _j2gCache: Record<string, number> = {};
const _g2jCache: Record<string, { targetYear: number; targetMonth: number; targetDay: number }> = {};

export function jalaliToGregorian(jy: number, jm: number, jd: number): Date {
  const ck = `${jy}_${jm}_${jd}`;
  if (_j2gCache[ck]) return new Date(_j2gCache[ck]);
  let gy = jy > 979 ? 1600 : 621;
  jy -= jy > 979 ? 979 : 0;
  let days =
    365 * jy +
    Math.floor(jy / 33) * 8 +
    Math.floor(((jy % 33) + 3) / 4) +
    78 +
    jd +
    (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const isLeap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
  const sal_a = [0, 31, isLeap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) {
    gd -= sal_a[gm];
  }
  const res = new Date(gy, gm - 1, gd).getTime();
  _j2gCache[ck] = res;
  return new Date(res);
}

export function getWeekdayIndex(y: number, m: number, d: number): number {
  const g = jalaliToGregorian(y, m, d);
  return (g.getDay() + 1) % 7;
}
export const getDayOfWeek = getWeekdayIndex;

export function getWeekdayName(y: number, m: number, d: number): string {
  return weekDaysOrder[getWeekdayIndex(y, m, d)];
}

const persianFormatter = new Intl.DateTimeFormat('en-US-u-ca-persian', {
  year: 'numeric',
  month: 'numeric',
  day: 'numeric',
});

const persianLongFormatter = new Intl.DateTimeFormat('en-US-u-ca-persian', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

export function gregorianToJalaliObj(gDate: Date): {
  targetYear: number;
  targetMonth: number;
  targetDay: number;
} {
  const ck = `${gDate.getFullYear()}_${gDate.getMonth()}_${gDate.getDate()}`;
  if (_g2jCache[ck]) return _g2jCache[ck];
  const parts = persianFormatter.formatToParts(gDate);
  const res = {
    targetYear: parseInt(parts.find((p) => p.type === 'year')!.value, 10),
    targetMonth: parseInt(parts.find((p) => p.type === 'month')!.value, 10),
    targetDay: parseInt(parts.find((p) => p.type === 'day')!.value, 10),
  };
  _g2jCache[ck] = res;
  return res;
}

export function gregorianToJalali(gy: number, gm: number, gd: number): JalaliDateTuple {
  const obj = gregorianToJalaliObj(new Date(gy, gm - 1, gd));
  return [obj.targetYear, obj.targetMonth, obj.targetDay];
}

export function todayJalali(now: Date = new Date()): JalaliDateObj {
  const parts = persianFormatter.formatToParts(now);
  return {
    y: parseInt(parts.find((p) => p.type === 'year')!.value, 10),
    m: parseInt(parts.find((p) => p.type === 'month')!.value, 10),
    d: parseInt(parts.find((p) => p.type === 'day')!.value, 10),
  };
}

export function getTodayJalali(now: Date = new Date()): JalaliDateTuple {
  const t = todayJalali(now);
  return [t.y, t.m, t.d];
}

export function jalaliToIso(jy: number, jm: number, jd: number): string {
  const g = jalaliToGregorian(jy, jm, jd);
  const y = g.getFullYear();
  const m = String(g.getMonth() + 1).padStart(2, '0');
  const d = String(g.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function isoToJalali(iso: string): JalaliDateTuple {
  if (!iso || typeof iso !== 'string') return getTodayJalali();
  const [gy, gm, gd] = iso.split('-').map(Number);
  if (!gy || !gm || !gd) return getTodayJalali();
  return gregorianToJalali(gy, gm, gd);
}

export function addDaysToIso(iso: string, days: number): string {
  const [gy, gm, gd] = (iso || '').split('-').map(Number);
  const d = gy && gm && gd ? new Date(gy, gm - 1, gd) : new Date();
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function compareIso(a: string, b: string): number {
  return a.localeCompare(b);
}

export function getDateKey(y: number, m: number, d: number): string {
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

export function getJalaliDateDetails(now: Date = new Date()) {
  const hour = now.getHours();
  const { y: jYear, m: jMonth, d: jDay } = todayJalali(now);
  const monthName = jalaliMonthNames[jMonth - 1];
  const weekdayName = getWeekdayName(jYear, jMonth, jDay);
  const fullDateStr = `${weekdayName}، ${toPersianDigits(jDay)} ${monthName} ${toPersianDigits(jYear)}`;
  let greetingText = 'سلام!';
  let greetingEmoji = '👋';
  if (hour >= 5 && hour < 12) {
    greetingText = 'صبح بخیر';
    greetingEmoji = '☀️';
  } else if (hour >= 12 && hour < 17) {
    greetingText = 'ظهر بخیر';
    greetingEmoji = '🌤️';
  } else if (hour >= 17 && hour < 19) {
    greetingText = 'عصر بخیر';
    greetingEmoji = '🌅';
  } else {
    greetingText = 'شب بخیر';
    greetingEmoji = '🌙';
  }
  return { fullDateStr, jYear, jMonth, jDay, greetingText, greetingEmoji };
}

export function getMonthDaysCount(y: number, m: number): number {
  if (m >= 1 && m <= 6) return 31;
  if (m >= 7 && m <= 11) return 30;
  if (m === 12) {
    const isLeap = (((((y - (y > 0 ? 474 : 473)) % 2820) + 474 + 38) * 682) % 2816) < 682;
    return isLeap ? 30 : 29;
  }
  return 30;
}
export const getJalaliMonthLength = getMonthDaysCount;

export function getStorageKey(y: number, m: number, d: number): string {
  return `Y${y}_M${m}_D${d}`;
}

export function parseStorageKey(key: string): JalaliDateObj | null {
  const m = key.match(/^Y(\d+)_M(\d+)_D(\d+)$/);
  if (!m) return null;
  return { y: parseInt(m[1], 10), m: parseInt(m[2], 10), d: parseInt(m[3], 10) };
}

export function jalaliTime(y: number, m: number, d: number): number {
  return jalaliToGregorian(y, m, d).getTime();
}

export function habitDayList(habit: HabitItem): JalaliDateObj[] {
  const startTuple: JalaliDateTuple = habit.startDate
    ? [habit.startDate.y, habit.startDate.m, habit.startDate.d]
    : isoToJalali(habit.startIso || '');
  const startG = jalaliToGregorian(startTuple[0], startTuple[1], startTuple[2]);
  const list: JalaliDateObj[] = [];
  const activeDays = habit.activeDays || [0, 1, 2, 3, 4, 5, 6];
  for (let i = 0; i < habit.duration; i++) {
    const g = new Date(startG.getTime());
    g.setDate(startG.getDate() + i);
    const di = (g.getDay() + 1) % 7;
    if (!activeDays.includes(di)) continue;
    const j = gregorianToJalaliObj(g);
    list.push({ y: j.targetYear, m: j.targetMonth, d: j.targetDay });
  }
  return list;
}

export function habitProgress(
  habit: HabitItem,
  tasksData: Record<string, TaskItem[]>,
  today: JalaliDateObj = todayJalali()
) {
  const todayT = jalaliTime(today.y, today.m, today.d);
  const days = habitDayList(habit);
  let total = 0;
  let done = 0;
  let elapsed = 0;
  days.forEach((day) => {
    const dayT = jalaliTime(day.y, day.m, day.d);
    if (dayT > todayT) return;
    elapsed++;
    const key = getStorageKey(day.y, day.m, day.d);
    const altKey = getDateKey(day.y, day.m, day.d);
    const list = tasksData[key] || tasksData[altKey] || [];
    list.forEach((task) => {
      if ((task.originHabitId === habit.id || task.habitId === habit.id) && !task.isDeferred) {
        total++;
        if (task.completed) done++;
      }
    });
  });
  const pct = habit.completed ? 100 : total ? Math.round((done / total) * 100) : 0;
  return {
    total,
    done,
    elapsed,
    percent: pct,
    plannedDays: days.length,
  };
}

export function isHabitCompleted(
  habit: HabitItem,
  tasksData?: Record<string, TaskItem[]>,
  today: JalaliDateObj = todayJalali()
): boolean {
  if (habit.completed) return true;
  if (!tasksData) {
    const totalSpan = habit.duration + (habit.deferrals || 0);
    const todayIsoStr = jalaliToIso(today.y, today.m, today.d);
    const elapsed = calcDaysBetweenIso(habit.startIso, todayIsoStr);
    return elapsed > totalSpan;
  }
  const p = habitProgress(habit, tasksData, today);
  const days = habitDayList(habit);
  if (days.length === 0) return false;
  const last = days[days.length - 1];
  const lastT = jalaliTime(last.y, last.m, last.d);
  const todayT = jalaliTime(today.y, today.m, today.d);
  return todayT >= lastT && p.percent === 100 && p.done >= days.length;
}

export function isPrayerMissed(
  arg1: TaskItem | number,
  arg2: number,
  arg3: number,
  arg4: TaskItem | number,
  arg5?: number,
  arg6?: Date
): boolean {
  if (typeof arg1 === 'number' && typeof arg4 === 'object') {
    const jy = arg1;
    const jm = arg2;
    const jd = arg3;
    const t = arg4;
    if (t.completed || t.priority !== 'prayer') return false;
    const now = new Date();
    const [ty, tm, td] = getTodayJalali(now);
    const todayT = jalaliTime(ty, tm, td);
    const dayT = jalaliTime(jy, jm, jd);
    if (dayT > todayT) return false;
    if (dayT < todayT) return true;
    const nowMins = now.getHours() * 60 + now.getMinutes();
    if (t.time && t.time.includes(':')) {
      const [th, tmin] = t.time.split(':').map(Number);
      if (!isNaN(th) && !isNaN(tmin)) return nowMins > th * 60 + tmin + 30;
    }
    if (t.slot === 'morning') return nowMins >= 12 * 60;
    if (t.slot === 'afternoon') return nowMins >= 18 * 60 + 30;
    return false;
  }

  const t = arg1 as TaskItem;
  const y = arg2;
  const m = arg3;
  const d = arg4 as number;
  const todayT = arg5 ?? jalaliTime(...getTodayJalali());
  const nowDate = arg6 ?? new Date();

  if (!t || (!t.isPrayerTask && t.priority !== 'prayer') || t.completed) return false;
  const dayT = jalaliTime(y, m, d);
  if (dayT > todayT) return false;
  if (dayT < todayT) return true;

  const nowMins = nowDate.getHours() * 60 + nowDate.getMinutes();
  if (t.time && t.time.includes(':')) {
    const [th, tm] = t.time.split(':').map(Number);
    if (!isNaN(th) && !isNaN(tm)) {
      return nowMins >= th * 60 + tm;
    }
  }
  const slot = t.slot || 'morning';
  const txt = t.text || '';
  if (slot === 'morning' || txt.includes('صبح')) {
    return nowMins >= 12 * 60;
  }
  if (slot === 'afternoon' || txt.includes('ظهر') || txt.includes('عصر')) {
    return nowMins >= 18 * 60 + 30;
  }
  return false;
}

export function formatPersianDate(iso?: string | null): string {
  if (!iso) return 'ثبت‌شده';
  try {
    const d = new Date(iso);
    const parts = persianLongFormatter.formatToParts(d);
    const day = parts.find((p) => p.type === 'day')?.value || '';
    const month = parts.find((p) => p.type === 'month')?.value || '';
    return `${toPersianDigits(day)} ${month}`;
  } catch {
    return 'ثبت‌شده';
  }
}

export function calcDaysBetweenIso(startIso?: string | null, endIso?: string | null): number {
  if (!startIso || !endIso) return 0;
  try {
    const [sy, sm, sd] = startIso.split('-').map(Number);
    const [ey, em, ed] = endIso.split('-').map(Number);
    if (sy && sm && sd && ey && em && ed) {
      const sMs = new Date(sy, sm - 1, sd).getTime();
      const eMs = new Date(ey, em - 1, ed).getTime();
      return Math.round((eMs - sMs) / (1000 * 60 * 60 * 24));
    }
    const diff = Math.abs(new Date(endIso).getTime() - new Date(startIso).getTime());
    return Math.max(1, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  } catch {
    return 0;
  }
}
