import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_ALARM_SETTINGS,
  evaluateCustomReminders,
  evaluateTaskRemindersAndAlarms,
  parseTimeMinutes,
} from './alarmEngine';
import {
  getMonthDaysCount,
  getStorageKey,
  habitDayList,
  habitProgress,
  jalaliToGregorian,
  gregorianToJalaliObj,
  toPersianDigits,
} from './jalali';
import { CustomReminder, HabitItem, TaskItem } from '../types';

test('Jalali to Gregorian round-trip and Persian digits conversion', () => {
  assert.equal(toPersianDigits(1405), '۱۴۰۵');
  const gDate = jalaliToGregorian(1405, 8, 17);
  const jObj = gregorianToJalaliObj(gDate);
  assert.equal(jObj.targetYear, 1405);
  assert.equal(jObj.targetMonth, 8);
  assert.equal(jObj.targetDay, 17);
  assert.equal(getMonthDaysCount(1405, 1), 31);
  assert.equal(getMonthDaysCount(1405, 8), 30);
});

test('parseTimeMinutes validates HH:MM properly', () => {
  assert.equal(parseTimeMinutes('08:30'), 510);
  assert.equal(parseTimeMinutes('23:59'), 1439);
  assert.equal(parseTimeMinutes('invalid'), null);
  assert.equal(parseTimeMinutes('25:00'), null);
});

test('evaluateTaskRemindersAndAlarms triggers advance reminder and exact-time alarm', () => {
  const now = new Date(2026, 10, 8, 14, 20, 0, 0); // 14:20
  const tasks: TaskItem[] = [
    {
      id: 101,
      text: 'جلسه تیم فنی',
      slot: 'afternoon',
      time: '14:30', // 10 mins from now
      priority: 'high',
      completed: false,
      originGoalId: null,
      originTaskId: null,
      reminderMinutesBefore: 15,
      alarmEnabled: true,
      alarmTone: 'urgent',
    },
    {
      id: 102,
      text: 'خوردن دارو',
      slot: 'afternoon',
      time: '14:20', // exact time now
      priority: 'medium',
      completed: false,
      originGoalId: null,
      originTaskId: null,
      reminderMinutesBefore: 5,
      alarmEnabled: true,
      alarmTone: 'classic',
    },
  ];

  const res = evaluateTaskRemindersAndAlarms(tasks, 'Y1405_M8_D17', now, DEFAULT_ALARM_SETTINGS);
  assert.equal(res.changed, true);
  assert.equal(res.notificationsToSend.length, 1);
  assert.ok(res.notificationsToSend[0].body.includes('جلسه تیم فنی'));
  assert.equal(res.alarmsToRing.length, 1);
  assert.equal(res.alarmsToRing[0].taskId, 102);
  assert.equal(res.updatedTasks[0].reminderSent, true);
  assert.equal(res.updatedTasks[1].exactAlarmSent, true);
});

test('evaluateCustomReminders triggers specific_time and interval reminders accurately', () => {
  const now = new Date(2026, 10, 8, 9, 45, 0, 0); // 09:45
  const reminders: CustomReminder[] = [
    {
      id: 1,
      title: 'مرور برنامه صبحگاهی',
      message: 'اهداف امروزت رو چک کن',
      type: 'specific_time',
      time: '09:45',
      intervalMinutes: 60,
      activeStartTime: '08:00',
      activeEndTime: '22:00',
      activeDays: [0, 1, 2, 3, 4, 5, 6],
      alertMode: 'both',
      tone: 'morning',
      enabled: true,
    },
    {
      id: 2,
      title: 'نوشیدن آب گوارا',
      message: 'یک لیوان آب بنوشید 💧',
      type: 'interval',
      time: '10:00',
      intervalMinutes: 30,
      activeStartTime: '08:00',
      activeEndTime: '22:00',
      activeDays: [0, 1, 2, 3, 4, 5, 6],
      alertMode: 'notification',
      tone: 'zen',
      enabled: true,
      lastIntervalTriggeredAt: now.getTime() - 31 * 60000, // 31 mins ago
    },
  ];

  const res = evaluateCustomReminders(reminders, now);
  assert.equal(res.changed, true);
  assert.equal(res.alarmsToRing.length, 1);
  assert.equal(res.alarmsToRing[0].title, 'مرور برنامه صبحگاهی');
  assert.equal(res.notificationsToSend.length, 2);
});

test('habitDayList and habitProgress calculate active days and completion percent', () => {
  const habit: HabitItem = {
    id: 500,
    name: 'مطالعه روزانه',
    duration: 5,
    startDate: { y: 1405, m: 8, d: 15 },
    tasks: [{ id: 1, text: '۲۰ صفحه کتاب', slot: 'night', time: '21:00' }],
    activeDays: [0, 1, 2, 3, 4, 5, 6],
    deferrals: 0,
  };
  const days = habitDayList(habit);
  assert.equal(days.length, 5);
  const k1 = getStorageKey(days[0].y, days[0].m, days[0].d);
  const k2 = getStorageKey(days[1].y, days[1].m, days[1].d);
  const tasksData: Record<string, TaskItem[]> = {
    [k1]: [
      {
        id: 1,
        text: '🔁 ۲۰ صفحه کتاب',
        slot: 'night',
        time: '21:00',
        priority: 'habit',
        completed: true,
        originGoalId: null,
        originTaskId: null,
        originHabitId: 500,
      },
    ],
    [k2]: [
      {
        id: 2,
        text: '🔁 ۲۰ صفحه کتاب',
        slot: 'night',
        time: '21:00',
        priority: 'habit',
        completed: false,
        originGoalId: null,
        originTaskId: null,
        originHabitId: 500,
      },
    ],
  };
  const prog = habitProgress(habit, tasksData, days[1]);
  assert.equal(prog.total, 2);
  assert.equal(prog.done, 1);
  assert.equal(prog.percent, 50);
});
