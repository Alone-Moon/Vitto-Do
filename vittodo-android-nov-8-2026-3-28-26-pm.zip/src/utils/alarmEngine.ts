import {
  ActiveAlarmPayload,
  AlarmSettings,
  AlarmToneId,
  CustomReminder,
  TaskItem,
} from '../types';
import { getWeekdayIndex, toPersianDigits, todayJalali, getStorageKey } from './jalali';

export const ALARM_TONES: { id: AlarmToneId; name: string; desc: string }[] = [
  { id: 'classic', name: '🔔 کلاسیک دیجیتال', desc: 'زنگ استاندارد و شفاف ساعت هوشمند' },
  { id: 'morning', name: '🌅 ملودی صبحگاهی', desc: 'آکورد ملایم و انرژی‌بخش برای شروع کارها' },
  { id: 'urgent', name: '🚨 هشدار فوری (قوی)', desc: 'پالس سریع و بیدارکننده برای تسک‌های حیاتی' },
  { id: 'zen', name: '🧘 کاسه تبتی و تمرکز', desc: 'طنین آرامش‌بخش برای عادت‌ها و مطالعه' },
  { id: 'spiritual', name: '🕌 طنین معنوی ملایم', desc: 'مناسب یادآوری وقت نماز و مراقبه' },
];

export const DEFAULT_ALARM_SETTINGS: AlarmSettings = {
  notificationsEnabled: true,
  soundEnabled: true,
  vibrationEnabled: true,
  defaultAdvanceMinutes: 15,
  triggerExactTimeAlarm: true,
  defaultTone: 'classic',
  volume: 85,
  defaultSnoozeMinutes: 5,
};

export function parseTimeMinutes(timeStr: string): number | null {
  if (!timeStr || !/^\d{1,2}:\d{2}$/.test(timeStr.trim())) return null;
  const [h, m] = timeStr.trim().split(':').map(Number);
  if (isNaN(h) || isNaN(m) || h < 0 || h > 23 || m < 0 || m > 59) return null;
  return h * 60 + m;
}

export function formatTimeHHMM(date: Date): string {
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

export interface TaskEvaluationResult {
  updatedTasks: TaskItem[];
  changed: boolean;
  notificationsToSend: { title: string; body: string; tone: AlarmToneId }[];
  alarmsToRing: ActiveAlarmPayload[];
}

/**
 * Pure function that checks today's tasks against current time and returns
 * any advance notifications or exact-time/snoozed alarms to trigger.
 */
export function evaluateTaskRemindersAndAlarms(
  todayTasks: TaskItem[],
  todayKey: string,
  now: Date,
  settings: AlarmSettings
): TaskEvaluationResult {
  const updatedTasks = todayTasks.map((t) => ({ ...t }));
  let changed = false;
  const notificationsToSend: { title: string; body: string; tone: AlarmToneId }[] = [];
  const alarmsToRing: ActiveAlarmPayload[] = [];
  const nowMs = now.getTime();

  for (const task of updatedTasks) {
    if (task.completed) continue;

    // 1. Check snoozed alarm first
    if (task.snoozedUntil && nowMs >= task.snoozedUntil) {
      task.snoozedUntil = null;
      changed = true;
      const tone = task.alarmTone || settings.defaultTone;
      alarmsToRing.push({
        id: `task-snooze-${task.id}-${nowMs}`,
        title: `⏰ یادآور مجدد: ${task.text}`,
        subtitle: task.customReminderNote || 'زمان تعویق (Snooze) به پایان رسید!',
        timeLabel: formatTimeHHMM(now),
        tone,
        sourceType: 'task',
        dayKey: todayKey,
        taskId: task.id,
      });
      continue;
    }

    if (!task.time) continue;
    const parsedMin = parseTimeMinutes(task.time);
    if (parsedMin === null) continue;

    const taskTime = new Date(now.getTime());
    taskTime.setHours(Math.floor(parsedMin / 60), parsedMin % 60, 0, 0);
    const diffMs = taskTime.getTime() - nowMs;
    const diffMinutes = diffMs / 60000;

    const advanceMin =
      task.reminderMinutesBefore !== undefined
        ? task.reminderMinutesBefore
        : settings.defaultAdvanceMinutes;
    const tone = task.alarmTone || settings.defaultTone;

    // 2. Advance Reminder Notification (when advanceMin > 0 and within window)
    if (
      advanceMin > 0 &&
      !task.reminderSent &&
      diffMinutes > 0 &&
      diffMinutes <= advanceMin
    ) {
      task.reminderSent = true;
      changed = true;
      const roundedMin = Math.max(1, Math.ceil(diffMinutes));
      const noteSuffix = task.customReminderNote ? ` — ${task.customReminderNote}` : '';
      notificationsToSend.push({
        title: `⏰ یادآوری تسک (${toPersianDigits(roundedMin)} دقیقه مانده)`,
        body: `تسک «${task.text}» ساعت ${toPersianDigits(task.time)} شروع می‌شود${noteSuffix}`,
        tone,
      });
    }

    // 3. Exact Time Alarm (within [-1.5, +0.5] minutes of task time, or advanceMin === 0)
    const shouldRingExact =
      task.alarmEnabled !== undefined ? task.alarmEnabled : settings.triggerExactTimeAlarm;

    if (
      shouldRingExact &&
      !task.exactAlarmSent &&
      diffMinutes <= 0.3 &&
      diffMinutes >= -2
    ) {
      task.exactAlarmSent = true;
      task.reminderSent = true;
      changed = true;
      alarmsToRing.push({
        id: `task-exact-${task.id}`,
        title: task.text,
        subtitle:
          task.customReminderNote ||
          `زمان انجام تسک در ساعت ${toPersianDigits(task.time)} فرا رسیده است!`,
        timeLabel: task.time,
        tone,
        sourceType: 'task',
        dayKey: todayKey,
        taskId: task.id,
      });
    }
  }

  return { updatedTasks, changed, notificationsToSend, alarmsToRing };
}

export interface CustomReminderEvaluationResult {
  updatedReminders: CustomReminder[];
  changed: boolean;
  notificationsToSend: { title: string; body: string; tone: AlarmToneId }[];
  alarmsToRing: ActiveAlarmPayload[];
}

/**
 * Pure function that evaluates user-defined custom reminders (specific_time and interval).
 */
export function evaluateCustomReminders(
  reminders: CustomReminder[],
  now: Date
): CustomReminderEvaluationResult {
  const updatedReminders = reminders.map((r) => ({ ...r }));
  let changed = false;
  const notificationsToSend: { title: string; body: string; tone: AlarmToneId }[] = [];
  const alarmsToRing: ActiveAlarmPayload[] = [];

  const today = todayJalali(now);
  const todayKey = getStorageKey(today.y, today.m, today.d);
  const weekdayIdx = getWeekdayIndex(today.y, today.m, today.d);
  const currentHHMM = formatTimeHHMM(now);
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const nowMs = now.getTime();

  for (const rem of updatedReminders) {
    if (!rem.enabled) continue;

    // Check snooze first
    if (rem.snoozedUntil && nowMs >= rem.snoozedUntil) {
      rem.snoozedUntil = null;
      changed = true;
      alarmsToRing.push({
        id: `rem-snooze-${rem.id}-${nowMs}`,
        title: `⏰ ${rem.title}`,
        subtitle: rem.message || 'یادآور شخصی‌سازی‌شده (پایان تعویق)',
        timeLabel: currentHHMM,
        tone: rem.tone,
        sourceType: 'custom_reminder',
        reminderId: rem.id,
      });
      continue;
    }

    const activeDays = rem.activeDays && rem.activeDays.length > 0 ? rem.activeDays : [0, 1, 2, 3, 4, 5, 6];
    if (!activeDays.includes(weekdayIdx)) continue;

    if (rem.type === 'specific_time') {
      const targetMin = parseTimeMinutes(rem.time);
      if (targetMin === null) continue;
      const triggerStamp = `${todayKey}_${rem.time}`;
      if (rem.lastTriggeredDateKey === triggerStamp) continue;

      // Trigger if current minute matches or is within 1 minute after target
      const diff = currentMinutes - targetMin;
      if (diff >= 0 && diff <= 1) {
        rem.lastTriggeredDateKey = triggerStamp;
        changed = true;
        if (rem.alertMode === 'alarm' || rem.alertMode === 'both') {
          alarmsToRing.push({
            id: `rem-time-${rem.id}-${triggerStamp}`,
            title: rem.title,
            subtitle: rem.message || `یادآور ساعت ${toPersianDigits(rem.time)}`,
            timeLabel: rem.time,
            tone: rem.tone,
            sourceType: 'custom_reminder',
            reminderId: rem.id,
          });
        }
        if (rem.alertMode === 'notification' || rem.alertMode === 'both') {
          notificationsToSend.push({
            title: `🔔 ${rem.title}`,
            body: rem.message || `یادآور شخصی ساعت ${toPersianDigits(rem.time)}`,
            tone: rem.tone,
          });
        }
      }
    } else if (rem.type === 'interval') {
      const startMin = parseTimeMinutes(rem.activeStartTime || '08:00') ?? 480;
      const endMin = parseTimeMinutes(rem.activeEndTime || '22:00') ?? 1320;
      if (currentMinutes < startMin || currentMinutes > endMin) continue;

      const intervalMs = Math.max(5, rem.intervalMinutes || 60) * 60000;
      const lastAt = rem.lastIntervalTriggeredAt || 0;
      if (lastAt === 0) {
        // Initialize timer from now so it triggers after 1 interval
        rem.lastIntervalTriggeredAt = nowMs;
        changed = true;
      } else if (nowMs - lastAt >= intervalMs) {
        rem.lastIntervalTriggeredAt = nowMs;
        changed = true;
        if (rem.alertMode === 'alarm' || rem.alertMode === 'both') {
          alarmsToRing.push({
            id: `rem-int-${rem.id}-${nowMs}`,
            title: rem.title,
            subtitle:
              rem.message ||
              `یادآور دوره‌ای (هر ${toPersianDigits(rem.intervalMinutes)} دقیقه)`,
            timeLabel: currentHHMM,
            tone: rem.tone,
            sourceType: 'custom_reminder',
            reminderId: rem.id,
          });
        }
        if (rem.alertMode === 'notification' || rem.alertMode === 'both') {
          notificationsToSend.push({
            title: `🔁 ${rem.title}`,
            body:
              rem.message ||
              `یادآور دوره‌ای هر ${toPersianDigits(rem.intervalMinutes)} دقیقه`,
            tone: rem.tone,
          });
        }
      }
    }
  }

  return { updatedReminders, changed, notificationsToSend, alarmsToRing };
}

// ============================================================================
// Web Audio API Synthesizer & Android Vibration / Notification Engine
// ============================================================================

let audioCtx: AudioContext | null = null;
let alarmLoopTimer: ReturnType<typeof setInterval> | null = null;
let hasUserInteracted = false;
let isVibrating = false;

if (typeof window !== 'undefined') {
  const markInteracted = () => {
    hasUserInteracted = true;
  };
  window.addEventListener('pointerdown', markInteracted, { once: true, passive: true });
  window.addEventListener('keydown', markInteracted, { once: true, passive: true });
  window.addEventListener('click', markInteracted, { once: true, passive: true });
}

function safeVibrate(pattern: number | number[]) {
  if (!hasUserInteracted || typeof navigator === 'undefined' || !('vibrate' in navigator)) {
    return;
  }
  try {
    navigator.vibrate(pattern);
  } catch {
    // Ignore
  }
}

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return null;
  if (!audioCtx) {
    audioCtx = new AudioCtx();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export function playToneSequence(tone: AlarmToneId, volumePercent: number = 80) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const gainScalar = Math.max(0.05, Math.min(1, volumePercent / 100)) * 0.35;
  const now = ctx.currentTime;

  const playNote = (
    freq: number,
    startOffset: number,
    duration: number,
    type: OscillatorType = 'sine',
    peakScalar = 1
  ) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now + startOffset);

    gain.gain.setValueAtTime(0.0001, now + startOffset);
    gain.gain.exponentialRampToValueAtTime(
      Math.max(0.01, gainScalar * peakScalar),
      now + startOffset + 0.03
    );
    gain.gain.exponentialRampToValueAtTime(0.0001, now + startOffset + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + startOffset);
    osc.stop(now + startOffset + duration + 0.02);
  };

  if (tone === 'classic') {
    // Classic digital double-beep pattern
    playNote(880, 0.0, 0.14, 'square', 0.7);
    playNote(880, 0.18, 0.14, 'square', 0.7);
    playNote(1174.66, 0.42, 0.22, 'square', 0.8);
  } else if (tone === 'morning') {
    // Uplifting major arpeggio (C5 - E5 - G5 - C6)
    playNote(523.25, 0.0, 0.22, 'triangle', 0.9);
    playNote(659.25, 0.18, 0.22, 'triangle', 0.9);
    playNote(783.99, 0.36, 0.25, 'triangle', 0.95);
    playNote(1046.5, 0.56, 0.45, 'sine', 1.0);
  } else if (tone === 'urgent') {
    // Urgent high-contrast alarm siren pulse
    playNote(987.77, 0.0, 0.12, 'sawtooth', 0.85);
    playNote(1318.51, 0.13, 0.12, 'sawtooth', 0.85);
    playNote(987.77, 0.26, 0.12, 'sawtooth', 0.85);
    playNote(1318.51, 0.39, 0.2, 'sawtooth', 0.95);
  } else if (tone === 'zen') {
    // Warm harmonic singing bowl
    playNote(432, 0.0, 0.95, 'sine', 1.0);
    playNote(648, 0.05, 0.8, 'sine', 0.5);
    playNote(864, 0.1, 0.65, 'sine', 0.3);
  } else if (tone === 'spiritual') {
    // Gentle Hijaz-inspired spiritual chime
    playNote(440, 0.0, 0.3, 'sine', 0.9);
    playNote(466.16, 0.28, 0.25, 'sine', 0.85);
    playNote(554.37, 0.52, 0.35, 'sine', 0.95);
    playNote(587.33, 0.85, 0.45, 'sine', 1.0);
  }
}

export function startLoopingAlarm(
  tone: AlarmToneId,
  volumePercent: number,
  vibrate: boolean
) {
  stopLoopingAlarm();
  playToneSequence(tone, volumePercent);
  if (vibrate) {
    isVibrating = true;
    safeVibrate([400, 200, 400, 200, 600]);
  }
  alarmLoopTimer = setInterval(() => {
    playToneSequence(tone, volumePercent);
    if (vibrate) {
      isVibrating = true;
      safeVibrate([400, 200, 400]);
    }
  }, 1800);
}

export function stopLoopingAlarm() {
  if (alarmLoopTimer) {
    clearInterval(alarmLoopTimer);
    alarmLoopTimer = null;
  }
  if (isVibrating) {
    isVibrating = false;
    safeVibrate(0);
  }
}

export async function requestAndroidNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  if (Notification.permission === 'granted') {
    return 'granted';
  }
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

export async function sendAndroidSystemNotification(
  title: string,
  body: string,
  vibrate: boolean = true
): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) return false;
  if (Notification.permission !== 'granted') return false;

  const options: NotificationOptions & { vibrate?: number[]; renotify?: boolean } = {
    body,
    icon: '/pwa-192x192.png',
    badge: '/pwa-192x192.png',
    dir: 'rtl',
    lang: 'fa',
    tag: `vittodo-${Date.now()}`,
    renotify: true,
    vibrate: vibrate ? [300, 150, 300, 150, 400] : undefined,
  };

  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && 'showNotification' in reg) {
        await reg.showNotification(title, options);
        return true;
      }
    }
    new Notification(title, options);
    return true;
  } catch {
    try {
      new Notification(title, options);
      return true;
    } catch {
      return false;
    }
  }
}

export function triggerHaptic(pattern: number | number[] = 12): void {
  safeVibrate(pattern);
}

export const startAlarmLoop = startLoopingAlarm;
export const stopAlarmLoop = stopLoopingAlarm;

export function sendAndroidNotification(
  title: string,
  body: string,
  _id?: string
): Promise<boolean> {
  return sendAndroidSystemNotification(title, body, true);
}

export function pruneFiredHistory(
  registry: Record<string, number>,
  nowMs: number,
  maxAgeMs: number = 36 * 60 * 60 * 1000
): Record<string, number> {
  const next: Record<string, number> = {};
  for (const [k, ts] of Object.entries(registry)) {
    if (nowMs - ts < maxAgeMs) {
      next[k] = ts;
    }
  }
  return next;
}

export function evaluateDueAlarms(
  now: Date,
  todayKey: string,
  todayTasks: TaskItem[],
  customReminders: CustomReminder[],
  settings: AlarmSettings,
  firedRegistry: Record<string, number>
): { payloads: ActiveAlarmPayload[]; nextFiredKeys: string[] } {
  const payloads: ActiveAlarmPayload[] = [];
  const nextFiredKeys: string[] = [];

  const taskRes = evaluateTaskRemindersAndAlarms(todayTasks, todayKey, now, settings);
  for (const alarm of taskRes.alarmsToRing) {
    const key = `${todayKey}_${alarm.id}`;
    if (!firedRegistry[key]) {
      nextFiredKeys.push(key);
      payloads.push({ ...alarm, dateKey: todayKey });
    }
  }
  for (let i = 0; i < taskRes.notificationsToSend.length; i++) {
    const notif = taskRes.notificationsToSend[i];
    const key = `${todayKey}_notif_${notif.title}_${notif.body}`;
    if (!firedRegistry[key]) {
      nextFiredKeys.push(key);
      payloads.push({
        id: `task-adv-${i}-${now.getTime()}`,
        title: notif.title,
        subtitle: notif.body,
        timeLabel: formatTimeHHMM(now),
        tone: notif.tone,
        sourceType: 'task',
        dateKey: todayKey,
      });
    }
  }

  const remRes = evaluateCustomReminders(customReminders, now);
  for (const alarm of remRes.alarmsToRing) {
    const key = `${todayKey}_${alarm.id}`;
    if (!firedRegistry[key]) {
      nextFiredKeys.push(key);
      payloads.push(alarm);
    }
  }

  return { payloads, nextFiredKeys };
}

